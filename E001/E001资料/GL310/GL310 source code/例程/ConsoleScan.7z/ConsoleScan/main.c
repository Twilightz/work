#include <windows.h>
#include <stdio.h>
#include "utype.h"
#include "usbio.h"
#include "Utility.h"

//------------
extern int scan();
extern int move();
//------------

int main(int argc, char *argv[])
{
	int hit;
	U32 action;

	printf("-------------------\n");
	printf("ConsoleScan v0.01\n");

l_OPEN_DEVICE:
	printf("--------------------------------------- \n");
	printf("Open scanner ..");
	if(!CMDIO_OpenDevice()) {
		printf("NG\n");
		DigitWaitHitKey(-1000);
		goto l_EXIT;
	}
	printf("OK\n");
	
	action = Load_Action();

	if(action == I4('SCAN'))
		scan();
	else if(action == I4('MOTO'))
		move();

	printf("\nClose Scanner ..");
	if(CMDIO_CloseDevice())
		printf("OK");
	else
		printf("NG");

	printf("\n\nPress 'R' to retry or other key to exit ....");
	do {
		hit = DigitWaitHitKey(1000);
	} while (hit == 0);
	if(hit == 'R' || hit == 'r') {
		printf("\r");
		goto l_OPEN_DEVICE;
	}

l_EXIT:
	return 0;
}
