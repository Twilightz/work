#ifndef _utility_h_
#define _utility_h_
#ifdef __cplusplus
extern "C" {
#endif//__cplusplus
//-----------------

int BreathWaitHitKey(int ms);
int DigitWaitHitKey(int ms);

//-----------------
#ifdef __cplusplus
}
#endif//__cplusplus
#endif//_utility_h_
