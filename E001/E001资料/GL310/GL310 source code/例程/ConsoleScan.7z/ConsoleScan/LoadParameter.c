#include <windows.h>
#include <stdio.h>
#include "usbio.h"
#include "ImgFile.h"
#include "ScanCmd.h"

extern SC_PAR_DATA_T sc_pardata;
extern IMG_FILE_T ImgFile[2];

char IniFile[256];
char ScanProfile[64];
char *MotoProfile = ScanProfile;
char *action = ScanProfile;

int Load_ScanParameter()
{
	char *file;
	int PageLength;
	GetModuleFileName(NULL, IniFile, sizeof(IniFile));
	strcpy(strrchr(IniFile, '.')+1, "ini");
	GetPrivateProfileString("Scan", "Profile", NULL, ScanProfile, sizeof(ScanProfile), IniFile);
	if(ScanProfile[0] == NULL)
		return FALSE;

	GetPrivateProfileString(ScanProfile, "SCAN_SOURCE", "FLB", (LPSTR)&sc_pardata.source, 4, IniFile);
	GetPrivateProfileString(ScanProfile, "SCAN_FORMAT", "RAW", (LPSTR)&sc_pardata.format, 4, IniFile);
	ImgFile[0].img.format = ImgFile[1].img.format = (sc_pardata.format==I3('RAW'))? I3('TIF'): sc_pardata.format;
	sc_pardata.bit = ImgFile[0].img.bit = ImgFile[1].img.bit =
	GetPrivateProfileInt(ScanProfile, "SCAN_BIT", 24, IniFile);
	sc_pardata.dpi.x = sc_pardata.dpi.y = ImgFile[0].img.dpi.x = ImgFile[0].img.dpi.y = ImgFile[1].img.dpi.x = ImgFile[1].img.dpi.y =
	GetPrivateProfileInt(ScanProfile, "SCAN_DPI", 300, IniFile);
	PageLength=GetPrivateProfileInt(ScanProfile, "SCAN_LENGTH", 12, IniFile);
	sc_pardata.dot.w = ImgFile[0].img.dot.w = ImgFile[1].img.dot.w = 864 * sc_pardata.dpi.x / 100;

	sc_pardata.dot.h = ImgFile[0].img.dot.h = ImgFile[1].img.dot.h = PageLength * sc_pardata.dpi.y / 100;
	sc_pardata.acquire = 0;
	if(GetPrivateProfileInt(ScanProfile, "SCAN_WITH_SHADING", 0, IniFile))
		sc_pardata.acquire |= ACQ_SHADING;
	if(GetPrivateProfileInt(ScanProfile, "SCAN_TEST_PATTERN", 0, IniFile))
		sc_pardata.acquire |= ACQ_TEST_PATTERN;
	sc_pardata.duplex = GetPrivateProfileInt(ScanProfile, "SCAN_DUPLEX", 1, IniFile);
	sc_pardata.page = GetPrivateProfileInt(ScanProfile, "SCAN_PAGE", 1, IniFile);

	return TRUE;
}

int Load_MotoPar(int *MotoPar)
{
	char *file;
	GetModuleFileName(NULL, IniFile, sizeof(IniFile));
	strcpy(strrchr(IniFile, '.')+1, "ini");
	GetPrivateProfileString("MOTO", "Profile", NULL, MotoProfile, sizeof(ScanProfile), IniFile);
	if(MotoProfile[0] == NULL)
		return FALSE;
	MotoPar[0] = GetPrivateProfileInt(MotoProfile, "MOTO_STEPS", 1200, IniFile);
	MotoPar[1] = GetPrivateProfileInt(MotoProfile, "MOTO_PPS", 2048, IniFile);
	MotoPar[2] = GetPrivateProfileInt(MotoProfile, "MOTO_DIR", 0, IniFile);
	MotoPar[3] = GetPrivateProfileInt(MotoProfile, "MOTO_ID", 0, IniFile);
	MotoPar[4] = GetPrivateProfileInt(MotoProfile, "MOTO_TYPE", 0x11, IniFile);
	return TRUE;
}

U32 Load_Action()
{
	char *file;
	GetModuleFileName(NULL, IniFile, sizeof(IniFile));
	strcpy(strrchr(IniFile, '.')+1, "ini");
	GetPrivateProfileString("MAIN", "ACTION", NULL, action, sizeof(ScanProfile), IniFile);
	if(action[0] == NULL)
		return FALSE;
	return *(U32*)action;
}