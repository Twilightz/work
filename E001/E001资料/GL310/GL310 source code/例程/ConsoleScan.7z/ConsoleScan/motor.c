#include <windows.h>
#include <stdio.h>
#include <math.h>
#include "usbio.h"
#include "ImgFile.h"
#include "ScanCmd.h"

#define MOTO_STYLE(A)	(0x000000ff & (A))
#define MOTO_DIR(A)		(0x0000ff00 & ((A)<<8))
#define MOTO_ID(A)		(0x00ff0000 & ((A)<<16))
#define MOTO_TYPE(A)	(0xff000000 & ((A)<<24))

int _move(int steps, int style, int dir, int id, int type)
{
	int result;
	unsigned int cmd[4];
	cmd[0] = I4('MOTO');
	cmd[1] = MOTO_STYLE(style)|MOTO_DIR(dir)|MOTO_ID(id)|MOTO_TYPE(type);
	result = CMDIO_BulkWriteEx(0, cmd, 8) &&
			CMDIO_BulkWriteEx(0, &steps, 4) &&
			CMDIO_BulkReadEx(0, &cmd[2], 8) &&
			(cmd[3] == 'A');
	return result;
}

int Load_MotoPar(int *MotoPar);
int move()
{
	int MotoPar[5];
	Load_MotoPar(MotoPar);
	_move(MotoPar[0], MotoPar[1]>>8, MotoPar[2], MotoPar[3], MotoPar[4]);
	return TRUE;
}
