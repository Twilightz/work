#include <windows.h>
#include <stdio.h>
#include "usbio.h"
#include "ImgFile.h"
#include "ScanCmd.h"

int Load_ScanParameter();

#define SCAN_DPI	300			// 200, 300, 600
#define SCAN_SOURCE I3('FLB')	//'FLB', 'ADF'
#define SCAN_FORMAT	I3('JPG')	//'JPG', 'RAW'
#define SCAN_BIT	24			// 8, 16, 24, 48
#define SCAN_OPTION 0
#define SCAN_DUPLEX	1
#define SCAN_PAGE	0			// 0: infinity pages

//-- image file parameter -----------------------------------------------
IMG_FILE_T ImgFile[2] = {
	{{I3('JPG'), 0, SCAN_BIT, 0, {SCAN_DPI,SCAN_DPI}, {0,0}, {864*SCAN_DPI/100, 12*SCAN_DPI}}},
	{{I3('JPG'), 0, SCAN_BIT, 0, {SCAN_DPI,SCAN_DPI}, {0,0}, {864*SCAN_DPI/100, 12*SCAN_DPI}}}
};
char filename[24];
U8	buf[0x100000];

//------------------------------------------------
int JobID;
//-----------------------------------------------
SC_JOB_T		sc_job_create =	{I3('JOB'), 'C'};
SC_JOB_STA_T	job_status;
SC_JOB_T		sc_job_end =	{I3('JOB'), 'E'};
//-----------------------------------------------
SC_PAR_T		sc_par =		{I3('PAR'), sizeof(SC_PAR_DATA_T)};
SC_PAR_DATA_T	sc_pardata =	{SCAN_SOURCE, SCAN_OPTION, 0, SCAN_DUPLEX, SCAN_PAGE, SCAN_FORMAT, 0, SCAN_BIT, 0, {SCAN_DPI,SCAN_DPI}, {0,0}, {864*SCAN_DPI/100, 12*SCAN_DPI}};
SC_PAR_STA_T	par_status;
//-----------------------------------------------
SC_SCAN_T		sc_scan =		{I4('SCAN')};
SC_SCAN_STA_T	scan_status;
//-----------------------------------------------
SC_STOP_T		sc_stop =		{I3('STP')};
SC_STOP_STA_T	stop_status;
//-----------------------------------------------
SC_INFO_T		sc_info =		{I4('INFO')};
SC_INFO_DATA_T	sc_infodata;
//-----------------------------------------------
SC_CNL_T		sc_cancel =		{I3('CNL')};
SC_CNL_STA_T	cancel_status;
//-----------------------------------------------
SC_IMG_T		sc_img =		{I3('IMG')};
SC_IMG_STA_T	img_status;
//-----------------------------------------------
SC_AFE_T		sc_afe = {I3('AFE'), sizeof(SC_AFE_DATA_T), {0,0}};
SC_AFE_DATA_T	sc_afe_data = {{{0x37,0x37,0x37},{0x37,0x37,0x37}}, \
								{{0x80,0x80,0x80},{0x80,0x80,0x80}}, \
								{{0x354,0x3aa,0x21b},{0x354,0x3aa,0x21b}}};
SC_AFE_STA_T	sc_afe_status;
//---------------------------------------------
SC_SHAD_T		sc_shad = {I4('SHAD'), 0, 0};
SC_SHAD_STA_T	sc_shad_status;
//---------------------------------------------
SC_MOTO_T		sc_moto = {I4('MOTO'), 0, 0, 1, 'F'};
SC_MOTO_DATA_T	sc_moto_data = {0, 0};
SC_MOTO_STA_T	sc_moto_status;
//---------------------------------------------

int _JobCreate()
{
	int result;
	result = CMDIO_BulkWriteEx(0, &sc_job_create, sizeof(sc_job_create)) &&
			CMDIO_BulkReadEx(0, &job_status, sizeof(job_status));
	if(!result || job_status.ack == 'E') {
		printf("Job create error (#%d)\n", job_status.err);
		result = 0;
		goto exit_JobCraete;
	}
	JobID = job_status.id;
	printf("Job create OK. ID(%d)\n", JobID);
exit_JobCraete:
	return result;
}
//-----------------------------------------------
int _JobEnd()
{
	int result;
	sc_job_end.id = JobID;
	result = CMDIO_BulkWriteEx(0, &sc_job_end, sizeof(sc_job_end)) &&
			CMDIO_BulkReadEx(0, &job_status, sizeof(job_status));
	if(!result || job_status.ack == 'E' || job_status.id != JobID) {
		printf("Job end error. err(%d), ID(%d)\n", job_status.err, job_status.id);
		result = 0;
		goto exit_JobEnd;
	}
	printf("Job end OK.\n");
exit_JobEnd:
	return result;
}
//-----------------------------------------------
int _parameters()
{
	int result;
	sc_par.id = JobID;
	result = CMDIO_BulkWriteEx(0, &sc_par, sizeof(sc_par)) &&
			CMDIO_BulkWriteEx(0, &sc_pardata, sizeof(sc_pardata)) &&
			CMDIO_BulkReadEx(0, &par_status, sizeof(par_status));
	if(!result || par_status.ack == 'E' || par_status.id != JobID) {
		printf("Set parameter error. err(%d), ID(%d)\n", par_status.err, par_status.id);
		result = 0;
		goto exit_par;
	}
	printf("Set parameter OK.\n");
exit_par:
	return result;
}
//-----------------------------------------------
int _calibration()
{
	int result;
	FILE *file = NULL;
	int size;
	char *data = (char*)buf;
	if(sc_pardata.source == I3('FLB')) {
		switch(sc_pardata.dpi.x)
		{
		case 200: 
			file = fopen("FB_200_calibration.asd","rb");
			break;
		case 300: 
			file = fopen("FB_300_calibration.asd","rb");
			break;
		case 600: 
			file = fopen("FB_600_calibration.asd","rb");
			break;
		case 1200: 
			file = fopen("FB_1200_calibration.asd","rb");
			break;
		}
	}
	else if(sc_pardata.source == I3('ADF')) {
		switch(sc_pardata.dpi.x)
		{
		case 200:
			file = fopen("Duo_200_calibration.asd","rb");
			break;
		case 300: 
			file = fopen("Duo_300_calibration.asd","rb");
			break;
		case 600: 
			file = fopen("Duo_600_calibration.asd","rb");
			break;
		}
	}
	if(file) {
		size = fread((char*)buf, sizeof(char), sizeof(SC_AFE_DATA_T), file);
		if(size == sizeof(SC_AFE_DATA_T))
			data = buf;
	}
	result = CMDIO_BulkWriteEx(0, &sc_afe, sizeof(sc_afe)) &&
			CMDIO_BulkWriteEx(0, data, sizeof(SC_AFE_DATA_T)) &&
			CMDIO_BulkReadEx(0, &sc_afe_status, sizeof(sc_afe_status));
	if(!result || sc_afe_status.ack != 'A') {
		printf("Set AFE error\n");
		result = FALSE;
		goto exit_par;
	}
	printf("Set AFE OK.\n");
exit_par:
	if(file)
		fclose(file);
	return result;
}
//-----------------------------------------------
int _shading()
{
	FILE *file[2] = {NULL, NULL};
	int size[2] = {0, 0};
	int result;
	if(sc_pardata.source == I3('FLB')) {
		switch(sc_pardata.dpi.x)
		{
		case 200: 
			file[0] = fopen("FB_200_shadingdata2.dat","rb");
			break;
		case 300: 
			file[0] = fopen("FB_300_shadingdata2.dat","rb");
			break;
		case 600: 
			file[0] = fopen("FB_600_shadingdata2.dat","rb");
			break;
		case 1200: 
			file[0] = fopen("FB_1200_shadingdata2.dat","rb");
			break;
		}
	}
	else if(sc_pardata.source == I3('ADF')) {
		switch(sc_pardata.dpi.x)
		{
		case 200:
			file[0] = fopen("Duo_200_shadingdata1.dat","rb");
			file[1] = fopen("Duo_200_shadingdata2.dat","rb");
			break;
		case 300: 
			file[0] = fopen("Duo_300_shadingdata1.dat","rb");
			file[1] = fopen("Duo_300_shadingdata2.dat","rb");
			break;
		case 600: 
			file[0] = fopen("Duo_300_shadingdata1.dat","rb");
			file[1] = fopen("Duo_300_shadingdata2.dat","rb");
			break;
		}
	}
	if(sc_pardata.duplex & 1) {
		if(file[0])
			size[0] = fread((char*)&buf[0], sizeof(char), sizeof(buf), file[0]);
		else
			goto exit_shading;
	}
	if(sc_pardata.duplex & 2) {
		if(file[1])
			size[1] = fread((char*)&buf[size[0]], sizeof(char), sizeof(buf)-size[0], file[1]);
		else
			goto exit_shading;
	}
	sc_shad.length = size[0]+size[1];
	result = CMDIO_BulkWriteEx(0, &sc_shad, sizeof(sc_shad)) &&
			CMDIO_BulkWriteEx(0, buf, sc_shad.length) &&
			CMDIO_BulkReadEx(0, &sc_shad_status, sizeof(sc_shad_status));
	if(!result || sc_shad_status.ack == 'E') {
		printf("Set shading data error.\n");
		result = 0;
		goto exit_shading;
	}
	printf("Set shading data OK.\n");
exit_shading:
	if(file[0])
		fclose(file[0]);
	if(file[1])
		fclose(file[1]);
	return TRUE;
}
//-----------------------------------------------
int _StartScan()
{
	int result;
	sc_scan.id = JobID;
	result = CMDIO_BulkWriteEx(0, &sc_scan, sizeof(sc_scan)) &&
			CMDIO_BulkReadEx(0, &scan_status, sizeof(scan_status));
	if(!result || scan_status.ack == 'E' || scan_status.id != JobID) {
		printf("Start scan error. err(%d), ID(%d)\n", scan_status.err, scan_status.id);
		result = 0;
		goto exit_StartScan;
	}
	printf("Start scan OK.\n");
exit_StartScan:
	return result;
}
//-----------------------------------------------
int _stop()
{
	int result;
	sc_stop.id = JobID;
	result = CMDIO_BulkWriteEx(0, &sc_stop, sizeof(sc_stop)) &&
			CMDIO_BulkReadEx(0, &stop_status, sizeof(stop_status));
	if(!result || stop_status.ack == 'E' || stop_status.id != JobID) {
		printf("Stop scan error. err(%d), ID(%d)\n", stop_status.err, stop_status.id);
		result = 0;
		goto exit_stop;
	}
	printf("Stop scan OK.\n");
exit_stop:
	return result;
}
//-----------------------------------------------
int _info()
{
	int result;
	sc_info.id = 0;

	result = CMDIO_BulkWriteEx(0, &sc_info, sizeof(sc_info));
	//Sleep(3);
	result = result && CMDIO_BulkReadEx(0, &sc_infodata, sizeof(sc_infodata));
	if(!result || sc_infodata.CoverOpen || sc_infodata.PaperJam) {
		printf("Scanner error.\n");
		result = 0;
		goto exit_info;
	}
exit_info:
	return result;
}
//-----------------------------------------------
int _cancel()
{
	int result;
	printf("\n\tCancel Scan...");
	sc_cancel.id = JobID;
	result = CMDIO_BulkWriteEx(0, &sc_cancel, sizeof(sc_cancel)) &&
			CMDIO_BulkReadEx(0, &cancel_status, sizeof(cancel_status));
	if(!result || cancel_status.ack == 'E' || cancel_status.id != JobID) {
		printf("Fail\n");
		result = 0;
		goto exit_cancel;
	}
	printf("OK\n");
exit_cancel:
	return result;
}
//-----------------------------------------------
int _ReadImage(int dup, int *ImgSize)
{
	int result;
	
	sc_img.side = dup;
	sc_img.length = sc_infodata.ValidPageSize[dup];
	if(sizeof(buf) < sc_infodata.ValidPageSize[dup]) {
		sc_img.length = sizeof(buf);
	}

	result = CMDIO_BulkWriteEx(0, &sc_img, sizeof(sc_img)) &&
			CMDIO_BulkReadEx(0, &img_status, sizeof(img_status));
	if(!result || img_status.ack == 'E') {
		printf("Get image status error.\n");
		result = 0;
		return FALSE;
	}
	result = CMDIO_BulkReadEx(0, buf, img_status.length);
	if(!result) {
		printf("Get image data error.\n");
		result = 0;
		return FALSE;
	} 
	*ImgSize = img_status.length;
	printf("%c", 'A'+dup);
	return result;
}
//-------------------------------------------------

//HL modify


int MY_Load_Shading_first()
{
	FILE *fp;
	errno_t err;
	int numread, bRet;
	unsigned int ic, data, fAddr=0x03ff0000;
	unsigned int filelen, Wx=2592;
	char filename[]="shadingdata_3001.dat";
	unsigned char *fdata;


	//bRet=CMDIO_OpenDevice();
	//if(!bRet) {
	//	printf("......Device not found !\n");
	//	return False;
	//}

	CMDASIC_ReadBus(fAddr, &data);
	if (data==89131888)
		return 1;


	filelen=Wx*2*3;

	if( (err = fopen_s( &fp, filename,"rb" )) != 0 ) {
		printf("......shding file open error, default shading data used !!!\n");
		return 0;
	}

	fdata = (unsigned char*)malloc(filelen);
	numread = fread((char*)fdata, sizeof(char),filelen,fp);
	if(numread!=filelen) {
		printf("......shding file read error!!!\n");
		free(fdata); 	fclose(fp);
		return 0;
	}
	fclose(fp);


	CMDASIC_WriteBus(fAddr, 89131888); //first 4byte = verify data
	CMDASIC_WriteBus(fAddr+4, Wx);     //second 4byte = width
	for (ic=0; ic<filelen; ic=ic+4) {
		data=*((unsigned int*)(fdata+ic));
		CMDASIC_WriteBus(fAddr+8+ic, data);
	}

	free(fdata);

	//CMDIO_CloseDevice();
	//if(!bRet)
	//	printf("......Test Error !!\n");

	printf("......shading data write ok  !!\n");

	return 1;

}












//-------------------------------------------------

int scan()
{
	int result=0;
	int end_page[2], end_doc;
	int duplex=3, dup=0;
	int page[2], page_line[2];
	int ImgSize;
	int time;
	int new_page[2];

//HL modify
//add
	//MY_Load_Shading_first();


	Load_ScanParameter();

	if(!_JobCreate())
		goto l_EXIT;
	if(!_parameters())
		goto l_EXIT;
	
//HL modify
//remove
	//if((sc_pardata.acquire & ACQ_SHADING) && (!_calibration() || !_shading()))
	//	goto l_EXIT;


	if(!_StartScan())
		goto l_JOB_END;
	time = GetTickCount();
	duplex = sc_pardata.duplex;
	page[0] = page[1] = 0;

l_OpenImgFile:
	end_page[0] = end_page[1] = end_doc = 0;
	page_line[0] = page_line[1] = 0;
	new_page[0] = new_page[1] = 1;
#if 0
	if(duplex & 1) {
		sprintf(buf, "%c%d%c_A%02d.%s", (sc_pardata.source==I3('ADF'))?'A':'F', ImgFile[0].img.dpi.x, (ImgFile[0].img.bit > 16)?'C':'G', page[0], &ImgFile[0].img.format);
		printf("Open file %s\n", buf);
		ImgFile_Open(&ImgFile[0], buf);
	}
	if(duplex & 2) {
		sprintf(buf, "%c%d%c_B%02d.%s", (sc_pardata.source==I3('ADF'))?'A':'F', ImgFile[1].img.dpi.x, (ImgFile[1].img.bit > 16)? 'C':'G', page[1], &ImgFile[1].img.format);
		printf("Open file %s\n", buf);
		ImgFile_Open(&ImgFile[1], buf);
	}
#endif
l_Info:
	result = _info();
	if(!result)
		goto l_CloseImgFile;
	if(_kbhit()) {
		_getch();
		_cancel();
		result = FALSE;
		goto l_CloseImgFile;
	}

	if((duplex & 1) && (end_page[0] == 0)) {
		dup = 0;
		ImgSize = 0;
		if(sc_infodata.ValidPageSize[dup] > 0) {
			if(new_page[0]) {
				new_page[0] = 0;
				sprintf(buf, "%c%d%c_A%02d.%s", (sc_pardata.source==I3('ADF'))?'A':'F', ImgFile[0].img.dpi.x, (ImgFile[0].img.bit > 16)?'C':'G', page[0], &ImgFile[0].img.format);
				printf("Open file %s\n", buf);
				ImgFile_Open(&ImgFile[0], buf);
			}
			result = _ReadImage(dup, &ImgSize) &&
					ImgFile_Write(&ImgFile[dup], buf, ImgSize);
			if(!result)
				goto l_CloseImgFile;
			
		}
		if(ImgSize >= sc_infodata.ValidPageSize[dup]) {
			end_page[dup] = sc_infodata.EndPage[dup];
			if((page_line[dup] == 0) && end_page[dup])
				page_line[dup] = sc_infodata.ImageLength[dup];
		}
	}
	if((duplex & 2) && (end_page[1] == 0)) {
		dup = 1;
		ImgSize = 0;
		if(sc_infodata.ValidPageSize[dup] > 0) {
			if(new_page[1]) {
				new_page[1] = 0;
				sprintf(buf, "%c%d%c_B%02d.%s", (sc_pardata.source==I3('ADF'))?'A':'F', ImgFile[1].img.dpi.x, (ImgFile[1].img.bit > 16)? 'C':'G', page[1], &ImgFile[1].img.format);
				printf("Open file %s\n", buf);
				ImgFile_Open(&ImgFile[1], buf);
			}
			result = _ReadImage(dup, &ImgSize) &&
					ImgFile_Write(&ImgFile[dup], buf, ImgSize);
			if(!result)
				goto l_CloseImgFile;			
		}
		if(ImgSize >= sc_infodata.ValidPageSize[dup]) {
			end_page[dup] = sc_infodata.EndPage[dup];
			if((page_line[dup] == 0) && end_page[dup])
				page_line[dup] = sc_infodata.ImageLength[dup];
		}
	}
	// Jason(141024) to receive the document_end message for crop scan endless loop error
	if(result && !sc_infodata.EndDocument && (((duplex & 1) && (end_page[0] == 0)) || ((duplex & 2) && (end_page[1] == 0))))
		goto l_Info;
	//if((!(duplex & 1) || end_page[0]) &&  (!(duplex & 2) || end_page[1]))
		end_doc = sc_infodata.EndDocument;
l_CloseImgFile:
	if(duplex & 1) {
		ImgFile_Close(&ImgFile[0], page_line[0]);
		page[0]++;
	}
	if(duplex & 2) {
		ImgFile_Close(&ImgFile[1], page_line[1]);
		page[1]++;
	}
	printf("\n");
	if(result && (end_doc == 0)) // && sc_infodata.EndDocument == 0)
		goto l_OpenImgFile;
	time = GetTickCount() - time;
	_stop();

l_JOB_END:
	_JobEnd();
l_EXIT:
	printf("Total %d ms for %d pages\n", time, page[0]);
	return result;
}
