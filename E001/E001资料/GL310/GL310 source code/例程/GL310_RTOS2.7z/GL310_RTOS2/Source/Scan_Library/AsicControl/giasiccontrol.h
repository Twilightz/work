////////////////////////////////////////////////////////////////
// File - giasiccontrol.h
// Copyright (c) 2011 - Genesys Logic, INC.
//
// define the export function and global variable for giafe.c, 
// gidevice.c, giimage.c, gilamp.c, gimotor.c, gisensor.c, giadf,c
//
////////////////////////////////////////////////////////////////

#ifndef _giasiccontrol_h
#define _giasiccontrol_h

extern RegRec CMDASIC_RegTable[MAX_SCAN_REGISTERS];

extern int Sensor_type;  //0=1CH CIS,  1=3CH CIS,  2=CCD
extern int BENG_Active;

//**************  DEVICE
//*********************************************************
extern float CtlDevice_PixelTime;
int CtlDevice_OpenDevice(void);
int CtlDevice_CloseDevice(void);
int CtlDevice_LoadInitRegData(void);
int CtlDevice_SetScannerClock(unsigned char iScanClk);
int CtlDevice_SetScanMOD(unsigned char iclkpl);


//**************  AFE
//*********************************************************
int CtlAfe_WriteAFERegister(unsigned short wAddr, unsigned short wData);
int CtlAfe_ReadAFERegister(unsigned short wAddr, unsigned short *pData);
int CtlAfe_SetAFEGain(unsigned short GainR, unsigned short GainG, unsigned short GainB);
int CtlAfe_SetAFEGain_B(unsigned short GainR, unsigned short GainG, unsigned short GainB);
int CtlAfe_SetAFEOffset(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB);
int CtlAfe_SetAFEOffset_B(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB);
//int CtlAfe_GetGainLevel(int type, unsigned short code);
int CtlAfe_GetGainLevel(int type, int code, float *value);
int CtlAfe_GetGainCode(int type, float value, int *code);
int CtlAfe_WriteAFERegister_B(unsigned short wAddr, unsigned short wData);
int CtlAfe_ReadAFERegister_B(unsigned short wAddr, unsigned short *pData);



//**************  MOTOR
//*********************************************************
int CtlMotor_MotorTable_setting(ScanParameter *pSPM);
int CtlMotor_SetMotorStartMove(void);
int CtlMotor_SetMotorPowerBit(unsigned char bOnOff);
int CtlMotor_EnableAutoGoHome(unsigned char State);
int CtlMotor_SetMotorDirect(unsigned char iDir);
int CtlMotor_SetScanTableUnit(int n);
int CtlMotor_SetFastTableUnit(int n);
int CtlMotor_SetTBTime(unsigned char t);
int CtlMotor_EnableFastMove(unsigned char State);
int CtlMotor_SetFeedSteps(unsigned int dwFStep);
int CtlMotor_SetStartStop(unsigned char bOnOff);
int CtlMotor_EnableLongCurve(unsigned char State);
int CtlMotor_SetMotorVref(unsigned char VRScan, unsigned char VRBack, unsigned char VRMove, unsigned char VRhome, unsigned char VRStop);
int CtlMotor_WaitMotorStop(void);
int CtlMotor_WriteFastSlopeTable(unsigned short *SlopeTbl, int iLen);
int CtlMotor_WriteScanSlopeTable(unsigned short *SlopeTbl, int iLen);
int CtlMotor_LoadPPSCurveToFastTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int *retstep);
int CtlMotor_LoadPPSCurveToScanTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int *retstep);
int CtlMotor_CalculateTableSum(unsigned short *SlopeTbl, int iLen);
int CtlMotor_SetZ1Z2Value(void);
int CtlMotor_WriteMotorRemainder(unsigned int z1, unsigned int z2);
int CtlMotor_CalculateFeedReg(unsigned int ScanBeginLine);

int CtlMotor_LDMWriteOne(unsigned short addr, unsigned char data);
int CtlMotor_LDMReadOne(unsigned short addr, unsigned char *data);
int CtlMotor_LDMWriteMulti(unsigned short addr, unsigned char *pData, unsigned short iLen);
int CtlMotor_LDMReadMulti(unsigned short addr, unsigned char *pData, unsigned short iLen);
int CtlMotor_SetMotorCurrent(int CUR1,  int CUR2); //20140521

//**************  IMAGE
//*********************************************************
extern unsigned int CtlImage_ShadingBase; //digital shading gain = 8 times system -> 0x2000, 4 time system -> 0x4000
int CtlImage_EnableShading(unsigned char bEn);
int CtlImage_EnableGamma(unsigned char bEn);
int CtlImage_ClrCounter(void);
int CtlImage_EnablePattern(unsigned char bEn);

int CtlImage_SetDefaultShading32_1CH(void);
int CtlImage_SetDefaultShading32_3CH(void);
int CtlImage_SetDefaultShading32_CCD(void);
int CtlImage_SetDefaultShading16_1CH(void);
int CtlImage_SetDefaultShading16_3CH(void);
int CtlImage_SetDefaultShading16_CCD(void);

int CtlImage_SetDefaultGamma(int flag);
int CtlImage_EnableScan(unsigned char bEnable);
int CtlImage_EnableASICWatchDog(unsigned char bEn);
int CtlImage_SetASICWatchTime(unsigned int sec);
int CtlImage_SetColorDepth(int iPixelBits, unsigned char Channel);
int CtlImage_RamSet_ShadingBank();
int CtlImage_RamSet_ImageBuffer(ScanParameter *pSPM);

int CtlImage_CMatrix_Default(ScanParameter *pSPM);
int CtlImage_TrueGray_Matrix(ScanParameter *pSPM);
int CtlImage_TrueGray_CISLED(ScanParameter *pSPM);

int CtlImage_Shading_AfterLoad(ScanParameter *pSPM);

//**************  SENSOR
//*********************************************************
extern unsigned int CtlSensor_wTGPeriod;
extern unsigned int CtlSensor_iOptRes;

int CtlSensor_LperiodSet(ScanParameter *pSPM);
int CtlSensor_XResSet(ScanParameter *pSPM);
int CtlSensor_YResSet(ScanParameter *pSPM);
int CtlSensor_SetDPIHW(unsigned int Res);

int CtlSensor_SetDummyPixel(void);
int CtlSensor_SetDummyLine(unsigned char n);



//**************  ADF
//*********************************************************
int CtlADF_ADFInit(void);
int CtlADF_DetectADFConnect(int *pADF);
int CtlADF_GetDocumentSensor(int *pDocSensor);
int CtlADF_GetADFSensor(int *pADFSensor);
int Api_CtlADF_ADFMotorOpen(void);
int CtlADF_ADFMotorOpen(void);
int CtlADF_ADFMotorClose(void);
int CtlADF_SetADFSEL(unsigned char bEnable);
int CtlADF_CheckPaperJam(int *jam);
int CtlADF_GetADFScNum(ScanParameter *pSPM, unsigned short *scnum);
int CtlADF_ADFsetting(ScanParameter *pSPM);
int CtlDevice_OpPanelKey(void);


int JPG_setting(ScanParameter *pSPM);

int BENG_Init_WriteDirect(void);
int BENG_setting(ScanParameter *pSPM);

#endif // _giasiccontrol_h
