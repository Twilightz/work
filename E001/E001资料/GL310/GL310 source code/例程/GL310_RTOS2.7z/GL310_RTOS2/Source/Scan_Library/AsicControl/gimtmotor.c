////////////////////////////////////////////////////////////////
// File - gimtmotor.
// Copyright (c) 2013 - Genesys Logic, INC.
//
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"
#include "gimtmotor.h"


int MultiMotorSet(int para1)
{
	unsigned short tlen;

	memset((unsigned char *)M0Tin0Ci_Wt,0x00,sizeof(M0Tin0Ci_Wt));
	memset((unsigned char *)M0Tin1Ci_Wt,0x00,sizeof(M0Tin1Ci_Wt));
	memset((unsigned char *)M0Tin2Ci_Wt,0x00,sizeof(M0Tin2Ci_Wt));
	memset((unsigned char *)M1Tin0Ci_Wt,0x00,sizeof(M1Tin0Ci_Wt));
	memset((unsigned char *)M1Tin1Ci_Wt,0x00,sizeof(M1Tin1Ci_Wt));
	memset((unsigned char *)M1Tin2Ci_Wt,0x00,sizeof(M1Tin2Ci_Wt));
	memset((unsigned char *)M2Tin0Ci_Wt,0x00,sizeof(M2Tin0Ci_Wt));
	memset((unsigned char *)M2Tin1Ci_Wt,0x00,sizeof(M2Tin1Ci_Wt));
	memset((unsigned char *)M2Tin2Ci_Wt,0x00,sizeof(M2Tin2Ci_Wt));

	memset((unsigned char *)&M0State_Wt,0x00,sizeof(M0State_Wt));
	memset((unsigned char *)&M1State_Wt,0x00,sizeof(M1State_Wt));
	memset((unsigned char *)&M2State_Wt,0x00,sizeof(M2State_Wt));
	memset((unsigned char *)&ScanTin_Wt,0x00,sizeof(ScanTin_Wt));
	memset((unsigned char *)&ScanState_Wt,0x00,sizeof(ScanState_Wt));
	memset((unsigned char *)&STSAsign_Wt,0x00,sizeof(STSAsign_Wt));
	memset((unsigned char *)&MtrStopTgr_Wt,0x00,sizeof(MtrStopTgr_Wt));


	CMDASIC_WriteRegister(0x0196, 0x02);  //MotorEn

	//my test
	M1State_Wt.CaseCycle = 1;
	M1State_Wt.CycleEn = 1;
	M1State_Wt.CycleLmt = 0xffff;

	M1State_Wt.CaseN0 = 1;
	M1State_Wt.PowerEn0 = 1;
	M1State_Wt.In0FedLmt = 0xffffff;
	M1Tin1Ci_Wt[0].FedStepA = 0xfffff0;  //trigger Tout0
	M1Tin1Ci_Wt[0].FedStepB = 0xfffff0;  //trigger Tout1
	//M1Tin1Ci_Wt[1].FedStepA = 0xfffff0;  
	//M1Tin1Ci_Wt[1].FedStepB = 0xfffff0; 
	//M1Tin1Ci_Wt[2].FedStepA = 0xfffff0;  
	//M1Tin1Ci_Wt[2].FedStepB = 0xfffff0; 

	M1Tin0Ci_Wt[0].TinLoopCtl = 1;
	M1Tin0Ci_Wt[0].LoopLmt = 0xffff;
	M1Tin0Ci_Wt[0].AccelTb = 0;
	M1Tin0Ci_Wt[0].AccelNo = para1; //52;
	//M1Tin0Ci_Wt[1].TinLoopCtl = 1;
	//M1Tin0Ci_Wt[1].LoopLmt = 0xffff;
	//M1Tin0Ci_Wt[1].AccelTb = 0;
	//M1Tin0Ci_Wt[1].AccelNo = para1; //52;
	//M1Tin0Ci_Wt[2].TinLoopCtl = 1;
	//M1Tin0Ci_Wt[2].LoopLmt = 0xffff;
	//M1Tin0Ci_Wt[2].AccelTb = 0;
	//M1Tin0Ci_Wt[2].AccelNo = para1; //52;


	STSAsign_Wt.GPOBSigDCNo = 0x0E;
	STSAsign_Wt.GPOSigSel = 0x05;
	CMDASIC_WriteRegisterBit(0x0060,1,1,1);  //gpo2_gpobt=1
	CMDASIC_WriteRegisterBit(0x0058,1,1,1);  //GPOE2=1
	M1Tin0Ci_Wt[0].MskSnr0 = 1;
	//M1Tin0Ci_Wt[1].MskSnr0 = 1;
	//M1Tin0Ci_Wt[2].MskSnr0 = 1;
	STSAsign_Wt.Snr0No = 1; //GPIO2

	STSAsign_Wt.GPOASigDCNo = 0x0C;
	STSAsign_Wt.GPOSigSel = 0x05;
	CMDASIC_WriteRegisterBit(0x0060,0,1,1);  //gpo1_gpoat=1
	CMDASIC_WriteRegisterBit(0x0058,0,1,1);  //GPOE1=1
	MtrStopTgr_Wt.M1MskSnrStop0 = 1;
	STSAsign_Wt.SnrStop0No = 0;  //GPIO1



	M1Tin1Ci_Wt[0].MskStatus0 = 1;
	STSAsign_Wt.Status0No = 8;

	CMDASIC_WriteRegister(0x0199, 0x02);  //motor1mod 

	CMDASIC_WriteFourRegister(0x0508, 0x04000000);  //MTR1SET franky


	CMDASIC_WriteFourRegister(0x0558, 0x09003fff); //MTR2_ENB MTR2SET
	//GPIO42  MOTOR STEP
	CMDASIC_WriteRegisterBit(0x0066,4,1,1); 
	CMDASIC_WriteRegisterBit(0x005d,1,1,1); 
	//CMDASIC_WriteRegisterBit(0x0055,1,1,1); 

	//GPIO38  MOTOR DIR
	CMDASIC_WriteRegisterBit(0x0065,4,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,5,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,5,1,0); 

	//GPIO40  MOTOR MS1
	CMDASIC_WriteRegisterBit(0x0066,0,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,7,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,7,1,0); 

	//GPIO39  MOTOR MS2
	CMDASIC_WriteRegisterBit(0x0065,6,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,6,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,6,1,1); 

	//GPIO35  MOTOR CUR SW1
	CMDASIC_WriteRegisterBit(0x0064,6,2,0); 
	CMDASIC_WriteRegisterBit(0x0065,0,1,0);
	CMDASIC_WriteRegisterBit(0x005c,2,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,2,1,0); 

	//GPIO36  MOTOR CUR SW2
	CMDASIC_WriteRegisterBit(0x0065,1,1,0);
	CMDASIC_WriteRegisterBit(0x005c,3,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,3,1,0); 

#if 0

	CMDASIC_WriteRegister(0x0196, 0x02);  //MotorEn

	M1State_Wt.CaseN0 = 1;
	M1State_Wt.PowerEn0 = 1;
	M1State_Wt.In0FedLmt = 0xffffff;
	M1Tin1Ci_Wt[0].FedStepA = 0xfffff0;  //trigger Tout0
	M1Tin1Ci_Wt[0].FedStepB = 0xfffff0;  //trigger Tout1

	M1Tin0Ci_Wt[0].TinLoopCtl = 1;
	M1Tin0Ci_Wt[0].LoopLmt = 0xffff;
	M1Tin0Ci_Wt[0].AccelTb = 0;
	M1Tin0Ci_Wt[0].AccelNo = para1; //52;

	M1Tin0Ci_Wt[0].MskSnr0 = 1;
	STSAsign_Wt.Snr0No = 1; //GPIO2
	STSAsign_Wt.GPOBSigDCNo = 0x0E;
	STSAsign_Wt.GPOSigSel = 0x05;
	CMDASIC_WriteRegisterBit(0x0060,1,1,1);  //gpo2_gpobt=1
	CMDASIC_WriteRegisterBit(0x0058,1,1,1);  //GPOE2=1


	MtrStopTgr_Wt.M1MskSnrStop0 = 1;
	STSAsign_Wt.SnrStop0No = 0;  //GPIO1
	STSAsign_Wt.GPOASigDCNo = 0x0C;
	STSAsign_Wt.GPOSigSel = 0x05;
	CMDASIC_WriteRegisterBit(0x0060,0,1,1);  //gpo1_gpoat=1
	CMDASIC_WriteRegisterBit(0x0058,0,1,1);  //GPOE1=1



	M1Tin1Ci_Wt[0].MskStatus0 = 1;
	STSAsign_Wt.Status0No = 8;

	CMDASIC_WriteRegister(0x0199, 0x02);  //motor1mod 


	//GPIO42  MOTOR STEP
	CMDASIC_WriteRegisterBit(0x0066,4,1,0); 
	CMDASIC_WriteRegisterBit(0x005d,1,1,1); 
	//CMDASIC_WriteRegisterBit(0x0055,1,1,1); 

	//GPIO38  MOTOR DIR
	CMDASIC_WriteRegisterBit(0x0065,4,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,5,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,5,1,1); 

	//GPIO40  MOTOR MS1
	CMDASIC_WriteRegisterBit(0x0066,0,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,7,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,7,1,1); 

	//GPIO39  MOTOR MS2
	CMDASIC_WriteRegisterBit(0x0065,6,2,0); 
	CMDASIC_WriteRegisterBit(0x005c,6,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,6,1,1); 

	//GPIO35  MOTOR CUR SW1
	CMDASIC_WriteRegisterBit(0x0064,6,2,0); 
	CMDASIC_WriteRegisterBit(0x0065,0,1,0);
	CMDASIC_WriteRegisterBit(0x005c,2,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,2,1,0); 

	//GPIO36  MOTOR CUR SW2
	CMDASIC_WriteRegisterBit(0x0065,1,1,0);
	CMDASIC_WriteRegisterBit(0x005c,3,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,3,1,0); 

#endif

	//STSAsign_Wt.GPOASigDCNo=10;
	//STSAsign_Wt.GPOBSigDCNo=12;
	//STSAsign_Wt.GPOSigSel=3;

	//M0State_Wt.CaseCycle = 1;
	//M0State_Wt.CycleEn = 1;
	//M0State_Wt.StepTp0 = 1;
	//M0State_Wt.Dir0 = 0;
	//M0State_Wt.EnToutN0 = 0;
	//M0State_Wt.PowerEn0 = 1;

	//M0Tin0Ci_Wt[0].AccelTb = 0;
	//M0Tin0Ci_Wt[0].AccelNo = 1000;  //52;
	//M0Tin0Ci_Wt[0].FedStep = 160000;




	///////////////////////////////////////////////////////////////////

	CtlMotor_LDMWriteMulti(0x0000, (unsigned char *)&M0Tin0Ci_Wt, 88);
	CtlMotor_LDMWriteMulti(0x0080, (unsigned char *)&M0Tin1Ci_Wt, 68);
	CtlMotor_LDMWriteMulti(0x0100, (unsigned char *)&M0Tin2Ci_Wt, 36);

	CtlMotor_LDMWriteMulti(0x0180, (unsigned char *)&M1Tin0Ci_Wt, 88);
	CtlMotor_LDMWriteMulti(0x0200, (unsigned char *)&M1Tin1Ci_Wt, 68);
	CtlMotor_LDMWriteMulti(0x0280, (unsigned char *)&M1Tin2Ci_Wt, 36);

	CtlMotor_LDMWriteMulti(0x0300, (unsigned char *)&M2Tin0Ci_Wt, 84);
	CtlMotor_LDMWriteMulti(0x0380, (unsigned char *)&M2Tin1Ci_Wt, 68);
	CtlMotor_LDMWriteMulti(0x0400, (unsigned char *)&M2Tin2Ci_Wt, 36);

	 	CtlMotor_LDMReadMulti(0x0000, (unsigned char *)&M0Tin0Ci_Rd, 88);
		CtlMotor_LDMReadMulti(0x0080, (unsigned char *)&M0Tin1Ci_Rd, 68);
		CtlMotor_LDMReadMulti(0x0100, (unsigned char *)&M0Tin2Ci_Rd, 36);

		CtlMotor_LDMReadMulti(0x0180, (unsigned char *)&M1Tin0Ci_Rd, 84);
		CtlMotor_LDMReadMulti(0x0200, (unsigned char *)&M1Tin1Ci_Rd, 68);
		CtlMotor_LDMReadMulti(0x0280, (unsigned char *)&M1Tin2Ci_Rd, 36);

		CtlMotor_LDMReadMulti(0x0300, (unsigned char *)&M2Tin0Ci_Rd, 84);
		CtlMotor_LDMReadMulti(0x0380, (unsigned char *)&M2Tin1Ci_Rd, 68);
		CtlMotor_LDMReadMulti(0x0400, (unsigned char *)&M2Tin2Ci_Rd, 36);



	CtlMotor_LDMWriteMulti(0x0440, (unsigned char *)&M0State_Wt, 39);
	CtlMotor_LDMWriteMulti(0x0480, (unsigned char *)&M1State_Wt, 39);
	CtlMotor_LDMWriteMulti(0x04C0, (unsigned char *)&M2State_Wt, 39);
		CtlMotor_LDMReadMulti(0x0440, (unsigned char *)&M0State_Rd, 39);
		CtlMotor_LDMReadMulti(0x0480, (unsigned char *)&M1State_Rd, 39);
		CtlMotor_LDMReadMulti(0x04C0, (unsigned char *)&M2State_Rd, 39);



	CtlMotor_LDMWriteMulti(0x0500, (unsigned char *)&ScanTin_Wt, 23);
		CtlMotor_LDMReadMulti(0x0500, (unsigned char *)&ScanTin_Rd, 23);

	CtlMotor_LDMWriteMulti(0x0520, (unsigned char *)&ScanState_Wt, 14);
		CtlMotor_LDMReadMulti(0x0520, (unsigned char *)&ScanState_Rd, 14);

	CtlMotor_LDMWriteMulti(0x0540, (unsigned char *)&STSAsign_Wt, 32);
		CtlMotor_LDMReadMulti(0x0540, (unsigned char *)&STSAsign_Rd, 32);

	CtlMotor_LDMWriteMulti(0x0560, (unsigned char *)&MtrStopTgr_Wt, 21);
		CtlMotor_LDMReadMulti(0x0560, (unsigned char *)&MtrStopTgr_Rd, 21);


#if 0

	CtlMotor_SetMotorPowerBit(1);

	CMDASIC_WriteFourRegister(0x0048, 0x0c003fff); //MTR_ENB MTRSET
	CMDASIC_WriteFourRegister(0x0508, 0x0a003fff); //MTR1_ENB MTR1SET
	CMDASIC_WriteFourRegister(0x0558, 0x09003fff); //MTR2_ENB MTR2SET

	//CMDASIC_WriteFourRegister(0x000c, 0x0000003f);  //clear

	//CtlMotor_LDMReadMulti(0x0580, (unsigned char *)&FlowData_Rd, 30);
	CMDASIC_WriteRegister(0x0196, 0x1f); //0x1f);  //multimotor motoren
	CMDASIC_WriteRegister(0x0198, 0x01);  //motor0mod   
	CMDASIC_WriteRegister(0x0199, 0x02);  //motor1mod   s m2 m1 m0
	CMDASIC_WriteRegister(0x019a, 0x04);  //motor2mod   s m2 m1 m0

	//CMDASIC_WriteFourRegister(0x0190,0x00000006); //STRCMD1 STRCMD2

	//CtlMotor_SetMotorStartMove();

#endif


	return True;


}

