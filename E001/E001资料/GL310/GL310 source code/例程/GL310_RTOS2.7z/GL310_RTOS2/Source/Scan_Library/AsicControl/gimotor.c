////////////////////////////////////////////////////////////////
// File - gimotor.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"
#include "input_ini.h"

int m_iScanTableUnit, m_iFastTableUnit;
unsigned char CtlMotor_nTBtime;
unsigned char ADF_MOTOR_Flag = 0;

extern int MotorGear;
extern int ADFMotorGear;
extern int ScanTBunit;
extern int FastTBunit;
extern float FastTBPPS;
extern MotorTableCfg MotorTableSet[];
extern int PowerOnBACK;
//extern int Duplex_Calibration;
extern int DuplexscanFlag;
extern unsigned char DoCalibrationFlag;
//extern unsigned int MonoScanFlag;	// defined in main.c, used in main_adftest.c
extern float mt1_pps;
extern int adf_cur1;
extern int adf_cur2;
extern int fb_cur1;
extern int fb_cur2;


//unsigned int
//	m_w01SlopeTblAddr = memuse_start, 
//	m_w02SlopeTblAddr = memuse_start+0x20000, 
//	m_w03SlopeTblAddr = memuse_start+0x40000, 
//	m_w04SlopeTblAddr = memuse_start+0x60000, 
//	m_w05SlopeTblAddr = memuse_start+0x80000;
unsigned int m_w01SlopeTblAddr, m_w02SlopeTblAddr, m_w03SlopeTblAddr, m_w04SlopeTblAddr, m_w05SlopeTblAddr;


unsigned int m_iTableSum=0, m_iTableHigh=0;
extern unsigned char CtlSensor_nStepPerLine;

int StepTim=4; 
int maxMotorStep=8192;

extern int MultiMotorSet(int para1);
extern int My_LoadPPSCurveToMultiTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int Vref, int *retstep);


int CtlMotor_SetMotorStartMove(void)
{
	return CMDASIC_WriteFourRegister(0x000c,0x01000500);
}


int CtlMotor_SetMotorPowerBit(unsigned char bOnOff)
{
	return CMDASIC_WriteRegisterBit(0x0002, 4, 1, bOnOff);
}


int CtlMotor_EnableAutoGoHome(unsigned char State)
{
	return CMDASIC_WriteRegisterBit(0x0002, 5, 1, State);
}


int CtlMotor_SetMotorDirect(unsigned char iDir)
{
	return CMDASIC_WriteRegisterBit(0x0002, 2, 1, (unsigned char)(iDir ? 0 : 1));
}

int CtlADFMotor_SetMotorDirect(unsigned char iDir)
{
	//GPIO42 is ADF MOTOR DIR
	CMDASIC_WriteRegisterBit(0x0066,4,1,0); 
	CMDASIC_WriteRegisterBit(0x005d,1,1,1); 
	CMDASIC_WriteRegisterBit(0x0055,1,1, (unsigned char)(iDir ? 0 : 1)); 

	return True; 
}

int CtlMotor_SetScanTableUnit(int n)
{
   unsigned char tt=1;

	switch(n){
		case 1:
			tt = 0;
			printf("Scan Motor Step = Full step\n");
			break;
		case 2:
			tt = 1;
			printf("Scan Motor Step = Half step\n");
			break;
		case 4:
			tt = 2;
			printf("Scan Motor Step = Quarter step\n");
			break;
		case 8:
			tt = 3;
			printf("Scan Motor Step = Eighth step\n");
			break;
		default:
			tt =1;
			printf("Scan Motor Step = Quarter step\n");
			break;
	}
	m_iScanTableUnit = n;

//HL modify
#if 0
	if(ADF_MOTOR_Flag){
		CMDASIC_WriteRegisterBit(0x0060,1,1,0); 
		CMDASIC_WriteRegisterBit(0x0050,1,2,tt); 
		CMDASIC_WriteRegisterBit(0x0058,1,2,3); 
	}
#endif	
	return CMDASIC_WriteRegisterBit(0x003C, 0, 3, tt);

}



int CtlMotor_SetFastTableUnit(int n)
{
   unsigned char tt=1;

	switch(n){
		case 1:
			tt = 0;
			break;
		case 2:
			tt = 1;
			break;
		case 4:
			tt = 2;
			break;
		case 8:
			tt = 3;
			break;
	}
	m_iFastTableUnit = n;
	return CMDASIC_WriteRegisterBit(0x003D, 0, 3, tt);

}


int CtlMotor_SetTBTime(unsigned char t)
{
	unsigned char tt=1;
	switch(t){
			case 1:
				tt = 0;
				break;
			case 2:
				tt = 1;
				break;
			case 4:
				tt = 2;
				break;
			case 8:
				tt = 3;
				break;
			case 16:
				tt = 4;
				break;
			case 32:
				tt = 5;
				break;
			default:
				tt = 0;
				break;
	}
	CtlMotor_nTBtime = t;
	return CMDASIC_WriteRegisterBit(0x0010,4,3,tt); 
}



int CtlMotor_SetFeedSteps(unsigned int dwFStep)
{
   unsigned int dwData;
   dwData = dwFStep & 0x00ffffff;
   return CMDASIC_WriteFourRegister(0x0170,dwData);
}


int CtlMotor_SetStartStop(unsigned char bOnOff)
{
	return CMDASIC_WriteRegisterBit(0x0002, 6, 1, (unsigned char)(bOnOff ? 0 : 1));
}


int CtlMotor_EnableFastMove(unsigned char State)
{
	return CMDASIC_WriteRegisterBit(0x0002, 3, 1, State);
}


int CtlMotor_EnableLongCurve(unsigned char State)
{
	return CMDASIC_WriteRegisterBit(0x0002, 0, 1, State);
}

int CtlMotor_SetMotorVref(unsigned char VRScan, unsigned char VRBack, unsigned char VRMove, unsigned char VRhome, unsigned char VRStop)
{
	unsigned int nVal;
	int bRet=1;

	bRet=CMDASIC_ReadFourRegister(0x0030,&nVal);
	if (!bRet)	return False;

	nVal &= 0xfff00000;
	nVal |= (unsigned int)VRScan;
	nVal |= ((unsigned int)VRBack << 4);
	nVal |= ((unsigned int)VRMove << 8);
	nVal |= ((unsigned int)VRhome << 12);
	nVal |= ((unsigned int)VRStop << 16);

	return CMDASIC_WriteFourRegister(0x0030,nVal);

}


int CtlMotor_WaitMotorStop(void)
{
	int bRet=1;
	unsigned char nVal;
	unsigned int dwStart;

	dwStart = gettickcount();
	while (-1){
		nVal=0x00;
		if (CMDASIC_ReadRegister(0x0401,&nVal) ) {
			if ( (nVal & 0x01) ) {
				if( gettickcount() - dwStart >= 60000) {
					bRet=False;
					break;
				}
				continue;
			} else {
				bRet=True;
				break;
			}
		} else {
			bRet=False;
			break;
		}
	}
	return bRet;
}


int CtlMotor_WriteFastSlopeTable(unsigned short *SlopeTbl, int iLen)
{
	int bRet=1;


	bRet=CMDASIC_WriteBulkData(m_w04SlopeTblAddr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;
	bRet=CMDASIC_WriteTwiRegister(0x0160,(unsigned short)iLen);
	if (!bRet)
		return False;

	bRet=CMDASIC_WriteBulkData(m_w05SlopeTblAddr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;

	return CMDASIC_WriteTwiRegister(0x0162,(unsigned short)iLen);

}


int CtlMotor_WriteScanSlopeTable(unsigned short *SlopeTbl, int iLen)
{
	int bRet=1;


	bRet=CMDASIC_WriteBulkData(m_w01SlopeTblAddr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;
	bRet=CMDASIC_WriteTwiRegister(0x0156,(unsigned short)iLen);
	if (!bRet)
		return False;

	bRet=CMDASIC_WriteBulkData(m_w02SlopeTblAddr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;
	bRet=CMDASIC_WriteTwiRegister(0x015c,(unsigned short)iLen);
	if (!bRet)
		return False;

	bRet=CMDASIC_WriteBulkData(m_w03SlopeTblAddr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;
	bRet=CMDASIC_WriteTwiRegister(0x015e,(unsigned short)iLen);
	if (!bRet)
		return False;

	return True;
}

 

int CtlMotor_LoadPPSCurveToFastTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int *retstep)
{
	int iCnt=0, i, bRet=1;
	float *fCurv;
	unsigned int dwtmp;
	unsigned short *SBuf,*BufPtr;

	fCurv=inPPSCurve;
	//check curve's max value less than TargetPPS
	if (TargetPPS > (fCurv[inCurveLen-1]*1)) {
		//not found suitable curve value, return error
		printf(" motor PPS table can't reach max request speed, re-create PPS table on gscanctrldb.h \n");
		return False;
	}

	bRet=CtlMotor_SetFastTableUnit(StepUnit);
	if (!bRet) return 0;

	SBuf= (unsigned short *)malloc((inCurveLen+4)*2);
	if (SBuf == NULL) 	return False;
	BufPtr = SBuf;

	for (iCnt=0; iCnt<inCurveLen; iCnt++){

		if ((fCurv[iCnt]*1) < TargetPPS) {
			dwtmp = (unsigned int) ((float)1000000.0 / (fCurv[iCnt]*1) / CtlDevice_PixelTime / CtlMotor_nTBtime / m_iFastTableUnit);
			BufPtr[iCnt] = (unsigned short)( (dwtmp > 0xffff) ? 0xffff : dwtmp );
		} else {
			break;
		}

	}

	// last step is TargetPPS
  	BufPtr[iCnt] = (unsigned short) ((float)1000000.0 / TargetPPS / CtlDevice_PixelTime / CtlMotor_nTBtime / m_iFastTableUnit);
	iCnt++;

	//let iCnt to be a multipe of StepTim
	for (i=0; i<StepTim; i++) {
		if ( ((iCnt+i)%StepTim) == 0 ) {
			iCnt = iCnt+i;
			break;
		}
		BufPtr[iCnt+i] = BufPtr[iCnt-1];
	}

	iCnt = ( (iCnt>maxMotorStep) ? maxMotorStep : iCnt );

	bRet=CtlMotor_WriteFastSlopeTable(SBuf, iCnt); 
	free(SBuf);
	if (!bRet)
		return False;

	*retstep = iCnt;

	return True;


}




int CtlMotor_LoadPPSCurveToScanTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int *retstep)
{
	int iCnt=0, i, bRet=1;
	float *fCurv;
	unsigned int dwtmp;
	unsigned short *SBuf,*BufPtr;


	fCurv=inPPSCurve;
	//check curve's max value less than TargetPPS
	if (TargetPPS > (fCurv[inCurveLen-1]*1)) {
		//not found suitable curve value, return error
		printf(" motor PPS table can't reach max request speed, re create PPS table on gscanctrldb.h \n");
		return False;
	}

	bRet=CtlMotor_SetScanTableUnit(StepUnit);
	if (!bRet) return False;

	SBuf= malloc((inCurveLen+4)*2);
	if (SBuf == NULL) 	return False;
	BufPtr = SBuf;

	for (iCnt=0; iCnt<inCurveLen; iCnt++){

		if ((fCurv[iCnt]*1) < TargetPPS) {
			dwtmp = (unsigned int) ((float)1000000.0 / (fCurv[iCnt]*1) / CtlDevice_PixelTime / CtlMotor_nTBtime / m_iScanTableUnit);
			BufPtr[iCnt] = (unsigned short)( (dwtmp > 0xffff) ? 0xffff : dwtmp );
		} else {
			break;
		}

	}

	// last step is TargetPPS
	BufPtr[iCnt] = (unsigned short) ((float)1000000.0 / TargetPPS / CtlDevice_PixelTime / CtlMotor_nTBtime / m_iScanTableUnit);
	iCnt++;

	//let iCnt to be a multipe of StepTim
	for (i=0; i<StepTim; i++) {
		if ( ((iCnt+i)%StepTim) == 0 ) {
			iCnt = iCnt+i;    
			break;
		}
		BufPtr[iCnt+i] = BufPtr[iCnt-1];
	}
	iCnt = ( (iCnt>maxMotorStep) ? maxMotorStep : iCnt );

	//if really set CtlMotor_SetZ1Z2Value, need to make table sum
	//CtlMotor_CalculateTableSum(SBuf, iCnt);

	bRet=CtlMotor_WriteScanSlopeTable(SBuf, iCnt); 

	free(SBuf);

	if (!bRet)	return False;

	*retstep = iCnt;

	return True;


}


int CtlMotor_CalculateTableSum(unsigned short *SlopeTbl, int iLen)
{
	int iCnt;
	unsigned int dwData=0;
	unsigned short *SlopePtr;

	SlopePtr = SlopeTbl;
	for(iCnt=0; iCnt<iLen; iCnt++){
		dwData += *SlopePtr;
		SlopePtr++;
	}

	m_iTableSum = dwData * CtlMotor_nTBtime;
	m_iTableHigh = (*(SlopeTbl+(iLen-1))) * CtlMotor_nTBtime;
	return True;
}


int CtlMotor_SetZ1Z2Value(void)
{
	int bRet;
	unsigned int b_value, d_value , z1_d, z2_d;
	unsigned char V_CCDLMT;

	V_CCDLMT=(CMDASIC_RegTable[0x0007].nValue & 0x0f )+1;

	if (CMDASIC_RegTable[0x0002].nValue & 0x08) { // two table;
		b_value = ((unsigned int)(CMDASIC_RegTable[0x0155].nValue) << 8) +
				  (unsigned int)(CMDASIC_RegTable[0x0154].nValue);  
	} else {  // one table
		b_value = ((unsigned int)(CMDASIC_RegTable[0x0172].nValue) << 16) +
				  ((unsigned int)(CMDASIC_RegTable[0x0171].nValue) << 8) +
				  (unsigned int)(CMDASIC_RegTable[0x0170].nValue);
	}
	d_value = ((unsigned int)(CMDASIC_RegTable[0x0159].nValue) << 8) +
			  (unsigned int)(CMDASIC_RegTable[0x0158].nValue);

	z1_d = m_iTableSum + m_iTableHigh*(d_value-1);
	z1_d = z1_d % (CtlSensor_wTGPeriod*V_CCDLMT);

	z2_d = m_iTableSum + m_iTableHigh*(b_value-1);
	z2_d = z2_d % (CtlSensor_wTGPeriod*V_CCDLMT);

	bRet=CtlMotor_WriteMotorRemainder(z1_d, z2_d);
	if (!bRet) return False;

	return True;
}


int CtlMotor_WriteMotorRemainder(unsigned int z1, unsigned int z2)
{
	int bRet;
	bRet=CMDASIC_WriteFourRegister(0x0164, z1);
	if (!bRet) return False;
	return CMDASIC_WriteFourRegister(0x0168, z2);
}



//transfer scanbeginline from "CCD_DPIHW base unit" to "motor gear (full step)base unit",
//after that, calculate fast move or not
int CtlMotor_CalculateFeedReg(unsigned int ScanBeginLine)
{
	int bRet=1;
	unsigned short nStepNo, nFmovNo, nScanFed; //full step unit;
	int tmpline,beFastMove;

	bRet=CMDASIC_WriteTwiRegister(0x0154,(unsigned char)m_iScanTableUnit); //SCANFED
	if (!bRet) return False;

	nStepNo = (((unsigned short)(CMDASIC_RegTable[0x0157].nValue) << 8) +
					(unsigned short)(CMDASIC_RegTable[0x0156].nValue) ) / m_iScanTableUnit;
	nScanFed = (((unsigned short)(CMDASIC_RegTable[0x0155].nValue) << 8) +
					(unsigned short)(CMDASIC_RegTable[0x0154].nValue) ) / m_iScanTableUnit;
	nFmovNo = (((unsigned short)(CMDASIC_RegTable[0x0161].nValue) << 8) +
					(unsigned short)(CMDASIC_RegTable[0x0160].nValue) ) / m_iFastTableUnit;

	tmpline = ( (int)ScanBeginLine -nFmovNo -nFmovNo -nStepNo -nScanFed);

	if ( tmpline > 0 )  {
		beFastMove = 1;
	} else {
		tmpline = ((int)ScanBeginLine-nStepNo );
		if (tmpline < 1) {
			//error, no enough feedline for motor accelerate... 
			//you should need return error!!!
			//return False;
			printf("scan begin line is too small for motor accerlate !!!\n");
			tmpline = 1;
		}
		beFastMove = 0; 
	}

	bRet=CtlMotor_SetFeedSteps((unsigned long)tmpline * ( beFastMove ? m_iFastTableUnit : m_iScanTableUnit));
	if (!bRet) return False;

 	bRet=CtlMotor_EnableFastMove((unsigned char)(beFastMove ? 1 : 0));
	if (!bRet) return False;

	return True;

}




// calculate suitable times, to extend the content value of motor tables, 
// the content value of motor tables max value is 0xffff
int Calculate_TBTIME(unsigned int LastStepVale)
{
	unsigned char times;
	int bRet;

	times = (unsigned char)(LastStepVale / 65536 +1);
	if (times <= 2)
		times=times;
	else if (times < 5)
		times=4;
	else if (times < 9)
		times=8;
	else if (times < 17)
		times=16;
	else if (times < 33) 
		times=32;

	bRet=CtlMotor_SetTBTime(times);  
	if (!bRet) return False;

	return True;
}



int CtlMotor_LDMWriteOne(unsigned short addr, unsigned char data)
{
	int bRet;

	bRet=CMDASIC_WriteFourRegister(0x0184, (unsigned int)addr);
	if(!bRet)	return False;

	return CMDASIC_WriteFourRegister(0x0188, (unsigned int)data);
}


int CtlMotor_LDMReadOne(unsigned short addr, unsigned char *data)
{
	int bRet;
	unsigned int datain;

	bRet=CMDASIC_WriteFourRegister(0x0184, ((unsigned int)addr)<<16 );
	if(!bRet)	return False;

	bRet=CMDASIC_ReadFourRegister(0x018c, &datain);
	if(!bRet)	return False;

	*data = (unsigned char)(datain & 0x000000ff); 
	return True;
}


int CtlMotor_LDMWriteMulti(unsigned short addr, unsigned char *pData, unsigned short iLen)
{
	/*  //write addr every time
	int i,bRet;
	unsigned short addrtmp=addr;
	unsigned char *datatmp=pData;
	for (i=0; i<iLen; i++) {
		bRet=CtlMotor_LDMWriteOne(addrtmp, *datatmp);
		if(!bRet)	return False;
		addrtmp++;
		datatmp++;
	}
	return True;
	*/
///*
	int i,bRet;
	unsigned short addrtmp=addr;
	unsigned char *datatmp=pData;
	for (i=0; i<iLen; i++) {
		if ((*datatmp)!=0x00) {
			bRet=CtlMotor_LDMWriteOne(addrtmp, *datatmp);
			if(!bRet)	return False;
		}
		addrtmp++;
		datatmp++;
	}
	return True;
//*/


/*
	//write once addr
	int i,bRet;
	unsigned char *datatmp=pData;

	bRet=CMDASIC_WriteFourRegister(0x0184, (unsigned int)addr);
	if(!bRet)	return False;

	for (i=0; i<iLen; i++) {
		bRet=CMDASIC_WriteFourRegister(0x0188, (unsigned int)(*datatmp));
		if(!bRet)	return False;
		datatmp++;
	}
	return True;
*/

/*
	//write once addr
	int i,bRet;
	unsigned char *datatmp=pData;
	unsigned int dataint[100];

	bRet=CMDASIC_WriteFourRegister(0x0184, (unsigned int)addr);
	if(!bRet)	return False;

	memset((unsigned char *)dataint,0x00,iLen*4);
	for (i=0; i<iLen; i++) {
		dataint[i]=datatmp[i];
	}

	bRet=CMDASIC_WriteBulkData_Ex(0xb0000188, (unsigned char *)dataint, iLen*4);
	if (!bRet)	return False;

	return True;

*/
}



int CtlMotor_LDMReadMulti(unsigned short addr, unsigned char *pData, unsigned short iLen)
{
///*  //write addr every time
	int i,bRet;
	unsigned short addrtmp=addr;
	unsigned char *datatmp=pData;

	for (i=0; i<iLen; i++) {
		bRet=CtlMotor_LDMReadOne(addrtmp, datatmp);
		if(!bRet)	return False;
		addrtmp++;
		datatmp++;
	}

	return True;
//*/

/*  //write once addr
	int i,bRet;
	unsigned char *datatmp=pData;
	unsigned int datain;

	bRet=CMDASIC_WriteFourRegister(0x0184, ((unsigned int)addr)<<16 );
	if(!bRet)	return False;

	for (i=0; i<iLen; i++) {
		bRet=CMDASIC_ReadFourRegister(0x018c, &datain);
		if(!bRet)	return False;
		*datatmp = (unsigned char)(datain & 0x000000ff);
		datatmp++;
	}

	return True;
*/

}

//HL modify
int CtlMotor_MotorTable_setting(ScanParameter *pSPM)
{
	int iCnt,bRet=1;
	unsigned int Final_TG; //scan table final step, TG unit
	float Final_PPS;       //scan table final step, PPS(full step) unit
	int sn_Fastcuvid=0, sn_Scancuvid=1;
	unsigned short wSlope[16];

	bRet=CtlMotor_SetScanTableUnit(ScanTBunit);
	if (!bRet) return False;

	bRet=CtlMotor_SetFastTableUnit(FastTBunit);
	if (!bRet) return False;

	Final_TG = (unsigned int)((float)CtlSensor_nStepPerLine * CtlSensor_wTGPeriod / ((float)MotorGear/pSPM->spMotorResolution) );
	Final_TG *= (pSPM->spCCDLMT+1);

	bRet=Calculate_TBTIME(Final_TG); 
	if (!bRet) return False;	

	//bRet=CtlMotor_SetMotorVref(2, 2, 2, 2, 2);
	//if (!bRet) return False;

	if (!pSPM->spStillMode) {

		Final_PPS = (float)1000000.0 / CtlDevice_PixelTime / Final_TG;

		sn_Scancuvid = ( (Final_PPS > 2095.0f) ? 0 : 1); //select motor curve, CurveData1 or CurveData2
		bRet=CtlMotor_LoadPPSCurveToScanTable(MotorTableSet[sn_Scancuvid].fPPSTable,
							MotorTableSet[sn_Scancuvid].TbLength, 
							Final_PPS, 
							ScanTBunit, 
							&iCnt);
		if (!bRet)	return False;


#if 0
	bRet=My_LoadPPSCurveToMultiTable(MotorTableSet[sn_Fastcuvid].fPPSTable,
							MotorTableSet[sn_Fastcuvid].TbLength, 
							1200.0f, //Final_PPS*1.5f, 
							ScanTBunit, 
							0x00,
							&iCnt);
	if(!bRet) {
		CtlDevice_CloseDevice();
		printf("......Test Error !!\n");
		return False;
	}
	//MultiMotorSet(iCnt);
	MultiMotorSet_PickupCtl_SimpleMove(iCnt);
#endif



		sn_Fastcuvid = ( (FastTBPPS > 2095.0f) ? 0 : 1); //select motor curve, CurveData1 or CurveData2
		bRet=CtlMotor_LoadPPSCurveToFastTable(MotorTableSet[sn_Fastcuvid].fPPSTable,
							MotorTableSet[sn_Fastcuvid].TbLength, 
							FastTBPPS, 
							FastTBunit, 
							&iCnt);
		if (!bRet)	return False;






	} else {  //!pSPM->spStillMode

		wSlope[0] = CtlSensor_wTGPeriod / CtlMotor_nTBtime;
		wSlope[1] = wSlope[2] = wSlope[3] = wSlope[0];
		bRet=CtlMotor_WriteScanSlopeTable(wSlope,4);
		if (!bRet) return False;

	}  //!pSPM->spStillMode



	return True;

}

//HL modify
int CtlMotor_MotorTable_setting__(ScanParameter *pSPM)
{
	int iCnt,bRet=1;
	unsigned int Final_TG; //scan table final step, TG unit
	float Final_PPS;       //scan table final step, PPS(full step) unit
	int sn_Fastcuvid=0, sn_Scancuvid=1;
	unsigned short wSlope[16];
	int CUR1, CUR2;
	FILE  *mt_table = NULL;
	float mtTable1[MAX_STEP];
	float infPPS;


	printf("***Motor Parameter***\n");

	//bRet=CtlMotor_SetScanTableUnit(ScanTBunit); //Set motor step 
	//if (!bRet) return False;
		
	if(pSPM->spADFscan || DuplexscanFlag)
	{
		Final_TG = (unsigned int)((float)CtlSensor_nStepPerLine * CtlSensor_wTGPeriod / ((float)ADFMotorGear/pSPM->spMotorResolution) );
		FastTBPPS = 800.0f; /*PPS*/
		printf("Motor Gear = %d \n",ADFMotorGear);

		if(DoCalibrationFlag){
			adf_cur1 = 0;
			adf_cur2 = 0;
			mt_step = 4; 
		}
		else{
			switch(pSPM->spPixelResolution)
			{
				case 200:
					adf_cur1 = 0;
					adf_cur2 = 1;
					mt_step = 2; //Half step
					break;
				case 300:
					adf_cur1 = 0;
					adf_cur2 = 1;
					mt_step = 2;
					break;
				case 600:
					adf_cur1 = 1;
					adf_cur2 = 0;
					mt_step = 4; //Quarter
					break;
			}
		}
		CUR1= adf_cur1;
		CUR2=adf_cur2;
		ADF_MOTOR_Flag = 1;
	}
	else//Flatbed setting
	{
		Final_TG = (unsigned int)((float)CtlSensor_nStepPerLine * CtlSensor_wTGPeriod / ((float)MotorGear/pSPM->spMotorResolution) );
#ifdef ReadFile		
		//FastTBPPS = mt2_pps; /*PPS*/
#else
		FastTBPPS = 2966.0f; /*PPS*/		
#endif
		printf("Motor Gear = %d \n",MotorGear);
		
		switch(pSPM->spPixelResolution)
		{
			case 200:
				fb_cur1 = 1;
				fb_cur2 = 0;
				mt_step = 1; //Full step
				break;
			case 300:
				fb_cur1 = 1;
				fb_cur2 = 0;
				mt_step = 1;
				break;
			case 600:
				fb_cur1 = 1;
				fb_cur2 = 0;
				mt_step = 2; //Quarter
				break;
			case 1200:
				fb_cur1 = 0;
				fb_cur2 = 1;
				mt_step = 8; //1/8
				break;
		}
		CUR1= fb_cur1;
		CUR2= fb_cur2;
	}
	printf("Motor current CUR1=%d,CUR2=%d\n", CUR1, CUR2);

	bRet=CtlMotor_SetScanTableUnit(mt_step); //Set motor step 
	if (!bRet) return False;

	ScanTBunit = mt_step;

	bRet=CtlMotor_SetFastTableUnit(FastTBunit);
	if (!bRet) return False;

	Final_TG *= (pSPM->spCCDLMT+1);
	
	bRet=Calculate_TBTIME(Final_TG); 
	if (!bRet) return False;	

	//Set Forward current
	printf("Motor current CUR1=%d,CUR2=%d\n", CUR1, CUR2);

	bRet=CtlMotor_SetMotorCurrent(CUR1,CUR2); //Setup motor current 
	if (!bRet) return False;

	if(!pSPM->spStillMode) 
	{
#ifdef ReadFile
		if(mt1_pps == 5){
			printf(".....Using default PPS setting\n");
			Final_PPS = (float)1000000.0 / CtlDevice_PixelTime / Final_TG;
		}
		else{
			printf(".....Read Final PPS from file\n");
			Final_PPS = mt1_pps; //read input.ini
		}
#else
		Final_PPS = (float)1000000.0 / CtlDevice_PixelTime / Final_TG;		
#endif
		printf("Final_PPS = %f \n",Final_PPS);


		bRet=CtlMotor_SetMotorVref(2, 2, 2, 2, 2);  //Set Motor Current
		if (!bRet)	return False;

#if 0
		if(Final_PPS>2800) //??
			bRet=CtlMotor_SetMotorVref(2, 2, 2, 2, 2); 
		else
			bRet=CtlMotor_SetMotorVref(2, 2, 1, 2, 1); 
#endif

#ifdef _WIN32
		if((mt_table = fopen("mt_table.txt","r")) == NULL){
#else
		if(1) {
#endif
			printf("......Using motor table default\n");

			//sn_Scancuvid = ( (Final_PPS > 2950.0f) ? 0 : 1); //select motor curve, 0 = CurveData1 or 1= CurveData2
			

			//if(MonoScanFlag) // support ADF gray 300dpi only?
			if(pSPM->spImageType == IMAGE_GRAY)
				sn_Scancuvid = 0; //Genesys motor table
			else
				//use CurveData2
				sn_Scancuvid = 1; //select motor curve, 0 = CurveData1 or 1= CurveData2
		
			bRet=CtlMotor_LoadPPSCurveToScanTable(MotorTableSet[sn_Scancuvid].fPPSTable,
								MotorTableSet[sn_Scancuvid].TbLength, 
								Final_PPS, 
								ScanTBunit, 
								&iCnt);
			if (!bRet)	return False;

			bRet=CtlMotor_LoadPPSCurveToFastTable(MotorTableSet[sn_Fastcuvid].fPPSTable,
								MotorTableSet[sn_Fastcuvid].TbLength, 
								FastTBPPS, 
								FastTBunit, 
								&iCnt);
			if (!bRet)	return False;
		}
		else{
			int i= 0;
			int mtTbLength;

			printf("......Using motor table from file\n");
			
			while(fscanf(mt_table,"%f,",&infPPS)!=EOF){
				if(infPPS!=EOF)
				{
					mtTable1[i]=infPPS;
					i++;
				}
			}
			fclose(mt_table);

			mtTbLength = (i-1);

			bRet=CtlMotor_LoadPPSCurveToScanTable(mtTable1,
							mtTbLength, 
							Final_PPS, 
							ScanTBunit, 
							&iCnt);
			if (!bRet)	return False;

			bRet=CtlMotor_LoadPPSCurveToFastTable(mtTable1, //Fast table
							mtTbLength, 
							FastTBPPS, 
							FastTBunit, 
							&iCnt);
			if (!bRet)	return False;
		}
				
#if 0
	bRet=My_LoadPPSCurveToMultiTable(MotorTableSet[sn_Fastcuvid].fPPSTable,
							MotorTableSet[sn_Fastcuvid].TbLength, 
							Final_PPS*1.5f, 
							ScanTBunit, 
							0x00,
							&iCnt);
	if(!bRet) {
		CtlDevice_CloseDevice();
		printf("......Test Error !!\n");
		return False;
	}
	MultiMotorSet(iCnt);
#endif

	} else {  //!pSPM->spStillMode

		wSlope[0] = CtlSensor_wTGPeriod / CtlMotor_nTBtime;
		wSlope[1] = wSlope[2] = wSlope[3] = wSlope[0];
		bRet=CtlMotor_WriteScanSlopeTable(wSlope,4);
		if (!bRet) return False;

	}  //!pSPM->spStillMode

	return True;

}



int My_WriteFastSlopeTable(unsigned int addr, unsigned short *SlopeTbl, int iLen)
{
	int bRet=1;

	bRet=CMDASIC_WriteBulkData(addr, (unsigned char *)SlopeTbl, iLen*2);
	if (!bRet)
		return False;

#if 0
	{
		unsigned char ss[512];
		int i;
		unsigned char *ss1;
		ss1=SlopeTbl;
		CMDASIC_ReadBulkData(addr, (unsigned char *)ss, iLen*2);
		for (i=0; i<iLen*2; i++) {
			if(ss[i]!=ss1[i]) {
				return False;
			}
		}
	}
#endif


	return True;

}

int My_LoadPPSCurveToMultiTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int Vref, int *retstep)
{
	int iCnt=0, i, bRet=1;
	float *fCurv;
	unsigned int dwtmp;
	unsigned short *SBuf,*BufPtr;

	fCurv=inPPSCurve;
	//check curve's max value less than TargetPPS
	//if (TargetPPS > fCurv[inCurveLen-1]) return False 

	//bRet=CtlMotor_SetFastTableUnit(StepUnit);
	//if (!bRet) return 0;

	//bRet=CtlMotor_SetMotorVref(Vref, Vref, -1, -1);
	//if (!bRet) return 0;

	SBuf= (unsigned short *)malloc((inCurveLen+4)*2);
	if (SBuf == NULL) 	return False;
	BufPtr = SBuf;

	for (iCnt=0; iCnt<inCurveLen; iCnt++){

		if ((fCurv[iCnt]*1) < TargetPPS) {
			dwtmp = (unsigned int) ((float)1000000.0 / (fCurv[iCnt]*1) / CtlDevice_PixelTime / CtlMotor_nTBtime / StepUnit);
			BufPtr[iCnt] = (unsigned short)( (dwtmp > 0xffff) ? 0xffff : dwtmp );
		} else {
			break;
		}

	}

	// last step is TargetPPS
  	BufPtr[iCnt] = (unsigned short) ((float)1000000.0 / TargetPPS / CtlDevice_PixelTime / CtlMotor_nTBtime / StepUnit);
	iCnt++;

	//let iCnt to be a multipe of StepTim
	for (i=0; i<4; i++) {
		if ( ((iCnt+i)%4) == 0 ) {
			iCnt = iCnt+i;
			break;
		}
		BufPtr[iCnt+i] = BufPtr[iCnt-1];
	}

	iCnt = ( (iCnt>8192) ? 8192 : iCnt );

	bRet=My_WriteFastSlopeTable(0xB0002000, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002200, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002400, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002600, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002800, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002a00, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002c00, SBuf, iCnt);
//	bRet=My_WriteFastSlopeTable(0xB0002e00, SBuf, iCnt);

	free(SBuf);
	if (!bRet)
		return False;

	*retstep = iCnt;

	return True;


}

int CtlMotor_SetMotorCurrent(int CUR1, int CUR2) //read input.ini
{
//HL modify
#if 0
	if(ADF_MOTOR_Flag){
		//GPIO36  MOTOR CUR SW1
		CMDASIC_WriteRegisterBit(0x0065,1,1,0); //Enable GPIO function
		CMDASIC_WriteRegisterBit(0x0054,3,1,1); //GPIO36 output direction 
		CMDASIC_WriteRegisterBit(0x005c,3,1,CUR1); 

		//GPIO37  MOTOR CUR SW2
		CMDASIC_WriteRegisterBit(0x0065,2,2,0); //Enable GPIO function
		CMDASIC_WriteRegisterBit(0x0054,4,1,1); //GPIO37 output direction 
		CMDASIC_WriteRegisterBit(0x005c,4,1,CUR2);
	}
	else{
		//GPIO6  FB MOTOR CUR SW1
		CMDASIC_WriteRegisterBit(0x0060,4,1,0); //Enable GPIO function
		CMDASIC_WriteRegisterBit(0x0058,5,1,1); //GPIO6 output direction 
		CMDASIC_WriteRegisterBit(0x0050,5,1,CUR1); 

		//GPIO17  FB MOTOR CUR SW2
		CMDASIC_WriteRegisterBit(0x0062,0,1,0); //Enable GPIO function
		CMDASIC_WriteRegisterBit(0x005a,0,1,1); //GPIO17 output direction 
		CMDASIC_WriteRegisterBit(0x0052,0,1,CUR2);
	
	}
#endif
	return True;
}