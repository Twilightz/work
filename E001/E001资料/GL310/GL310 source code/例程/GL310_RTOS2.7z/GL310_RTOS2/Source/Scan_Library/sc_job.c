//-------------------
//	File: sc_job.c
//	Date: 2014.07.31
//-------------------

#include "sc_api.h"
#include "cmd.h"
#include "sc_job.h"
#include ".\AsicCmd\gusrdef.h"
//#include "tx_api.h"
#include "os_api.h"

JOB_SCAN_T Job_Scan;
int iEnableShading=1;
int disable_output_images=0; //if set (=1) scan image will not output

extern unsigned int memuse_start;	//0x00600000	//giimage.c
extern unsigned int memuse_size;	//0x03a00000	//giimage.c

U32 tick();

#ifdef BULKCMD_SIMULATE
#define MEM_START	0x00600000
#define MEM_END		0x03ff0000  //HL modify //0x04000000
#define PA_START	MEM_START
#define PB_START	(MEM_START + MEM_END)/2 
#define P0_A_size 0x20000	//0x1c000
#define P1_A_size 0x20000	//0x24000
#define P0_B_size 0x20000	//0x28000
#define P1_B_size 0x20000	//0x18000

typedef struct DEBUG_SCRIPT_STRUCT {
	U32 valid_page; U32 valid_size; U32 page_no; U32 page_end; U32 doc_end; U32 img_addr;
} DEBUG_SCRIPT_T;

DEBUG_SCRIPT_T debug_script[8][2] = {
	{{0, 1*P0_A_size/8, 0, 0, 0, PA_START},
	 {0, 2*P0_B_size/8, 0, 0, 0, PB_START}},
	{{0, 2*P0_A_size/8, 0, 0, 0, PA_START+(1*P0_A_size/8)},
	 {0, 2*P0_B_size/8, 0, 0, 0, PB_START+(2*P0_B_size/8)}},
	{{0, 3*P0_A_size/8, 0, 0, 0, PA_START+(3*P0_A_size/8)},
	 {0, 2*P0_B_size/8, 0, 0, 0, PB_START+(4*P0_B_size/8)}},
	{{1, 2*P0_A_size/8, 0, 1, 0, PA_START+(6*P0_A_size/8)},
	 {1, 2*P0_B_size/8, 0, 1, 0, PB_START+(6*P0_B_size/8)}},
	{{0, 2*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size},
	 {0, 2*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size}},
	{{0, 2*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size+(2*P1_A_size/8)},
	 {0, 2*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size+(2*P1_B_size/8)}},
	{{0, 2*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size+(4*P1_A_size/8)},
	 {0, 2*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size+(4*P1_B_size/8)}},
	{{1, 2*P1_A_size/8, 1, 1, 1, PA_START+P0_A_size+(6*P1_A_size/8)},
	 {1, 2*P1_B_size/8, 1, 1, 1, PB_START+P0_B_size+(6*P1_B_size/8)}}
#if 0
	{{0, 3*P0_A_size/8, 0, 0, 0, PA_START},
	 {0, 2*P0_B_size/8, 0, 0, 0, PB_START}},
	{{0, 2*P0_A_size/8, 0, 0, 0, PA_START+(3*P0_A_size/8)},
	 {0, 3*P0_B_size/8, 0, 0, 0, PB_START+(2*P0_B_size/8)}},
	{{0, 1*P0_A_size/8, 0, 0, 0, PA_START+(5*P0_A_size/8)},
	 {0, 2*P0_B_size/8, 0, 0, 0, PB_START+(5*P0_B_size/8)}},
	{{1, 2*P0_A_size/8, 0, 1, 0, PA_START+(6*P0_A_size/8)},
	 {1, 1*P0_B_size/8, 0, 1, 0, PB_START+(7*P0_B_size/8)}},
	{{0, 1*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size},
	 {0, 2*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size}},
	{{0, 2*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size+(1*P1_A_size/8)},
	 {0, 1*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size+(2*P1_B_size/8)}},
	{{0, 3*P1_A_size/8, 1, 0, 0, PA_START+P0_A_size+(3*P1_A_size/8)},
	 {0, 3*P1_B_size/8, 1, 0, 0, PB_START+P0_B_size+(3*P1_B_size/8)}},
	{{1, 2*P1_A_size/8, 1, 1, 0, PA_START+P0_A_size+(6*P1_A_size/8)},
	 {1, 2*P1_B_size/8, 1, 1, 1, PB_START+P0_B_size+(6*P1_B_size/8)}}
#endif
};

U32 debug_loop[2] = {0,0};

#endif //BULKCMD_SIMULATE

void Get_AvailableMemory(JOB_SCAN_T *job)
{
#ifdef BULKCMD_SIMULATE

	U32 i, j, k;
	U32 mem_next;
	
	mem_next = PA_START;
	for(i = 4; i <= P0_A_size; i+=4, mem_next+=4){
		M32(mem_next) = i;
	}
	for(i = 4; i <= P1_A_size; i+=4, mem_next+=4){
		M32(mem_next) = i;
	}
	M32(PA_START) = I3('P0A');
	M32(PA_START+P0_A_size-4) = I3('P0A');
	M32(PA_START+P0_A_size) = I3('P1A');
	M32(PA_START+P0_A_size+P1_A_size-4) = I3('P1A');

	mem_next = PB_START;
	for(i = 4; i <= P0_B_size; i+=4, mem_next+=4){
		M32(mem_next) = i;
	}
	for(i = 4; i <= P1_B_size; i+=4, mem_next+=4){
		M32(mem_next) = i;
	}
	M32(PB_START) = I3('P0B');
	M32(PB_START+P0_B_size-4) = I3('P0B');
	M32(PB_START+P0_B_size) = I3('P1B');
	M32(PB_START+P0_B_size+P1_B_size-4) = I3('P1B');

#endif //BULKCMD_SIMULATE

	job->mem.start = memuse_start;
	job->mem.end = memuse_start + memuse_size;
}

void Get_Action(JOB_SCAN_T *job)
{
	U32 acquire = job->acq.acquire;
	job->action.auto_scan = ((acquire & ACQ_AUTO_SCAN)? 1: 0);
	job->action.shading = ((acquire & ACQ_SHADING)? 1: 0);
	job->action.gamma = ((acquire & ACQ_GAMMA)? 1: 0);
	job->action.calibration = ((acquire & ACQ_CALIBRATION)? 1: 0);
	job->action.mirror = ((acquire & ACQ_MIRROR)? 1: 0);
	job->action.start_home = ((acquire & ACQ_START_HOME)? 1: 0);
	job->action.back_track = ((acquire & ACQ_BACK_TRACK)? 1: 0);
	job->action.auto_go_home = ((acquire & ACQ_AUTO_GO_HOME)? 1: 0);
	job->action.eject_paper = ((acquire & ACQ_EJECT_PAPER)? 1: 0);
	job->action.pickup_home = ((acquire & ACQ_PICKUP_HOME)? 1: 0);
	job->action.still_scan = ((acquire & ACQ_STILL_SCAN)? 1: 0);
	job->action.test_pattern = ((acquire & ACQ_TEST_PATTERN)? 1: 0);
	job->action.runin_image = ((acquire & ACQ_RUNIN_IMAGE)? 1: 0);
	job->action.runin = ((acquire & ACQ_RUNIN)? 1: 0);
}

int sc_Init(void *par, int size)
{
	int result;
#ifdef BULKCMD_SIMULATE
	return TRUE;
#endif //BULKCMD_SIMULATE	
	result=CtlDevice_LoadInitRegData();
	return result;
}

int ADF_SetParameter(JOB_SCAN_T *job);	//sc_job_adf.c
int FLB_SetParameter(JOB_SCAN_T *job);		//sc_job_adf.c
int Data_start(JOB_SCAN_T *job, int dup);	// dup = 0(A), 1(B)
int PowerOnBackToHome(void);


int sc_SetParameter(void *par, int size)
{
	int result = False;
	JOB_SCAN_T *job = &Job_Scan;

	if(size > (sizeof(ACQUIRE_T)+sizeof(IMAGE_T))) {
		size = (sizeof(ACQUIRE_T)+sizeof(IMAGE_T));
	}
	dprintf("SetParameter(t=%d)\n", tick());
	memcpy(&job->acq, par, size);
	dprintf("source=%s, duplex=%d, page=%d, action=0x%04x\n", &job->acq.source, job->acq.duplex, job->acq.page, job->acq.acquire);
	dprintf("format=%s, option=0x%04x, bit=%d, dpi=(%d,%d), org=(%d,%d), dot=(%d,%d)\n", &job->img.format, job->img.option, job->img.bit, job->img.dpi.x, job->img.dpi.y, job->img.org.x, job->img.org.y, job->img.dot.w, job->img.dot.h);
	Get_Action(job);
	Get_AvailableMemory(job);

	//PowerOnBackToHome();

#ifdef BULKCMD_SIMULATE
	return TRUE;
#endif //BULKCMD_SIMULATE
	if(job->acq.source == I3('ADF')) {
		result = ADF_SetParameter(job);
	}
	else if(job->acq.source == I3('FLB')) {
		result = FLB_SetParameter(job);
	}

	if(job->acq.duplex & 1)
		Data_start(job, 0);
	if(job->acq.duplex & 2)
		Data_start(job, 1);
	return result;
}

int ADF_StartScan(JOB_SCAN_T *job);
int FLB_StartScan(JOB_SCAN_T *job);

int sc_StartScan(void *par, int size)
{
	int result = False;
	JOB_SCAN_T *job = &Job_Scan;
#ifdef BULKCMD_SIMULATE
	dprintf("StartScan(t=%d)\n", tick());
	debug_loop[0] = debug_loop[1] = 0;
	return True;
#endif //BULKCMD_SIMULATE
	if(job->acq.source == I3('ADF')) {
		result = ADF_StartScan(job);
	}
	else if(job->acq.source == I3('FLB')) {
		result = FLB_StartScan(job);
	}
	return result;
		
}

int Data_IsReady(JOB_SCAN_T *job, int dup);  // dup = 0(A), 1(B)

int sc_GetInfo(void *par, int par_size)
{
	int result = False;
	JOB_SCAN_T *job = &Job_Scan;
	DATA_FLOW_T *df;
	SC_INFODATA_T *info = (SC_INFODATA_T*)par;
	int data_size = 0;
	U32 status = GET_STATUS(clr);
	static U32 info_tick = 0;
#if 0
		if((tick() - info_tick) < 10) {
			taskSleep(1);
		}
		info_tick = tick();
#endif
	memset(info, 0, sizeof(SC_INFODATA_T));
	//info->CoverOpen = 0;
	info->code = I4('INFO');
	info->PaperJam = (status & (DOCJAM(1)|MOVEJAM(1)))? 1: 0;

	if(job->acq.duplex & 1) {
#ifdef BULKCMD_SIMULATE
		int loop = debug_loop[0];
		DEBUG_SCRIPT_T *sc = &debug_script[loop][0];
		
		data_size = sc->valid_size;	//Data_IsReady(job, 1);
		info->EndDocument = sc->doc_end; //(df->event & EVENT_DOCUMENT_END)? 1: 0;
		info->EndPage[0] = sc->page_end; //(df->event & EVENT_PAGE_END)? 1: 0;
		info->PageNo[0] = sc->page_no;	//df->read.page;
		info->ValidPage[0] = sc->valid_page; //df->scanned.page;
		info->ValidPageSize[0] = sc->valid_size; //df->reading.size;
#else
		data_size = Data_IsReady(job, 0);
		df = &job->data[0];
		//info->EndDocument = (df->event & EVENT_DOCUMENT_END)? 1: 0;
		info->EndPage[0] = (df->event & EVENT_PAGE_END)? 1: 0;
		info->PageNo[0] = df->read.page;
		info->ValidPage[0] = df->scanned.page;
		info->ValidPageSize[0] = df->reading.size;
#endif //BULKCMD_SIMULATE
		info->ImageWidth[0] = job->img.dot.w;
		info->ImageLength[0] = (df->event & EVENT_PAGE_END)? df->expect.line: job->img.dot.h;
	}
	if(job->acq.duplex & 2) {
#ifdef BULKCMD_SIMULATE
		int loop = debug_loop[1];
		DEBUG_SCRIPT_T *sc = &debug_script[loop][1];
		
		data_size = sc->valid_size;	//Data_IsReady(job, 2);
		info->EndDocument = sc->doc_end; //(df->event & EVENT_DOCUMENT_END)? 1: 0;
		info->EndPage[1] = sc->page_end; //(df->event & EVENT_PAGE_END)? 1: 0;
		info->PageNo[1] = sc->page_no;	//df->read.page;
		info->ValidPage[1] = sc->valid_page; //df->scanned.page;
		info->ValidPageSize[1] = sc->valid_size; //df->reading.size;
#else
		data_size = Data_IsReady(job, 1);
		df = &job->data[1];
		//info->EndDocument = (df->event & EVENT_DOCUMENT_END)? 1: 0;
		info->EndPage[1] = (df->event & EVENT_PAGE_END)? 1: 0;
		info->PageNo[1] = df->read.page;
		info->ValidPage[1] = df->scanned.page;
		info->ValidPageSize[1] = df->reading.size;
#endif //BULKCMD_SIMULATE
		info->ImageWidth[1] = job->img.dot.w;
		info->ImageLength[1] = (df->event & EVENT_PAGE_END)? df->expect.line: job->img.dot.h;
	}
	
	if(((job->acq.duplex == 1) && (job->data[0].event & EVENT_DOCUMENT_END)) ||
		((job->acq.duplex == 2) && (job->data[1].event & EVENT_DOCUMENT_END)) || 
		((job->acq.duplex == 3) && (job->data[0].event & EVENT_DOCUMENT_END) && (job->data[1].event & EVENT_DOCUMENT_END)))
		info->EndDocument = 1;
		
	//dprintf("GetInfo(t=%d)\n", tick());
	return TRUE;
}

U32 Data_Submit(JOB_SCAN_T *job, int dup, int *size);

U32 sc_ReadData(int dup, int *size)
{
#ifdef BULKCMD_SIMULATE
	int loop = debug_loop[dup];
	DEBUG_SCRIPT_T *sc = &debug_script[loop][dup];
	debug_loop[dup]++;	
	//dprintf("ReadData(t=%d)\n", tick());
	return sc->img_addr;
#endif //BULKCMD_SIMULATE

	return Data_Submit(&Job_Scan, dup, size);
}

int ADF_CancelScan(JOB_SCAN_T *job);
int FLB_CancelScan(JOB_SCAN_T *job);

int sc_CancelScan(void *par, int size)
{
	int result = False;
	JOB_SCAN_T *job = &Job_Scan;

#ifdef BULKCMD_SIMULATE
	dprintf("CancelScan(t=%d)\n", tick());
	return TRUE;
#endif //BULKCMD_SIMULATE

	if(job->acq.source == I3('ADF')) {
		result = ADF_CancelScan(job);
	}
	else if(job->acq.source == I3('FLB')) {
		result = FLB_CancelScan(job);
	}

	return TRUE;
}


int ADF_StopScan(JOB_SCAN_T *job);
int FLB_StopScan(JOB_SCAN_T *job);

int sc_StopScan(void *par, int size)
{
	int result = False;
	JOB_SCAN_T *job = &Job_Scan;

#ifdef BULKCMD_SIMULATE
	dprintf("StopScan(t=%d)\n", tick());
	return TRUE;
#endif //BULKCMD_SIMULATE

	if(job->acq.source == I3('ADF')) {
		result = ADF_StopScan(job);
	}
	else if(job->acq.source == I3('FLB')) {
		result = FLB_StopScan(job);
	}
	return result;

}

extern unsigned int shd_bank_address[10]; 

#define EXP_100	864
int sc_DownloadShading(int type, void *data, int size)
{
		
	JOB_SCAN_T *job = &Job_Scan;
	int bRet;
	U32 onelen = 2 * EXP_100 * job->img.dpi.x / 100;
	U8 *shading_data = (U8*)data;
	// int type: used to decide witch 16+16 / 8+8 / 10+6 / 12+4 (0 is default)

	bRet= CMDASIC_WriteBulkData(shd_bank_address[0], shading_data, onelen) &&
		CMDASIC_WriteBulkData(shd_bank_address[1], shading_data+onelen,onelen) &&
		CMDASIC_WriteBulkData(shd_bank_address[2], shading_data+2*onelen,onelen);

	dprintf("write shd_bank[%08x] <- data[%08x] (len=%d)x3\n", shd_bank_address[0], shading_data, onelen);

	
	if(bRet && (job->acq.duplex == 3)) {
		shading_data += (3*onelen);
		bRet= CMDASIC_WriteBulkData(shd_bank_address[0]+DualOffset, shading_data, onelen) &&
			CMDASIC_WriteBulkData(shd_bank_address[1]+DualOffset, shading_data+onelen,onelen) &&
			CMDASIC_WriteBulkData(shd_bank_address[2]+DualOffset, shading_data+2*onelen,onelen);
		dprintf("write shd_bank[%08x] <- data[%08x] (len=%d)x3\n", shd_bank_address[0]+DualOffset, shading_data, onelen);
	}
	if(job->acq.duplex & 1) {
		SET_REGBIT(0xb0000000, SHDAREA(clr), SHDAREA(1));
		SET_REGBIT(0xb0000004, DVDSET(clr)|DVDTYPE(clr)|DARKSHIFT(clr), DVDSET(1)|DVDTYPE(2)|DARKSHIFT(8));	
	}
	if(job->acq.duplex & 2) {
		SET_REGBIT(0xb0000600, SHDAREA(clr), SHDAREA(1));
		SET_REGBIT(0xb0000604, DVDSET(clr)|DVDTYPE(clr)|DARKSHIFT(clr), DVDSET(1)|DVDTYPE(2)|DARKSHIFT(8));		
	}
	return bRet;
}

int sc_SetCalibration(void *data, int size)
{
//HL modify
#if 0
	JOB_SCAN_T *job = &Job_Scan;
	CALIBRATION_T *k = (CALIBRATION_T *)data;
	if(size != sizeof(CALIBRATION_T)) {
		dprintf("Error: Set Calibration data size mismatch\n");
		return FALSE;
	}	
	if(job->acq.duplex & 1) {
		CtlAfe_SetAFEGain(k->GainCode[0][0], k->GainCode[0][1], k->GainCode[0][2]);
		CtlAfe_SetAFEOffset(k->OffsetCode[0][0], k->OffsetCode[0][1], k->OffsetCode[0][2]);
		SET_EXPR(k->Exposure_Pix[0][0], 0);
		SET_EXPG(k->Exposure_Pix[0][1], 0);
		SET_EXPB(k->Exposure_Pix[0][2], 0);
	}
	if(job->acq.duplex & 2) {
		CtlAfe_SetAFEGain_B(k->GainCode[1][0], k->GainCode[1][1], k->GainCode[1][2]);
		CtlAfe_SetAFEOffset_B(k->OffsetCode[1][0], k->OffsetCode[1][1], k->OffsetCode[1][2]);
		SET_EXPR(k->Exposure_Pix[1][0], 1);
		SET_EXPG(k->Exposure_Pix[1][1], 1);
		SET_EXPB(k->Exposure_Pix[1][2], 1);
	}
#endif	
	return TRUE;
}



