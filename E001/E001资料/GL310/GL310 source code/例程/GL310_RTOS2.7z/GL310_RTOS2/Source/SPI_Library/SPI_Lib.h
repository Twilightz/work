#ifndef _SPILIB_H_
#define _SPILIB_H_
#include "spi_fun.h"
#include "spi_tag.h"
 



#ifdef  _SPI_TX
#include "os_user_api.h"
#include "os_user_spi.h"
#endif	


BOOL SPI_Ready(void);
UINT32 SPI_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen, UINT8 Ch); 
UINT32 SPI_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen, UINT8 Ch);
void SPI_BE(UINT32 BlockAddr, UINT8 Ch);
void SPI_CE(UINT8 Ch);
void SPI_RDID(UINT8 *VID, UINT8 *PID, UINT8 Ch);
void SPI_Initialize(void);
void SPI_BlockProctect(UINT8 Enable, UINT8 Ch);
void SPI_hw_Proctect(UINT8 Enable, UINT8 Ch);
void SPI_ProctectBits(UINT8 ProtectBits, UINT8 Ch);


#endif 
