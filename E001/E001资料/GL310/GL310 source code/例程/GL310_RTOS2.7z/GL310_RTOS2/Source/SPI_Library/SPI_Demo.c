#include "def.h"
//#include "tx_api.h"
#include "spi_tag.h"

BOOL SPI_TEST()
{

	UINT8 TagID;
	MemID_Tag *Tag_info;


	
    UINT8 *Wrbuf = fLib_NC_malloc(0x1000);
	UINT8 *RdBuf = fLib_NC_malloc(0x1000);
	UINT32 checksum=0;
	UINT32 checksum2=0;
	INT8 *IDString ="TESTI5";
    //INT8 *SPIDISKString="SPIDISK";   
       
    
    
	
	while( !SPI_Ready() );   
   	
   	if( SPI_TagStringInquiry(&TagID, IDString) ){
   		
   		SPI_TagIDRelease(TagID);
   	}   
       
    
 	while( !SPI_Ready() );   
   	
   	if( !SPI_TagIDGet(&TagID, 4, IDString) )
   		return false;
   	
   	
   	
    if( !SPI_TagStringInquiry(&TagID, IDString) )
    	return false;
    
    if( !SPI_TagInfoRead(TagID, &Tag_info) )
    	return false;
    
    printf("TagID->Start Block=%x\n",Tag_info->StartBlock);
    printf("TagID->name=%s\n",Tag_info->IDString);
    
   		
 	SPI_TagEraseAll(TagID);
	
 	SPI_TagDataWrite(TagID, 1, Wrbuf, &checksum2);
	SPI_TagDataRead(TagID, 1, RdBuf, &checksum);
	
	
	memset(Wrbuf, 0x11, 0x1000);
	SPI_TagDataWrite(TagID, 0, Wrbuf, &checksum2);
	
	memset(Wrbuf, 0x22, 0x1000);
	SPI_TagDataWrite(TagID, 1, Wrbuf, &checksum2);
	
	memset(Wrbuf, 0x33, 0x1000);
	SPI_TagDataWrite(TagID, 2, Wrbuf, &checksum2);
	
	memset(Wrbuf, 0x44, 0x1000);
	SPI_TagDataWrite(TagID, 3, Wrbuf, &checksum2);
	
	
	SPI_TagDataRead(TagID, 0, RdBuf, &checksum);
	
	SPI_TagDataRead(TagID, 1, RdBuf+0x1000, &checksum);
	SPI_TagDataRead(TagID, 2, RdBuf+0x2000, &checksum);
	SPI_TagDataRead(TagID, 3, RdBuf+0x3000, &checksum);

	
	SPI_TagEraseIndex(TagID, 0);
		
	memset(Wrbuf, 0x55, 0x1000);
	SPI_TagDataWrite(TagID, 0, Wrbuf, &checksum2);
	
	SPI_TagDataRead(TagID, 0, RdBuf, &checksum);
	
	SPI_TagEraseIndex(TagID, 1);
	
	memset(Wrbuf, 0x66, 0x1000);
	SPI_TagDataWrite(TagID, 1, Wrbuf, &checksum2);
	
	SPI_TagDataRead(TagID, 1, RdBuf, &checksum);
	
	
	SPI_TagEraseIndex(TagID, 2);
	
	memset(Wrbuf, 0x77, 0x1000);
	SPI_TagDataWrite(TagID, 2, Wrbuf, &checksum2);
	
	SPI_TagDataRead(TagID, 2, RdBuf, &checksum);
	
   	SPI_TagEraseIndex(TagID, 3);
	
	memset(Wrbuf, 0x88, 0x1000);
	SPI_TagDataWrite(TagID, 3, Wrbuf, &checksum2);
	
	SPI_TagDataRead(TagID, 3, RdBuf, &checksum);   
       
	fLib_NC_free(Wrbuf);
	fLib_NC_free(RdBuf);
 
	return true;

	
}

//void DemoSPI(ULONG thread_input)
void DemoSPI()
{

	UINT8 TagID;
	MemID_Tag *TagID_info;
	INT8 *IDString = "TESTIB";

	//SPIC_Initialize();
	
	

	
	SPI_BackupBootTag(0);
	SPI_RD(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);
	SPI_SetBootImageTag(8);
    SPI_RD(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);
	
	
	
	
	
	SPI_TEST();
	
	if( !SPI_TagIDGet(&TagID, 10, IDString) ){
		
		printf("Get TagID failure\n");
		while(1);
	}
	
	if( !SPI_TagInfoRead(TagID, &TagID_info) ){
		
		printf("Get TagID info failure\n");
		while(1);
	}
	
	
}
