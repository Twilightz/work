#ifndef _UDEV_CSTAPI_H
#define _UDEV_CSTAPI_H

#ifdef THREADX
#include "tx_api.h"
void InitUDev_Thread(TX_BYTE_POOL*);

#elif defined(RTOS)
#include "OS_API.h"
void InitUDev_Task(void);
#endif

//udev_GetUSBStatus();
#define  bmConfigured       		0x01
#define  bmHighSpeed        		0x02
#define  bmVbusExist        		0x04


//BOOL SetupDMA(BOOL fDMANo, BOOL fDir,BOOL fDisInc, UINT32 *pStarAdr, UINT32 wLen, BOOL fIntEn, BOOL fIntDis, BOOL fRunCB)
#define  cDMA1              		0
#define  cDMA2              		!cDMA1
#define  cBO                		0
#define  cBI                		!cBO
#define  cAdrInc            		0
#define  cIntEn_disabled    		0
#define  cIntDis_disabled   		0
#define  cRunCB             		1

//Send_IntPipe(UINT8 *pBuf, UINT8 bLeng, BOOL fRstFF3, BOOL fRunCB)
//UDev_Push_IntPipe_New(UINT8 *pMem, UINT8 bCnt, BOOL fRstFF3, BOOL fRunCB)
#define  cRstEp3Fifo				1

//UDev_Reg_EvtHdl(iDMA1BO_CST, DMA1BO_CB);
#define  iDMA1BO_CST	 	        0
#define  iDMA1BI_CST	 	        1

#define  iDMA2BO_CST	 	        2
#define  iDMA2BI_CST	 	        3

#define  iPIO1BO_CST	 	        4
#define  iPIO1BI_CST	            5

#define  iPIO2BO_CST		        6
#define  iPIO2BI_CST		        7

#define  iEp3Tx_CST					8

#define  FS_CST			            0
#define  HS_CST		            	1

//HS
#define  cMAXPKTHS1_L_CST		    0x00  //512 bytes
#define  cMAXPKTHS1_H_CST		    0x02
#define  cMAXPKTHS2_L_CST		    cMAXPKTHS1_L_CST
#define  cMAXPKTHS2_H_CST		    cMAXPKTHS1_H_CST
#define  cMAXPKTHS3_L_CST		    0x40

//FS
#define  cMAXPKTFS1_L_CST		    0x40  //64 bytes
#define  cMAXPKTFS1_H_CST		    0x00
#define  cMAXPKTFS2_L_CST		    cMAXPKTFS1_L_CST
#define  cMAXPKTFS2_H_CST		    cMAXPKTFS1_H_CST
#define  cMAXPKTFS3_L_CST		    0x40


void ChgID(UINT16, UINT16);
void ChgVdrStr(UINT8*, UINT8, BOOL);
void ChgPdtStr(UINT8*, UINT8 , BOOL);
void ChgSerStr(UINT8*, UINT8, BOOL);

BOOL Chg_Dev_Desc(UINT8 aCstDesc[]);
BOOL Chg_Cfg_Desc(UINT8 aCstDesc[],BOOL);

void UDev_DisConnect(void);
void UDev_Connect(void);
BOOL UDev_Chk_Connect(void);

UINT32 UDev_Init_Vbus(UINT32);                      //Initial Vbus pin
BOOL UDev_Chk_Vbus(void);                           //Check if Vbus exist
UINT8 udev_GetUSBStatus(void);						//Get current status of USB device

INT32 udev_RegEP0CmdHandler(INT32, UINT8*, BOOL (*hdl)(), UINT8);	//Reigster vendor command
UINT8 UDev_Reg_EvtHdl(UINT8, BOOL (*Hdl)());        				//Register event call-back handler
UINT8 UDev_Reg_GpioHdl(UINT32, UINT8 (*fpGpio_Int_Func)()); 		//Register GPIOs call-back handler

BOOL SetupDMA(BOOL, BOOL, BOOL, UINT32*, UINT32, BOOL, BOOL, BOOL);	//Setup DMA
void  udev_StopDMA(UINT8);                          				//Stop DMA

void InitGpioInt_Edge(UINT32, BOOL, BOOL, BOOL);    //Initial GPIOs

void UDev_Set_Rmt_Wakeup_Key(UINT8);                //Set Remote Wakeup Key, GPOE will be changed as input mode

UINT8 UDev_Reg_UnCfgHdl(UINT8 (*fpHdl)());          //Register unconfigured call-back handler
UINT8 UDev_Reg_CfgHdl(UINT8 (*fpHdl)());            //Register configured call-back handler

UINT8 BulkOut_PIO(UINT8, BOOL);                     //BulkOut_PIO
UINT8 BulkIn_PIO(UINT8, BOOL);                      //BulkIn_PIO  

UINT8 udev_PopBOFIFO(UINT8);                        //Pop BulkOut FIFO
void udev_PopBOFIFO2Mem(UINT8*, UINT32, UINT8);     //Pop BulkOut FIFO to memory

void udev_PushBIFIFO(UINT8, UINT8);                 //Push BulkIn FIFO
void udev_PushBIFIFOFmMem(UINT8*, UINT32, UINT8);   //Push BulkIn FIFO from memory

UINT16 Chk_UDevLib_Ver(void);                       //Check usb device library version

UINT8 Send_IntPipe(UINT8*, UINT8, BOOL, BOOL);		//Push & Transmit data to interrupt pipe 
void UDev_Push_IntPipe(UINT8*, UINT8);              //Push data to interrupt pipe
void UDev_Push_IntPipe_New(UINT8*,UINT8,BOOL,BOOL); //Push data to interrupt pipe
void UDev_Xmit_IntPipeData(void);                   //Transmit data through the interrupt pipe

UINT32  udev_GetUSBCntr(UINT8);                     //Get the USB pre-counter

extern BOOL    fBOPIO1OpFnsh,fBIPIO1OpFnsh,fBOPIO2OpFnsh,fBIPIO2OpFnsh;

//--Pure usb device-------------------------------------------
void UDev_Before_RunDevice(void);
void UDevTask_Int(void);

#endif

