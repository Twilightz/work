#ifndef _SYSCONFIG_H_
#define _SYSCONFIG_H_

 

#define _USER_CONFIG	1

#define TBD1            0x01             
#define TBD2			0x02
#define TBD3			0x04
#define TBD4			0x08

#define TBD5			0x10
#define TBD6			0x20
#define TBD7	        0x40
#define TBD8		    0x80

BOOL sysConfig_initialize(void);


 
#endif 

