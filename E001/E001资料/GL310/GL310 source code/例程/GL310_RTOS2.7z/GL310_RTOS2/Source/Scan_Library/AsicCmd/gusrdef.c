////////////////////////////////////////////////////////////////
// File - gusrdef.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include <time.h>

void sleep(unsigned int wait)
{
	clock_t goal, start;
	start = (clock_t)((double)wait*CLOCKS_PER_SEC/1000);
	goal = start + clock();
	while( goal > clock())
		;
	return;
}

unsigned int gettickcount(void)
{
	clock_t time;
	time=clock();
	return (unsigned int)((double)time*1000/CLOCKS_PER_SEC);
}
