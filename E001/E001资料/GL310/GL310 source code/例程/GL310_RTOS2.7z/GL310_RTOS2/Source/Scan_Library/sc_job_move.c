//-------------------
//	File: sc_job_move.c
//	Date: 2014.09.12
//-------------------

#include "cmd.h"
#include "sc_job.h"
//#include "tx_api.h"











