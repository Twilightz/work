////////////////////////////////////////////////////////////////
// File - asiccmd.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

//#include <Windows.h>
#include "asiccmd.h"
#include "gusrdef.h"
#include "cmd.h"	//"i_GL310.h"


RegRec CMDASIC_RegTable[MAX_SCAN_REGISTERS];

extern unsigned char wRegIdxTbl[MAX_SCAN_REGISTERS/4];

extern int BENG_Active;

int CMDASIC_ReadRegister(unsigned short nAddr, unsigned char *nResult)
{
#if 0
	int bRet;
	unsigned short wdaddr;
	unsigned int wddata;
	wdaddr=nAddr%4;
	bRet=CMDASIC_ReadBus(0xB0000000 | (unsigned int)(nAddr-wdaddr), &wddata);
	if(!bRet) return False;
	*nResult = (unsigned char)(0x000000ff&(wddata>>(wdaddr*8)));
#endif
	int left = nAddr % 4;
	U32 data;
	U32 addr = SCR(nAddr) - left;
	data = GET_REG(addr) >> (left<<3);
	*nResult = (U8)data;

	return True;
}


int CMDASIC_ReadTwiRegister(unsigned short nAddr, unsigned short *wResult)
{
#if 0
	int bRet;
	unsigned short wdaddr;
	unsigned int wddata;
	wdaddr=nAddr%4;
	bRet=CMDASIC_ReadBus(0xB0000000 | (unsigned int)(nAddr-wdaddr), &wddata);
	if(!bRet) return False;
	*wResult = (unsigned short)(0x0000ffff&(wddata>>(wdaddr*8)));
#endif
	int left = nAddr % 4;
	U32 data;

	U32 addr = SCR(nAddr) - left;
	data = GET_REG(addr) >> (left<<3);
	*wResult = (U16)data;

	return True;
}


int CMDASIC_ReadFourRegister(unsigned short nAddr, unsigned int *dwResult)
{
#if 0
	return CMDASIC_ReadBus(0xB0000000 | (unsigned int)nAddr, dwResult);
#endif
	U32 addr = SCR(nAddr);
	*dwResult = GET_REG(addr);
	return True;
}

U32 Bitn_map[] = {0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f};

int CMDASIC_WriteRegisterBit(unsigned short nAddr, unsigned char StartBit, unsigned char Bitn, unsigned char iData) 
{
#if 0
	int iCnt;
	unsigned char nVal, flag=0x01, mask=0x00;
	
	for (iCnt=0; iCnt<Bitn; iCnt++) {
		flag = 0x01 << (StartBit+iCnt);
		mask |= flag;
	}
	nVal=CMDASIC_RegTable[nAddr].nValue;
	nVal &= (~mask);
	nVal |= (iData<<StartBit);
	return CMDASIC_WriteRegister(nAddr, nVal);
#endif
	int left = nAddr % 4;
	U32 clear = (Bitn_map[Bitn] << StartBit);
	U32 data = (iData << StartBit);

	U32 addr = SCR(nAddr) - left;
	left <<= 3;
	clear <<= left;
	data <<= left;
	SET_REGBIT(addr, clear, data);
	if ( (wRegIdxTbl[(addr-0xb0000000)/4]==1) && BENG_Active ) {
		addr += 0x600;
		SET_REGBIT(addr, clear, data);
	}
	return True;

}


int CMDASIC_WriteRegister(unsigned short nAddr, unsigned char nData) 
{
#if 0
	int bRet;
	unsigned short wdaddr;
	unsigned int wddata;

	CMDASIC_RegTable[nAddr].nValue = nData;
	wdaddr=nAddr-nAddr%4;
	wddata =	(unsigned int)(CMDASIC_RegTable[wdaddr+3].nValue<<24) | 
				(unsigned int)(CMDASIC_RegTable[wdaddr+2].nValue<<16) | 
				(unsigned int)(CMDASIC_RegTable[wdaddr+1].nValue<<8) | 
				(unsigned int)CMDASIC_RegTable[wdaddr].nValue;
	bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)wdaddr, wddata);
	if(!bRet) return False;


	if ( (wRegIdxTbl[wdaddr/4]==1) && BENG_Active ) {
		CMDASIC_RegTable[nAddr+0x600].nValue = nData;
		bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)(wdaddr+0x600), wddata);
		if(!bRet) return False;
	}
#endif
	int left = nAddr % 4;
	U32 clear = 0xff;
	U32 addr = SCR(nAddr) - left;
	U32 data = nData;

CMDASIC_RegTable[nAddr].nValue = nData;

	left <<= 3;
	clear <<= left;
	data <<= left;
	SET_REGBIT(addr, clear, data);
	if ( (wRegIdxTbl[(addr-0xb0000000)/4]==1) && BENG_Active ) {
CMDASIC_RegTable[nAddr+0x600].nValue = nData;	
		addr += 0x600;
		SET_REGBIT(addr, clear, data);
	}
	return True;
}


int CMDASIC_WriteTwiRegister(unsigned short nAddr, unsigned short wData)
{
#if 0
	int bRet;
	unsigned short wdaddr;
	unsigned int wddata;

	CMDASIC_RegTable[nAddr].nValue = LoByte(wData);
	CMDASIC_RegTable[nAddr+1].nValue = HiByte(wData);
	wdaddr=nAddr-nAddr%4;
	wddata =	(unsigned int)(CMDASIC_RegTable[wdaddr+3].nValue<<24) | 
				(unsigned int)(CMDASIC_RegTable[wdaddr+2].nValue<<16) | 
				(unsigned int)(CMDASIC_RegTable[wdaddr+1].nValue<<8) | 
				(unsigned int)CMDASIC_RegTable[wdaddr].nValue;
	bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)wdaddr, wddata);
	if(!bRet) return False;

	if ( (wRegIdxTbl[wdaddr/4]==1) && BENG_Active ) {
		CMDASIC_RegTable[nAddr+0x600].nValue = LoByte(wData);
		CMDASIC_RegTable[nAddr+0x600+1].nValue = HiByte(wData);
		bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)(wdaddr+0x600), wddata);
		if(!bRet) return False;
	}
#endif
	int left = nAddr % 4;
	U32 clear = 0xffff;
	U32 addr = SCR(nAddr) - left;
	U32 data = wData;
	
CMDASIC_RegTable[nAddr].nValue = LoByte(wData);
CMDASIC_RegTable[nAddr+1].nValue = HiByte(wData);	

	left <<= 3;
	clear <<= left;
	data <<= left;
	SET_REGBIT(addr, clear, data);
	if ( (wRegIdxTbl[(addr-0xb0000000)/4]==1) && BENG_Active ) {
CMDASIC_RegTable[nAddr+0x600].nValue = LoByte(wData);
CMDASIC_RegTable[nAddr+0x600+1].nValue = HiByte(wData);	
		addr += 0x600;
		SET_REGBIT(addr, clear, data);
	}

	return True;

}



int CMDASIC_WriteFourRegister(unsigned short nAddr, unsigned int dwData)
{
#if 0
	int bRet;
	unsigned short wHiData,wLoData;

	wHiData = HiWord(dwData);
	wLoData = LoWord(dwData);
	CMDASIC_RegTable[nAddr].nValue = LoByte(wLoData);
	CMDASIC_RegTable[nAddr+1].nValue = HiByte(wLoData);
	CMDASIC_RegTable[nAddr+2].nValue = LoByte(wHiData);
	CMDASIC_RegTable[nAddr+3].nValue = HiByte(wHiData);

	bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)nAddr, dwData);
	if(!bRet) return False;

	if ( (wRegIdxTbl[nAddr/4]==1) && BENG_Active ) {
		wHiData = HiWord(dwData);
		wLoData = LoWord(dwData);
		CMDASIC_RegTable[nAddr+0x600].nValue = LoByte(wLoData);
		CMDASIC_RegTable[nAddr+0x600+1].nValue = HiByte(wLoData);
		CMDASIC_RegTable[nAddr+0x600+2].nValue = LoByte(wHiData);
		CMDASIC_RegTable[nAddr+0x600+3].nValue = HiByte(wHiData);
		bRet=CMDASIC_WriteBus(0xB0000000 | (unsigned int)(nAddr+0x600), dwData);
		if(!bRet) return False;
	}
#endif

	U32 addr = SCR(nAddr);
	
unsigned short wHiData,wLoData;
wHiData = HiWord(dwData);
wLoData = LoWord(dwData);
CMDASIC_RegTable[nAddr].nValue = LoByte(wLoData);
CMDASIC_RegTable[nAddr+1].nValue = HiByte(wLoData);
CMDASIC_RegTable[nAddr+2].nValue = LoByte(wHiData);
CMDASIC_RegTable[nAddr+3].nValue = HiByte(wHiData);
		
	SET_REG(addr, dwData);
	if ( (wRegIdxTbl[(addr-0xb0000000)/4]==1) && BENG_Active ) {

wHiData = HiWord(dwData);
wLoData = LoWord(dwData);
CMDASIC_RegTable[nAddr+0x600].nValue = LoByte(wLoData);
CMDASIC_RegTable[nAddr+0x600+1].nValue = HiByte(wLoData);
CMDASIC_RegTable[nAddr+0x600+2].nValue = LoByte(wHiData);
CMDASIC_RegTable[nAddr+0x600+3].nValue = HiByte(wHiData);
			
		addr += 0x600;
		SET_REG(addr, dwData);
	}
	return True;
}



int CMDASIC_WriteMultiRegister(unsigned char *pBuf, unsigned int dwLen)
{
	int bRet;
	unsigned int i;
	RegRec *buffer;

	buffer=(RegRec*)pBuf;
	for (i=0; i<dwLen; i++) {
		CMDASIC_RegTable[buffer[i].nCtrl].nValue = buffer[i].nValue;
		bRet=CMDASIC_WriteRegister( buffer[i].nCtrl, buffer[i].nValue );
		if(!bRet)
			return False;
	}
	return True;
}

int CMDASIC_ReadBulkData(unsigned int wAddr,unsigned char *pData, unsigned int dwLen)
{
#if 0
	int bRet;

	bRet=CMDASIC_SetupBulkLength(wAddr, dwLen,0);
	if (!bRet) 	return False;
	return CMDIO_BulkRead(pData, dwLen);
#endif
	int i, j;
	for(i = 0, j = (dwLen & ~3); i < j; i += 4, wAddr+=4, pData+=4)
		M32(pData) = R32(wAddr);
	for(i = 0, j = (dwLen & 3); i < j; i++, wAddr++, pData++)
		M8(pData) = R8(wAddr);
	return True;
}


int CMDASIC_SetupBulkLength(unsigned addr, unsigned int len,unsigned char bmode) //bmode=1=write bmode=0=read
{
#if 0
	union SetupCmd xx;
	xx.val[0]=addr;     //data address
	xx.val[1]=len;		//data length
	return CMDIO_WriteCommand(0x82, bmode, 8, (unsigned char*)&xx);
#endif
	return True;
} 


int CMDASIC_WriteBulkData(unsigned int wAddr, unsigned char *pData, unsigned int dwLen)
{
#if 0
	int bRet;

	bRet = CMDASIC_SetupBulkLength(wAddr, dwLen,1);
	if (!bRet)	return False;
	return CMDIO_BulkWrite(pData,dwLen);
#endif
	U32 i, j;
	for(i = 0, j = (dwLen & ~3); i < j; i += 4, wAddr+=4, pData+=4)
		R32(wAddr) = M32(pData);
	for(i = 0, j = (dwLen & 3); i < j; i++, wAddr++, pData++)
		R8(wAddr) = M8(pData);
	return 1;

}

int CMDASIC_WriteBulkData_Ex(unsigned int wAddr, unsigned char *pData, unsigned int dwLen)
{
#if 0
	int bRet;

	bRet = CMDASIC_SetupBulkLength(wAddr, dwLen,9);
	if (!bRet)	return False;
	return CMDIO_BulkWrite(pData,dwLen);
#endif 
	return CMDASIC_WriteBulkData(wAddr, pData, dwLen);
}

int CMDASIC_ReadBulkData_Ex(unsigned int wAddr,unsigned char *pData, unsigned int dwLen)
{
#if 0
	int bRet;

	bRet=CMDASIC_SetupBulkLength(wAddr, dwLen,8);
	if (!bRet) 	return False;
	return CMDIO_BulkRead(pData, dwLen);
#endif
	return CMDASIC_ReadBulkData(wAddr, pData, dwLen);
}


int CMDASIC_APBWriteAddr(unsigned int addr)
{
#if 0
	return CMDIO_WriteCommand(0x8b, 0x06, 4, (unsigned char*)&addr);
#endif
	return False;
}

int CMDASIC_APBWriteData(unsigned int data)
{
#if 0
	return CMDIO_WriteCommand(0x8b, 0x05, 4, (unsigned char*)&data);
#endif
	return False;
}

int CMDASIC_APBReadData(unsigned int *data)
{
#if 0
	return CMDIO_ReadCommand(0x8a, 0x05, 4, (unsigned char*)data);
#endif
	return False;
}

int CMDASIC_Debug_Dump(void)
{
#if 0
	int ic;
	char strtmp[256];
	unsigned int data;
	//return True;
	for (ic=0; ic<MAX_SCAN_REGISTERS; ic=ic+4) { 
		CMDASIC_ReadFourRegister((unsigned short)ic,&data);
		sprintf(strtmp,"0x%04x= 0x%08x\n",ic,data); 
		OutputDebugString(strtmp);
	}
#endif
	return True;
}



int CMDASIC_ReadJPGBus(unsigned short nAddr, unsigned int *nResult)
{
	return CMDASIC_ReadBus(0xB0300000 | (unsigned int)nAddr, nResult);
}

int CMDASIC_WriteJPGBus(unsigned short nAddr, unsigned int nData) 
{
	if(BENG_Active)
		CMDASIC_WriteBus(0xB0400000 | (unsigned int)nAddr, nData); 
	return CMDASIC_WriteBus(0xB0300000 | (unsigned int)nAddr, nData);
}

int CMDASIC_ReadJPGBus_B(unsigned short nAddr, unsigned int *nResult)
{
	return CMDASIC_ReadBus(0xB0400000 | (unsigned int)nAddr, nResult);
}

int CMDASIC_WriteJPGBus_B(unsigned short nAddr, unsigned int nData) 
{
	return CMDASIC_WriteBus(0xB0400000 | (unsigned int)nAddr, nData);
}


int CMDASIC_ReadBus(unsigned int nAddr, unsigned int *nResult)
{
#if 0
	int bRet;
	unsigned int wddata;

	bRet=CMDASIC_APBWriteAddr(nAddr);
	if(!bRet) return False;
	bRet=CMDASIC_APBReadData(&wddata);
	if(!bRet) return False;
	*nResult = wddata;
#endif
	*nResult = GET_REG(nAddr);
	return True;
}

int CMDASIC_WriteBus(unsigned int nAddr, unsigned int nData) 
{
#if 0
	int bRet;
	bRet=CMDASIC_APBWriteAddr(nAddr);
	if(!bRet) return False;
	return CMDASIC_APBWriteData(nData);
#endif
	SET_REG(nAddr, nData);
	return True;
}

