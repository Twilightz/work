#include "def.h"
#include "spi_lib.h"

/********************************************
 * SPI Library 141128.01
 ********************************************/
extern UINT8 Flash_Power_protect;

BOOL WriteToSPI(UINT8* IDString, UINT32 SourceAddr, UINT32 Len);
BOOL ReadFromSPI(UINT8* IDString, UINT32 DestAddr, UINT32 Len);




BOOL SPI_Ready()
{

	return true;
	
}


/*==================================================================
  = UINT32 SPIC_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen) 
  ==================================================================*/
UINT32 SPI_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen, UINT8 Ch) 
{
	

	return SPIC_WR(StartAddr, WriteBuf, WriteLen, &spicmap_tbl[Ch]); 
}


/*==================================================================
  = UINT32 Spi_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen) 
  ==================================================================*/
UINT32 SPI_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen, UINT8 Ch)
{
	
    return SPIC_RD(StartAddr, ReadBuf, ReadLen, &spicmap_tbl[Ch]); 
}




void SPI_BE(UINT32 BlockAddr, UINT8 Ch)
{
	
	SPIC_BE(BlockAddr, &spicmap_tbl[Ch]); 
}



void SPI_CE(UINT8 Ch)
{
	
	SPIC_CE(&spicmap_tbl[Ch]); 
}


void SPI_ProctectBits(UINT8 ProtectBits, UINT8 Ch)
{
	SPIC_ProctectBits(ProtectBits, &spicmap_tbl[Ch]);
    
}


void SPI_BlockProctect(UINT8 Enable, UINT8 Ch)
{
    SPI_hw_Proctect(0, 0);  // GPIO goes high to enable modify  WRSR 
    
	if(Enable == 1){
	    SPIC_BlkProctect(&spicmap_tbl[Ch]); 
	}
        
	else{
	    SPIC_BlkUnProctect(&spicmap_tbl[Ch]); 
	}
	SPI_hw_Proctect(1, 0);  // GPIO goes low to disable modify  WRSR 
	    
}


void SPI_hw_Proctect(UINT8 Enable, UINT8 Ch)
{
	if(Enable == 1)
	    SPIC_hw_Proctect(&spicmap_tbl[Ch]); 
	else	
        SPIC_hw_unProctect(&spicmap_tbl[Ch]); 
}


void SPI_RDID(UINT8 *VID, UINT8 *PID, UINT8 Ch)
{
	SPIC_RDID(VID, PID, &spicmap_tbl[Ch]);
    
}


 

void SPI_Initialize()
{
	
	#ifdef _SPI_TX
	
	SPIC_Transfer_Entry_Register(os_user_spi_transfer);
	os_user_spi_transfer_initial();	
	
	#endif
	
}

