#include "spi_ctrl.h"

spic_transfer_entry spic_transfer_entry_tbl[]={

	user_spi_transfer	
};



BOOL user_spi_transfer(Spi_Str *spistr)
{
	spic_fun_entry *spic_fun_ptr = &spic_fun_entry_tbl[spistr->Interface];
    

	if(spistr->Interface >= NumSPIC_Limint)
		return FALSE;
	
	spic_fun_ptr->fun_entry(spistr);                            // enter spic interface fun entry

	return TRUE;	
}


void SPIC_FUNC(Spi_Str *spistr)
{

    spic_transfer_entry *spic_transfer_ptr = (spic_transfer_entry *)&spic_transfer_entry_tbl[0];
    
    spic_transfer_ptr->transfer_entry(spistr);                  // enter spic transfer_entry    
}                                                               // normal or Threadx transfer 


void SPIC_Transfer_Entry_Register(BOOL (*transfer_entry)(Spi_Str *))
{
    spic_transfer_entry *spic_transfer_ptr = (spic_transfer_entry *)&spic_transfer_entry_tbl[0];
    
                                                                 // register spic transfer_entry               
    spic_transfer_ptr->transfer_entry = (spic_transfer_entry *)transfer_entry;    
}


