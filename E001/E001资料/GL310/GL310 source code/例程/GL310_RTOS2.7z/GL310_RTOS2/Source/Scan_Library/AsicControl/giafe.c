////////////////////////////////////////////////////////////////
// File - giafe.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"


//Wolfson AFE gain/offset register address
/*#define  AFE_REG_OFFSET_R        0x20
#define  AFE_REG_OFFSET_G        0x21
#define  AFE_REG_OFFSET_B        0x22
#define  AFE_REG_SIGN_R          0x24
#define  AFE_REG_SIGN_G          0x25 
#define  AFE_REG_SIGN_B          0x26
#define  AFE_REG_GAIN_R          0x28
#define  AFE_REG_GAIN_G          0x29
#define  AFE_REG_GAIN_B          0x2A*/

//Holtek AFE gain/offset register address
#define  AFE_REG_OFFSET_R			0x05
#define  AFE_REG_OFFSET_G			0x06
#define  AFE_REG_OFFSET_B			0x07
#define  AFE_REG_GAIN_R				0x02
#define  AFE_REG_GAIN_G				0x03
#define  AFE_REG_GAIN_B				0x04

//write AFE register
#define EMBEDDED_AFE_WAIT

int CtlAfe_WriteAFERegister(unsigned short wAddr, unsigned short wData)
{
	int i;
	unsigned char status;
	unsigned int data=0x00;
	
	data |= (unsigned int)wData;
	data |= (((unsigned int)wAddr) << 16);
	CMDASIC_WriteFourRegister(0x00a4, data);
#ifdef EMBEDDED_AFE_WAIT
	for(i = 0, status = 0x02; status & 0x02; i++)
		CMDASIC_ReadRegister(0xb0000401, &status);
	//printf("AFE serial out (%d)\n", i);
#endif	
	if(BENG_Active) {
		CMDASIC_WriteFourRegister(0x06a4, data);
#ifdef EMBEDDED_AFE_WAIT
		for(i = 0, status = 0x02; status & 0x02; i++)
			CMDASIC_ReadRegister(0xb0000a02, &status);
	//	printf("b_AFE serial out (%d)\n", i);
#endif
	}
	return True;
}

int CtlAfe_WriteAFERegister_B(unsigned short wAddr, unsigned short wData)
{
	unsigned int data=0x00;
	int i;
	unsigned char status;
	
	data |= (unsigned int)wData;
	data |= (((unsigned int)wAddr) << 16);
	CMDASIC_WriteFourRegister(0x06a4, data);
#ifdef EMBEDDED_AFE_WAIT
	for(i = 0, status = 0x02; status & 0x02; i++)
		CMDASIC_ReadRegister(0xb0000a02, &status);
	//printf("b_AFE serial out (%d)\n", i);
#endif
	return True;
}

//read AFE register
int CtlAfe_ReadAFERegister(unsigned short wAddr, unsigned short *pData)
{
	unsigned int data=0x00;
	
	data |= (((unsigned int)wAddr) << 16);
	CMDASIC_WriteFourRegister(0x00a8, data);
	CMDASIC_ReadFourRegister(0x00a8, &data);
	*pData = (unsigned short)data; 
	return True;
}

int CtlAfe_ReadAFERegister_B(unsigned short wAddr, unsigned short *pData)
{
	unsigned int data=0x00;
	
	data |= (((unsigned int)wAddr) << 16);
	CMDASIC_WriteFourRegister(0x06a8, data);
	CMDASIC_ReadFourRegister(0x06a8, &data);
	*pData = (unsigned short)data; 
	return True;
}

//write AFE GAIN
int CtlAfe_SetAFEGain(unsigned short GainR, unsigned short GainG, unsigned short GainB)
{
	int bRet;

	bRet=CtlAfe_WriteAFERegister(AFE_REG_GAIN_R,(unsigned char)GainR);
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister(AFE_REG_GAIN_G,(unsigned char)GainG);
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister(AFE_REG_GAIN_B,(unsigned char)GainB);
	if (!bRet) return False;

	return True;
}

int CtlAfe_SetAFEGain_B(unsigned short GainR, unsigned short GainG, unsigned short GainB)
{
	int bRet;

	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_GAIN_R,(unsigned char)GainR);
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_GAIN_G,(unsigned char)GainG);
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_GAIN_B,(unsigned char)GainB);
	if (!bRet) return False;

	return True;
}

//write AFE OFFSET
int CtlAfe_SetAFEOffset(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB)
{
	int bRet;
	bRet=CtlAfe_WriteAFERegister(AFE_REG_OFFSET_R,(unsigned short)(OffsetR)); //fixed Write AFE Reg 
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister(AFE_REG_OFFSET_G,(unsigned short)(OffsetG));
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister(AFE_REG_OFFSET_B,(unsigned short)(OffsetB));
	if (!bRet) return False;

	return True;
}

int CtlAfe_SetAFEOffset_B(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB)
{
	int bRet;
	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_OFFSET_R,(unsigned char)(OffsetR));
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_OFFSET_G,(unsigned char)(OffsetG));
	if (!bRet) return False;

	bRet=CtlAfe_WriteAFERegister_B(AFE_REG_OFFSET_B,(unsigned char)(OffsetB));
	if (!bRet) return False;

	return True;
}


//AFE type gain calculate
int CtlAfe_GetGainLevel(int type, int code, float *value)
{
	switch(type)
	{
		case 0: //HT82V38 AFE
			*value = (float)(76/(76-code));
			break;
		case 1: //Wolfson AFE		
			*value = (float)208/(283-code);
			break;
		default:
			*value = (float)(76/(76-code));
			break;
	}		
	return True;
}


int CtlAfe_GetGainCode(int type, float value, int *code)
{
	switch(type)
	{
		case 0: //HT82V38
			*code = (int)(76 - (float)76/value);
			break;
		case 1: //Wolfson
			*code = (int)(283 - (float)208/value);
			break;
		default :
			*code = (int)(76 - (float)76/value);
			break;
	}
	return True;
}
