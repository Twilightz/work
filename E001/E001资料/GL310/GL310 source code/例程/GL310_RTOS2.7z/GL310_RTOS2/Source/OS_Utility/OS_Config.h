#define RTOS_HEAP_SIZE                  0x20000

#define INCLUDE_OS_Queue_Delete         0

#define INCLUDE_OS_Timer_ResetOneShot   0
