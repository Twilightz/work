////////////////////////////////////////////////////////////////
// File - gisensor.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"

int DCmotor_setting(ScanParameter *pSPM)
{
	int bRet;
	int PIDDIS=0; //control moving speed, (1 adjust mtr0_duty), (0 adjust V1ref)
	//int bRet=1,i=0;
	unsigned short DCtable[52] = { //33+17, unit=duty
		0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0,
		290, 
		500, 500, 500, 500, 500, 500, 500, 500, 
		500, 500, 500, 500, 500, 500, 500, 500,
		0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0
	};

	// set motot & encoder GPIO
	///////////////////////////////////////////////////////////////
	CMDASIC_WriteRegisterBit(0x0061,4,1,0);  //gpo13_mtr_2
	CMDASIC_WriteRegisterBit(0x0059,4,1,1);  //gpo13 output
	CMDASIC_WriteRegisterBit(0x0051,4,1,1);  //gpo13 1

	CMDASIC_WriteRegisterBit(0x0061,5,1,1);  //gpo14_mtr_1
	CMDASIC_WriteRegisterBit(0x0059,5,1,1);  //gpo15 output
	//CMDASIC_WriteRegisterBit(0x0051,5,1,1);  //gpo15 1

	CMDASIC_WriteRegisterBit(0x0061,6,1,1);  //gpo15_mtr_0
	CMDASIC_WriteRegisterBit(0x0059,6,1,1);  //gpo15 output
	//CMDASIC_WriteRegisterBit(0x0051,6,1,1);  //gpo15 1

	CMDASIC_WriteRegisterBit(0x0061,2,1,1);  //gpo11_mtr_4
	CMDASIC_WriteRegisterBit(0x0059,2,1,0);  //gpo11 input
	//CMDASIC_WriteRegisterBit(0x0051,6,1,1);  //gpo11 1

	CMDASIC_WriteRegisterBit(0x0061,0,2,1);  //gpo10_mtr_5
	CMDASIC_WriteRegisterBit(0x0059,1,1,0);  //gpo10 input
	//CMDASIC_WriteRegisterBit(0x0051,6,1,1);  //gpo11 1



	// DC control register
	///////////////////////////////////////////////////////////////
								  
	//Allegro A3950 DCmotor test setting
	//CMDASIC_WriteFourRegister(0x01c0,0x00a8b9c0);  //dc_ccwon. dc_ccwoff, dc_cwon. dc_cwoff, dc_brake. dc_off
	//Sanyo LV8760T DCmotor test setting  
	CMDASIC_WriteFourRegister(0x01c0,0x00231330);  //dc_ccwon. dc_ccwoff, dc_cwon. dc_cwoff, dc_brake. dc_off

	CMDASIC_WriteTwiRegister(0x01d0,1);        //MPhLnSet
	CMDASIC_WriteRegisterBit(0x01e0,4,3,0);    //PIDX_lsft
	CMDASIC_WriteRegisterBit(0x01e0,0,1,0);    //DCDecelType=0
	CMDASIC_WriteRegisterBit(0x01e1,0,6,0x10); // DecelType2=0 DecelType1=1 CH_SYN=0
	CMDASIC_WriteTwiRegister(0x01ec,100);      //sense_period

	CMDASIC_WriteTwiRegister(0x01f0,500);      //mtr0_period
	if (PIDDIS==0) {
		// load DC motor PID table
		///////////////////////////////////////////////////////////////
		CMDASIC_WriteRegisterBit(0x01e0,7,1,0);  //dc_tbl_enb
		bRet=CMDASIC_WriteBulkData(0xb0003180, (unsigned char *)DCtable, 104);
		if (!bRet) 	return False;

		{  //Read back and check DC motor table
			short ChkDCtb[104];
			int i;
			CMDASIC_ReadBulkData(0xb0003180, (unsigned char *)ChkDCtb, 104);
			for (i=0; i<52; i++) {
				if(ChkDCtb[i]!=DCtable[i]) {
					printf("Dc motor table write error !\n");
					return False;
				}
			}
		}
		CMDASIC_WriteRegisterBit(0x01e0,7,1,1);  //dc_tbl_enb

		CMDASIC_WriteTwiRegister(0x01e8,12000);  //V1ref, adjust to control speed.
		CMDASIC_WriteTwiRegister(0x01e2,0x7000); //0x1000);  //Kp
		CMDASIC_WriteTwiRegister(0x01e4,0);      //0x1000);  //Ki 
		CMDASIC_WriteTwiRegister(0x01e6,0);      //0xff00);  //Kd
		CMDASIC_WriteRegisterBit(0x01e0,1,1,0);  //PID_dis=0

	} else {  //PIDDIS==1
		
		CMDASIC_WriteTwiRegister(0x01f6,300);    //mtr0_duty, adjust to control speed.
		CMDASIC_WriteRegisterBit(0x01e0,1,1,1);  //PID_dis=1
	}

	

	// moving by scanner motor 
	///////////////////////////////////////////////////////////////
	CMDASIC_WriteFourRegister(0x000c,0x00070000);  //CLRDC 0/1/2 CNT
	CMDASIC_WriteRegisterBit(0x0195,2,3,1); //DCMot0En=1
	CMDASIC_WriteRegisterBit(0x0196,0,5,0); //multimotor=0 motoren=0
	CMDASIC_WriteRegister(0x0198, 0x00);    //motor0mod=0 controled by scanner motor
	CMDASIC_WriteTwiRegister(0x0156,1);     //STEPNO=1
	CMDASIC_WriteTwiRegister(0x015e,1);     //FSHDEC=1
	CMDASIC_WriteRegisterBit(0x003e,0,3,1); //DECSEL=1
	CMDASIC_WriteRegisterBit(0x003f,0,5,1); //STOPTIM=1
	//bRet=CtlMotor_SetMotorDirect(1);
	//bRet=CtlMotor_EnableFastMove(1);
	//bRet=CtlMotor_SetFeedSteps(Steps); //FEEDL move distance
	//bRet=CtlMotor_SetMotorPowerBit(1);

	//if (((pSPM->spADFscan)&0x0f)==3) {
	//	unsigned int pfed;
	//	CMDASIC_ReadFourRegister(0x0174,&pfed);
	//	CMDASIC_WriteFourRegister(0x01FC,(unsigned int)(pfed*0.8) );  //DCprefed
	//	CMDASIC_WriteTwiRegister(0x01e8,6000*4);   //V1ref
	//	CMDASIC_WriteTwiRegister(0x01ea,6000*1);   //V2ref
	//	CMDASIC_WriteRegisterBit(0x01e1,6,1,1);    //DCfast_fed
	//}

	//resolution 300 or 600dpi
	//CMDASIC_WriteRegisterBit(0x0060,7,1,1);       //gpo9_cmode=1 300dpi, =0 600dpi
	//CMDASIC_WriteFourRegister(0x0104,0x00020001); //TGW TGSHLD
	//CMDASIC_WriteFourRegister(0x0094,0x04010002); //MODSTR MODPULSE PULSELEN

	CMDASIC_WriteRegisterBit(0x006a,0,3,5);       //SSLEDEN=1, W_LED=0, CIS_LED=1

	CtlMotor_SetMotorDirect(1);
	CtlMotor_EnableFastMove(0);
	if (((pSPM->spADFscan)&0x0f)==0) bRet=CtlMotor_SetFeedSteps(300*1*48*2); //100);
	CtlMotor_SetMotorPowerBit(1); //1);
		
	CMDASIC_WriteFourRegister(0x0244, 0x01000102);         //DCXQueue Sensor_T
	CMDASIC_WriteTwiRegister(0x0230, 0x0800); //0x0808);   //AEncoder=0, A2DPulseEn=0, DCXShade=0, ManualDir=1
	CMDASIC_WriteTwiRegister(0x0232, (unsigned short)CtlSensor_wTGPeriod); //MinPixel
	CMDASIC_WriteRegisterBit(0x0230,0,3,1);                //1=DCXEn, 4=DCXEn1
	CMDASIC_WriteTwiRegister(0x0234, 16);                  //PPhLnSet
	CMDASIC_WriteTwiRegister(0x0236, 0x0706);              //DCXSigMux

	CMDASIC_WriteFourRegister(0x000c, 0x00200000); //snr_init
	CMDASIC_WriteRegisterBit(0x0230,1,1,1);        //DCX_Str

	return True;
}









