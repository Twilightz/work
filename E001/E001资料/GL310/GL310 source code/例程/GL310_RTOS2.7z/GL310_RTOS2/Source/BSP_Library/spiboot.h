#ifndef _SPIBOOT_H_
#define _SPIBOOT_H_

#include <stdio.h>
#include <string.h>

 
#include "dtype.h"				//Variable type define


#endif 

