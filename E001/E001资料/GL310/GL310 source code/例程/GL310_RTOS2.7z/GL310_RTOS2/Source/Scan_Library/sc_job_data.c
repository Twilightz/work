//-------------------
//	File: sc_job_adf.c
//	Date: 2014.07.31
//-------------------

//#include "sc_api.h"
#include "cmd.h"
#include "sc_job.h"
//#include "tx_api.h"

extern unsigned int Jpeg_stradr, Jpeg_endadr;
extern unsigned int Jpeg_stradr_B, Jpeg_endadr_B;

int Data_start(JOB_SCAN_T *job, int dup)  // dup = 0(A), 1(B)
{
	DATA_FLOW_T *d = &job->data[dup];
	memset(d, 0, sizeof(DATA_FLOW_T));
	d->expect.page = (job->acq.page? job->acq.page: MAX_VALID_PAGE);
	if(d->expect.page < MAX_VALID_PAGE)
		d->event |= EVENT_PAGE_COUNT_DOWN;
	d->expect.size = MAX_VALID_SIZE;
	d->expect.line = MAX_VALID_LINE;
	if(job->img.format == I3('JPG')) {
		if(dup == 0) {
			d->mem.next = d->mem.start = Jpeg_stradr;
			d->mem.end = Jpeg_endadr;
		}
		else if(dup == 1) {
			d->mem.next = d->mem.start = Jpeg_stradr_B;
			d->mem.end = Jpeg_endadr_B;
		}
	}
	else if(job->img.format == I3('RAW')) {
		if(dup == 0) {
			d->mem.next = d->mem.end = d->mem.start = 0xB0100000;
		}
		else if(dup == 1) {
			d->mem.next = d->mem.end = d->mem.start = 0xB0200000;
		}
	}
	else
		dprintf("Data_start() - parameter error: job.img.format=%s\n", &job->img.format);
	return TRUE;
}

int Data_Deliver(JOB_SCAN_T *job, int dup) // dup = 0(A), 1(B)
{
	DATA_FLOW_T *d = &job->data[dup];
	int size = 0;
	// is reading data process complete?
	if(d->event & EVENT_DATA_SUBMIT) {
		size = d->reading.size;
		d->event &= ~EVENT_DATA_SUBMIT;
		if(size > 0) {
			d->read.size += size;
			d->reading.size -= size;
			if(job->img.format == I3('JPG')) {
				if(dup == 0) 
					SET_Clear_Jpeg_size(size);
				else if(dup == 1)
					SET_b_Clear_Jpeg_size(size);
				d->mem.next += size;
				if(d->mem.next >= d->mem.end) {
					if(d->mem.next > d->mem.end) {
						dprintf("Data_Committed() Error: Jpeg data over boundary\n");
					}
					d->mem.next = d->mem.start;
					//dprintf("Jpeg[%d] ring buffer restart\n", dup);
				}
			}
			else if(job->img.format == I3('RAW')) {
				int LineSize = (job->img.bit * job->img.dot.w + 7) / 8;
				int valid_line = size / LineSize;
				if(dup == 0)
					SET_SW_VALID_LINE(valid_line);
				else if(dup == 1)
					SET_b_SW_VALID_LINE(valid_line);
			}
		}
			// is one page complete
		if(d->read.size >= d->expect.size) {
			dprintf("Info %c scanned.page(%d).size(%d) expect.size(%d) reading.size(%d) read.size(%d)\n", dup+'A', d->scanned.page, d->scanned.size, d->expect.size, d->reading.size, d->read.size);
			d->read.size = 0;
			d->read.page++;
			d->expect.size = MAX_VALID_SIZE;
			d->expect.line = MAX_VALID_LINE;
			if((d->event & EVENT_DOCUMENT_END) == 0) {
				if(d->read.page >= d->expect.page) {
					d->event |= EVENT_DOCUMENT_END;
				}
				else {
					d->event &= (~EVENT_PAGE_END);
				}	
			}
		}
	}
	return size;
}

int Data_IsReady(JOB_SCAN_T *job, int dup)  // dup = 0(A), 1(B)
{
	DATA_FLOW_T *d = &job->data[dup];
	U32 available_size;
	// is reading data process complete?
	if(d->event & EVENT_DATA_SUBMIT) {
		Data_Deliver(job, dup);
	}
	d->status = GET_STATUS(clr);
	// check paper jam here
	if(d->status & (DOCJAM(1)|MOVEJAM(1)|MOVEERR(1))) {
		d->event |= EVENT_PAPER_JAM;
	}
	// check for available image data
	if(job->img.format == I3('JPG')) {
		int jpeg_valid_size, jpeg_valid_page;
		if(dup == 0) {
			jpeg_valid_size = GET_Jpeg_Valid_size(0);
			if(jpeg_valid_size & page_flg(1)) {
				jpeg_valid_size &= ~page_flg(1);
				jpeg_valid_page = GET_Jpeg_Valid_Page(0);
				d->scanned.page = d->read.page + jpeg_valid_page;
				if(d->expect.size >= MAX_VALID_SIZE) {
					d->expect.size = GET_SW_PAGE_SIZE(0);
					d->expect.line = GET_SW_PAGE_LINE(0);
				}
			}
		}
		else if(dup = 1) {
			jpeg_valid_size = GET_Jpeg_Valid_size(1);
			if(jpeg_valid_size & page_flg(1)) {
				jpeg_valid_size &= ~page_flg(1);
				jpeg_valid_page = GET_Jpeg_Valid_Page(1);
				d->scanned.page = d->read.page + jpeg_valid_page;
				if(d->expect.size >= MAX_VALID_SIZE) {
					d->expect.size = GET_SW_PAGE_SIZE(1);
					d->expect.line = GET_SW_PAGE_LINE(1);
				}
			}
		}
		if((d->read.size + jpeg_valid_size) < d->expect.size) {
			d->scanned.size = d->read.size + jpeg_valid_size;
		}
		else {
			d->scanned.size = d->expect.size;
		}
		available_size = d->scanned.size - d->read.size;
		if(available_size > (d->mem.end - d->mem.next)) {
			available_size = d->mem.end - d->mem.next;
			d->scanned.size = d->read.size + available_size;
			//dprintf("JPEG[%d] touch the end of image buffer\n", dup);
		}

	}
	else if(job->img.format == I3('RAW')) {
		int sw_valid_line, valid_page, valid_size;
		int LineSize = (job->img.bit * job->img.dot.w + 7) / 8;
		if(dup == 0) {
			sw_valid_line = GET_SW_VALID_LINE(0);
			if(sw_valid_line & raw_page_flg(1)) {
				sw_valid_line &= (~raw_page_flg(1));
				valid_page = GET_Valid_Page(0);
				d->scanned.page = d->read.page + valid_page;
				if(d->expect.size >= MAX_VALID_SIZE) {
					d->expect.line = GET_SW_PAGE_LINE(0);
					d->expect.size = d->expect.line * LineSize;
				}
			}
		}
		else if(dup == 1) {
			sw_valid_line = GET_SW_VALID_LINE(1);
			if(sw_valid_line & raw_page_flg(1)) {
				sw_valid_line &= (~raw_page_flg(1));
				valid_page = GET_Valid_Page(1);
				d->scanned.page = d->read.page + valid_page;
				if(d->expect.size >= MAX_VALID_SIZE) {
					d->expect.line = GET_SW_PAGE_LINE(1);
					d->expect.size = d->expect.line * LineSize;
				}
			}
		}
		valid_size = sw_valid_line * LineSize;
		if((d->read.size + valid_size) < d->expect.size) {
			d->scanned.size = d->read.size + valid_size;
		}
		else {
			d->scanned.size = d->expect.size;
		}
	}
	d->reading.size = d->scanned.size - d->read.size;
//	if(d->reading.size > 0) {
		//dprintf("Info %c scanned.page(%d).size(%d) reading.size(%d) read.size(%d)\n", dup+'A', d->scanned.page, d->scanned.size, d->reading.size, d->read.size);
		if(d->event & EVENT_PAGE_COUNT_DOWN) {
			if((d->read.page + 1) >= d->expect.page) {
				SET_AUTO_ADF(0);
				d->event &= ~EVENT_PAGE_COUNT_DOWN;
			}
		}
		if(d->scanned.size >= d->expect.size) {
			d->event |= EVENT_PAGE_END;
			//dprintf("Info %c Page End (#%d)\n", dup+'A', d->read.page);
			if((d->read.page+1) >= d->expect.page) {
				d->event |= EVENT_DOCUMENT_END;
			}
			if(((d->read.page+1) >= d->scanned.page) && (d->status & ADFSNR(1)) && (d->status & DOCSNR(1))) {
				//dprintf("Info %c Document End (#%d)\n", dup+'A', d->read.page);
				d->event |= EVENT_DOCUMENT_END;
			}
		}
//	}
//	else {
//		//tx_thread_sleep(2);
//		dprintf("Info %c scanned.page(%d).size(%d) expect.size(%d) reading.size(%d) read.size(%d)\n", dup+'A', d->scanned.page, d->scanned.size, d->expect.size, d->reading.size, d->read.size);
//	}
	//else {
	//	if((d->read.page >= d->expect.page) || ((d->status & ADFSNR(1)) && (d->status & DOCSNR(1)))) {
	//		dprintf("Info %c Document End (#%d)\n", dup+'A', d->read.page);
	//		d->event |= EVENT_DOCUMENT_END;
	//	}
	//}
	if(d->reading.size == 0)
		d->event |= EVENT_DATA_SUBMIT;

	return d->reading.size;
}

U32 Data_Submit(JOB_SCAN_T *job, int dup, int *size)
{
	DATA_FLOW_T *d = &job->data[dup];
	//dprintf("Read Image %c request(%d) -> ", duplex-1 + 'A', size);
	//if(*size > (d->scanned.size - d->read.size))
	//	*size = d->scanned.size - d->read.size;
	if(job->img.format == I3('RAW')) {
		U32 line_size = (job->img.bit * job->img.dot.w + 7) / 8;
		*size = *size / line_size * line_size;
	}
	if(*size > d->reading.size) {
		*size = d->reading.size;
	}
	else if(*size < d->reading.size) {
		d->event &= ~(EVENT_PAGE_END | EVENT_DOCUMENT_END);
	}
	d->reading.size = *size;
	d->event |= EVENT_DATA_SUBMIT;
	//dprintf("reply(%d)\n", size);
	return (U32)d->mem.next;
}


//int DataFlow_Abort(DATAFLOW_T *doc)
//{
//	return Abort_Image(doc->pipe);
//}
