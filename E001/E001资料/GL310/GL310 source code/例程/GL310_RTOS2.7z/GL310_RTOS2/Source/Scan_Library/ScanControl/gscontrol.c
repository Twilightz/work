////////////////////////////////////////////////////////////////
// File - gscanctrl.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

//#include <Windows.h>
#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "..\asiccontrol\giasiccontrol.h"
//#include "gscanctrl.h"
#include "gscanctrldb.h"

// change the definition from main.c to here
unsigned int solu = 300;//default

unsigned int RdOnceLine=400; //400;
unsigned int RdBufSize;
unsigned char *RdBuffer;

extern int ResetJPGImgAdr(void);
extern int ResetJPGthumbImgAdr(void);

//extern int Duplex_Calibration;
//extern int DuplexscanFlag;
unsigned int DuplexscanFlag = 0; // change the definition from FB_shadingscan.c

//extern int mEngineScan;
int mEngineScan = 0;	// change from main_scantest.c to here
//extern unsigned char DoCalibrationFlag;
unsigned char DoCalibrationFlag = 0;	// change the definition here (from main.c)

extern int MultiMotorSet(int para1);
extern int My_LoadPPSCurveToMultiTable(float *inPPSCurve, int inCurveLen, float TargetPPS, int StepUnit, int Vref, int *retstep);


int SetReadBuffer(ScanParameter *pSPM) 
{
	unsigned int dwLineSize;

	dwLineSize = pSPM->spScanLinePixels * pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1)/8;
	RdBufSize=(dwLineSize*RdOnceLine/64+1)*64;    //let read buffer be multiple of 64
	RdBuffer= (unsigned char*)malloc(RdBufSize);  //prepare read image buffer
	if (RdBuffer == NULL)	{
		return False;
	}

	return True;
}


//****************************************************************************
//load ASIC/AFE timing register from CCD_ColorASICTiming/CCD_ColorAFEiming
//****************************************************************************
int WriteTiming(unsigned char iIdx)  //iIdx= timing 1,2,4,8
{
	unsigned int iRegNum, i, itm, bRet=1;

	switch(iIdx){
		case 1:
			itm=0;
			CCD_ColorASICTiming[itm].TbLength=sizeof(CCD_Timing_X1)/sizeof(unsigned int);
			CCD_ColorAFETiming[itm].TbLength=sizeof(AFE_Timing_X1)/sizeof(unsigned short);
			break;
		case 2:
			itm=1;
			CCD_ColorASICTiming[itm].TbLength=sizeof(CCD_Timing_X2)/sizeof(unsigned int);
			CCD_ColorAFETiming[itm].TbLength=sizeof(AFE_Timing_X2)/sizeof(unsigned short);
			break;
		case 4:
			itm=2;
			CCD_ColorASICTiming[itm].TbLength=sizeof(CCD_Timing_X4)/sizeof(unsigned int);
			CCD_ColorAFETiming[itm].TbLength=sizeof(AFE_Timing_X4)/sizeof(unsigned short);
			break;
		case 8:
			itm=3;
			CCD_ColorASICTiming[itm].TbLength=sizeof(CCD_Timing_X8)/sizeof(unsigned int);
			CCD_ColorAFETiming[itm].TbLength=sizeof(AFE_Timing_X8)/sizeof(unsigned short);  //HL modify
			break;
		default:
			return False;
			break;
	}	

	//load ASIC timing register
	iRegNum=CCD_ColorASICTiming[itm].TbLength;
	for (i=0; i<iRegNum; i=i+2) {
		bRet=CMDASIC_WriteFourRegister((unsigned short)CCD_ColorASICTiming[itm].Timing[i], CCD_ColorASICTiming[itm].Timing[i+1]);
		if(!bRet) return False;
	}

	//load AFE timing register
	iRegNum=CCD_ColorAFETiming[itm].TbLength;
	for (i=0; i<iRegNum; i=i+2) {
		bRet=CtlAfe_WriteAFERegister(CCD_ColorAFETiming[itm].Timing[i], CCD_ColorAFETiming[itm].Timing[i+1]);
		if(!bRet) return False;
	}

	return True;

}



//***********************************************************
// move motor 
// fpps: moving speed, unit = pps
// Steps: moving lentgh, unit = motor steps
// iDir: moving direction, 1=forwared, 0=backward
//***********************************************************

int Sctl_MoveMotor(float fpps, unsigned int Steps, int iDir)
{
	int usstep,bRet=1;
	int crID=0, usunit=4;

	if(DuplexscanFlag || mEngineScan){
		usunit = 1; //Feed paper
		
		bRet=CtlMotor_SetMotorCurrent(0,1); //Setup motor current 
		if (!bRet) return False;
		if(!DoCalibrationFlag)
			bRet=CtlMotor_SetScanTableUnit(2); //Set motor step 
			if (!bRet) return False;
	}
	else{
		if(solu==300)
			usunit = 1;
	}

	bRet=CtlMotor_SetTBTime(1);
	if (!bRet) return False;

	if(iDir){
		bRet=CtlMotor_SetMotorDirect((unsigned char)iDir); 
		if (!bRet) return False;
	}
	else{
		bRet=CtlADFMotor_SetMotorDirect((unsigned char)iDir); 
		if (!bRet) return False;
	}

	//crID = ( (fpps > 2095.0f) ? 0 : 1); //select motor curve, CurveData1 or CurveData2
	crID = 1; //( (fpps > 2095.0f) ? 0 : 1); //select motor curve, CurveData1 or CurveData2

	bRet=CtlMotor_LoadPPSCurveToFastTable(MotorTableSet[crID].fPPSTable
		, MotorTableSet[crID].TbLength, fpps, usunit, &usstep);
	if (!bRet)
		return False;

	bRet=CtlMotor_EnableFastMove(1);
	if (!bRet) return False;

	bRet=CtlMotor_SetFeedSteps(Steps*usunit-usstep*2);
	if (!bRet) return False;

	bRet=CtlMotor_SetMotorPowerBit(1);
	if (!bRet) return False;

	bRet=CtlMotor_SetMotorStartMove();
	if (!bRet) return False;

	return True;
}


//***********************************************************

int Sctl_SetScanParameter(ScanParameter *pSPM)
{
	int bRet=1;
	int	iColorBits;

	CMDASIC_WriteRegisterBit(0x0007, 0, 4, 0);   //CCDLMT
	CMDASIC_WriteFourRegister(0x0200, 0x00000001);  //clr TG

	iColorBits = pSPM->spPixelDepth * ( (pSPM->spImageType == IMAGE_COLOR) ? 3 : 1);

	bRet=CtlSensor_SetDummyLine((unsigned char)((pSPM->spDummyLines < 0x1f) ? pSPM->spDummyLines : 0x1f));  
	if (!bRet) return False;

	bRet=CtlMotor_SetStartStop( (unsigned char)((pSPM->spDisBackTrack == 1) ? 0 : 1));
	if (!bRet) return False;

	bRet=WriteTiming(pSPM->spTimingIdx);
	if (!bRet) return False;

	bRet=CtlImage_SetColorDepth(iColorBits, pSPM->spMonoChannel);
	if (!bRet) return False; 

	bRet=CtlSensor_SetDummyPixel();
	if (!bRet) return False; 

	bRet=CtlSensor_XResSet(pSPM);
	if (!bRet) return False;

	bRet=CtlSensor_YResSet(pSPM);
	if (!bRet) return False;

	bRet=CtlSensor_LperiodSet(pSPM);
	if (!bRet) return False;

	//CCDLMT
	bRet=CMDASIC_WriteRegisterBit(0x0007, 0, 4, pSPM->spCCDLMT);   
	if (!bRet) return False;

	bRet=CtlMotor_EnableAutoGoHome(pSPM->spAutoGoHome);
	if (!bRet) return False;

	bRet=CtlImage_EnableGamma(pSPM->spGammaMapping);
	if (!bRet) return False;

	bRet=CtlImage_EnableShading(pSPM->spShading);
	if (!bRet) return False;

	bRet=CtlImage_RamSet_ImageBuffer(pSPM);
	if (!bRet) return False;

	bRet=CtlMotor_SetMotorDirect(1);
	if (!bRet) return False;

	if (!pSPM->spStillMode) {
		bRet=CtlMotor_MotorTable_setting(pSPM);
		if (!bRet) return False;
	}

	if (pSPM->spADFscan) { //ADF scan
		bRet=CtlADF_ADFsetting(pSPM);
		if (!bRet) return False;
		
		if(pSPM->spDualscan == 2){ 
			bRet=CtlADF_LEDPWR(1);
			if (!bRet) return False;
		}
	} 
	else { 
		if (!pSPM->spStillMode)
		{
			if(pSPM->spDualscan){
				bRet=CtlMotor_CalculateFeedReg((unsigned int)(pSPM->spScanBeginLine / ((float)CtlSensor_iOptRes / ADFMotorGear)));
				if (!bRet) return False;

				Api_CtlADF_ADFMotorOpen();//Motor Driver config
				bRet=CtlMotor_SetMotorPowerBit(1);
				if (!bRet) return False;
			}
			else{  //Flatbed scan
				bRet=CtlMotor_CalculateFeedReg((unsigned int)(pSPM->spScanBeginLine / ((float)CtlSensor_iOptRes / MotorGear)));
				if (!bRet) return False;

				bRet=CtlMotor_SetMotorPowerBit(1);
				if (!bRet) return False;
			}
			bRet=CtlMotor_WriteMotorRemainder(0,0);  //bRet=CtlMotor_SetZ1Z2Value();
			if (!bRet) return False;
		} else {  ////Flatbed still scan
			bRet=CtlMotor_SetFeedSteps(1);
			if (!bRet) return False;
			bRet=CtlMotor_EnableFastMove(0);
			if (!bRet) return False;
			bRet=CtlMotor_SetMotorPowerBit(0);
			if (!bRet) return False;
			bRet=CMDASIC_WriteRegisterBit(0x0230,3,1,1);
			if (!bRet) return False;
		}
	}

	if ((pSPM->spJPEGENC&0x0f)!=0) {
		JPG_setting(pSPM);
	} else 	{
		CMDASIC_WriteRegister(0x03a0, 0x00);
	}

	bRet=CtlImage_EnablePattern(pSPM->spTestImage);
	if (!bRet) return False;

	if(pSPM->spDualscan) {
		//duplex scan AB side
		bRet=BENG_setting(pSPM);
		if (!bRet) return False;
	} else 	{
		//simplex scan & A side
		bRet=CMDASIC_WriteRegister(0x0630, 0x00); 
		if (!bRet) return False;
	}

	//simplex scan & B side
	if((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1)) {
		bRet=CMDASIC_WriteRegisterBit(0x0630, 0, 5, 0x19);  //b_afe_sel
		if (!bRet) return False;
	}

	
	//IMGLMT, how many gray lines make one color line
	bRet=CMDASIC_WriteRegisterBit(0x02a0,0,4,(unsigned char)((CMDASIC_RegTable[0x0630].nValue & 0x02) ? ((pSPM->spCCDLMT+1)/2-1) : pSPM->spCCDLMT));
	if (!bRet) return False;

	//horizontal mirror function
	bRet=CMDASIC_WriteRegisterBit(0x03a1, 0, 4, pSPM->spMirror & 0x0f); 
	if (!bRet) return False;

	bRet=CMDASIC_WriteRegisterBit(0x09a1, 0, 4, (pSPM->spMirror & 0xf0)>>4); 
	if (!bRet) return False;


	//{ //DR-150, DC motor setting
	//	CMDASIC_WriteRegisterBit(0x0195,2,3,0);  //DCMot0En
	//	bRet=DCmotor_setting(pSPM);
	//	if (!bRet) return False;
	//}

	if (pSPM->spStillMode) {
		bRet=CMDASIC_WriteRegisterBit(0x0230,3,1,1);  //DCXShade = 1
		if (!bRet) return False;	
	} else	{
		bRet=CMDASIC_WriteRegisterBit(0x0230,3,1,0);  //DCXShade = 1
		if (!bRet) return False;		
	}


	bRet=CtlImage_CMatrix_Default(pSPM);
	if (!bRet) return False;

	if((pSPM->spImageType==IMAGE_GRAY)&&(pSPM->spMonoChannel==CHANNEL_TRUE_CISLED)) {
			bRet=CtlImage_TrueGray_CISLED(pSPM);
			if (!bRet) return False;
	} else if((pSPM->spImageType==IMAGE_COLOR)&&(pSPM->spMonoChannel==CHANNEL_TRUE_Matrix)) {
			bRet=CtlImage_TrueGray_Matrix(pSPM);
			if (!bRet) return False;
	} else {
		CMDASIC_WriteRegisterBit(0x0001,2,1,0);  //TRUEGRAY
		CMDASIC_WriteRegisterBit(0x0008,5,1,0);  //LEDADD
	}

//HL debug
#if 1
	//CMDASIC_WriteFourRegister(0x0210, 0x00000044);
	//CMDASIC_WriteFourRegister(0x0214, 0x0000007f);
	//CMDASIC_WriteFourRegister(0x0218, 0x00000a9f);
	CtlImage_Shading_AfterLoad(pSPM);
#endif

	bRet=CMDASIC_WriteRegisterBit(0x0003,4,1,1); //LAMPPWR
	if (!bRet) return False;

	/*
	//LineArt 
	{
		CMDASIC_WriteTwiRegister(0x0348,0x6060); //BWLOW BWHI
		CMDASIC_WriteRegisterBit(0x0001,4,1,1); //LINEART
	}
	*/


	//For each scanning, must clear SCANCNT before starting process
	bRet=CtlImage_ClrCounter();
	if (!bRet) return False;

	return True;
}


//***********************************************************

int Sctl_StartScan(ScanParameter *pSPM) 
{
	int bRet;
#ifdef _WIN32
	bRet=SetReadBuffer(pSPM);
	if (!bRet)	return False;
#endif
	if (pSPM->spJPEGENC & 0x0f) {
		ResetJPGImgAdr();
		ResetJPGthumbImgAdr();
	}

	if (pSPM->spADFscan & 0x0f) //set adfsel =0 when ADF scan start
	{
		CtlADF_SetADFSEL(1);
		//Set GPIO40 as ADF DOC SENSOR
		CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
		CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
		CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR
	}
	else if(DuplexscanFlag)
	{
		CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
		CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
		CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR
	}
	else
	{
		//Set GPIO36 as FB HOME SENSOR
		CMDASIC_WriteRegisterBit(0x65,1,1,0); //Enable GPIO36
		CMDASIC_WriteRegisterBit(0x54,3,1,0); //GPIO36 OUTPUT VALUE
		CMDASIC_WriteRegisterBit(0x5c,3,1,1); //GPIO36 DIR
	}

	bRet=CtlImage_EnableScan(True);
	if (!bRet)	return False;
			
	bRet=CtlMotor_SetMotorStartMove();  
	if (!bRet) return False;

	//bRet=Sctl_ChkScanDataReady();
	//if (!bRet) return False;

#if 0  //for debug read state machine code
		while (-1){
			unsigned int data1;
			unsigned char nVal;

			if(_kbhit()) {
				printf("......cancel , process will stop!!!\n");
				_getch();

				CtlMotor_SetFeedSteps(0);
				CtlMotor_SetMotorPowerBit(0);
				break;
			}

			CMDASIC_ReadFourRegister(0x0450,&data1);
			printf(".. 0x%08x \n",data1);
			//CMDASIC_ReadFourRegister(0x0400,&data1);
			printf(".. 0x%08x \n",data1);

			//nVal=0x00;
			//if (CMDASIC_ReadRegister(0x0401,&nVal) ) {
			//	if ( (nVal & 0x01) ) {
			//		continue;
			//	} else {
			//		break;
			//	}
			//} else {
			//	break;
			//}
		}

		//return False;
#endif

	return True;

}



int Sctl_ChkScanDataReady(void) 
{
	int bRet, ScanFinish=0;
	unsigned int dwStart;
	unsigned int ValidLine, status;

  	dwStart = gettickcount();
	//check valid line is not zero
	while (-1){  

		status=0x00000000;
		if(CMDASIC_ReadFourRegister(0x0400,&status)) { //check DOCJAM
			if(status & 0x00000008) {
				printf("papger Jam happened \n");
				return False;
			}
		} else
			return False;

		ValidLine=0x00000000;
		if(CMDASIC_ReadFourRegister(0x0408,&ValidLine)) {
			if (ValidLine == 0) {
				if( gettickcount() - dwStart >= 60000) {
					bRet=False;
					break;
				} else { 
					continue;
				}

			} else {
				bRet=True;
				break;
			}
		} else {
			bRet=False;
			break;
		}

	}
	if (!bRet) 	return False;


	return True;


}





//***********************************************************

int Sctl_StopScan(ScanParameter *pSPM) 
{
	int bRet=1;
	unsigned short data;

	free(RdBuffer);  //free read buffer

	bRet=CtlImage_EnableScan(False); 
	if (!bRet) return False;

	if (pSPM->spADFscan & 0x0f) //set adfsel =0 when ADF scan finished
		CtlADF_SetADFSEL(0);
#if 0
	//CMDASIC_Debug_Dump();
	printf("\n");
	CtlAfe_ReadAFERegister(0x01,&data);  printf("AFE reg0x01 = 0x%02x \n",data);
	CtlAfe_ReadAFERegister(0x02,&data);  printf("AFE reg0x02 = 0x%02x \n",data);
	CtlAfe_ReadAFERegister(0x03,&data);  printf("AFE reg0x03 = 0x%02x \n",data);

	CtlAfe_ReadAFERegister_B(0x01,&data);  printf("AFE reg0x01 = 0x%02x \n",data);
	CtlAfe_ReadAFERegister_B(0x02,&data);  printf("AFE reg0x02 = 0x%02x \n",data);
	CtlAfe_ReadAFERegister_B(0x03,&data);  printf("AFE reg0x03 = 0x%02x \n",data);
#endif
	//Wolfson AFE OEB set low & input
	//CMDASIC_WriteRegisterBit(0x0058,5,1,1);  //GPIO6
	//CMDASIC_WriteRegisterBit(0x0050,5,1,1);  //GPIO6
	//CMDASIC_WriteRegisterBit(0x0058,5,1,0);  //GPIO6

	return True;

}



int Sctl_ADFFeedPaper(int dist) 
{
	//CtlADF_DetectADFConnect(&isADFConnect);
	//if(isADFConnect) {
		CtlADF_SetADFSEL(1);
		CtlADF_ADFMotorOpen();
		Sctl_MoveMotor(1000, dist, 1);
		CtlMotor_WaitMotorStop();
		CtlADF_ADFMotorClose();
	//}
	return True;
}



int Sctl_CheckADFPaperReady(int *status) 
{
	int isDocEmpty=0;
	
	CtlADF_SetADFSEL(1);
	
	//Enable ADF switch
	CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
	CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
	CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR
	CtlADF_ADFMotorOpen();

	CtlADF_GetDocumentSensor(&isDocEmpty);

	*status = (!isDocEmpty) ? True : False;

	CtlADF_ADFMotorClose();
	CtlADF_SetADFSEL(0);

	return True;
}


int Sctl_CheckADFScanFinish(ScanParameter *pSPM, int *status)
{

	unsigned short scnum;
	int isDocEmpty=0;
	int isADFEmpty=0;
	unsigned int bufstate;
	unsigned int  wtick;

	if ( (pSPM->spADFscan & 0x0f) == 0x01 ) { //single ADF

		while(1) {
			CtlADF_GetADFSensor(&isADFEmpty);
			if (isADFEmpty) {   //ADF high
				break;
			}
		}

		//check DOC sensor
		CtlADF_GetDocumentSensor(&isDocEmpty);
		if (!isDocEmpty) {
			*status = False;
		} else {
			*status = True;
		}

		return True;

	}


	if ( (pSPM->spADFscan & 0x0f) == 0x02 ) {  //auto ADF
	
		wtick = (unsigned int)(pSPM->spExposureTime * (pSPM->spCCDLMT+1) * pSPM->spMotorResolution * 2 * 1.5);  //ms unit
	
		while(1) {
			//check scan finish number
			CtlADF_GetADFScNum(pSPM, &scnum);
			if (scnum > 0) {
				*status = False;
				return True;
			}

			Sctl_BufferState(pSPM, &bufstate);
			if(bufstate>0) {
				*status = False;
				return True;			
			} 

			CtlADF_GetADFSensor(&isADFEmpty);
			if (isADFEmpty) {   //ADF high
				Sctl_BufferState(pSPM, &bufstate);
				if(bufstate>0) {
					*status = False;
					return True;			
				} else 	{
					sleep(wtick);
					Sctl_BufferState(pSPM, &bufstate);
					if (bufstate > 0) {
						*status = False;
						return True;				
					} else {
						CtlADF_GetADFSensor(&isADFEmpty);
						if (isADFEmpty) {   //ADF high
							*status = True;
							return True;					
						}
					}				
				
				}
			}		
		}
	}


	return True;

/*
	unsigned short scnum;
	int isDocEmpty=0;
	int isADFEmpty=0;
	unsigned int bufstate;
	unsigned int  wtick;
	
	wtick = pSPM->spExposureTime * (pSPM->spCCDLMT+1) * pSPM->spMotorResolution * 2 * 1.5;  //ms unit
	
	while(1) {
		//check scan finish number
		CtlADF_GetADFScNum(pSPM, &scnum);
		if (scnum > 0) {
			*status = False;
			return True;
		}

		Sctl_BufferState(pSPM, &bufstate);
		if(bufstate>0) {
			*status = False;
			return True;			
		} 

		CtlADF_GetDocumentSensor(&isDocEmpty);
		CtlADF_GetADFSensor(&isADFEmpty);
		if (isDocEmpty && isADFEmpty) { //ADF & DOC high in the same time
			Sctl_BufferState(pSPM, &bufstate);
			if(bufstate>0) {
				*status = False;
				return True;			
			} else 	{
				sleep(wtick);
				Sctl_BufferState(pSPM, &bufstate);
				if (bufstate > 0) {
					*status = False;
					return True;				
				
				} else {
					*status = True;
					return True;
				}				
				
			}
		}		

		
	}
	//return True;
*/

/*
	unsigned short scnum;
	unsigned int mstatus;
	unsigned char endbyte;
	int isDocEmpty=0;

//only use for one table ADF scan
	while(1) {
		//check scan finish number
		CtlADF_GetADFScNum(pSPM, &scnum);
		if (scnum > 0) {
			*status = False;
			return True;
		}

		//check DOC sensor
		CtlADF_GetDocumentSensor(&isDocEmpty);
		if (isDocEmpty) {
			*status = True;
			return True;
		}

		CMDASIC_ReadFourRegister(0x0450,&mstatus); 
		//printf(" ..main task 0x%08x \n",mstatus);
		if ((mstatus & 0x0000f000) != 0x00009000)  //mask=9 or 9��3
			break;
	}


	//check DOC sensor
	CtlADF_GetDocumentSensor(&isDocEmpty);
	if (!isDocEmpty) {
		*status = False;
		return True;
	}

	*status = True;
	return True;
*/


/*
	unsigned short scnum;
	//unsigned int valid;
	unsigned char endbyte;
	int isDocEmpty=0;

	//check scan finish number
	CtlADF_GetADFScNum(pSPM, &scnum);
	if (scnum > 0) {
		*status = False;
		return True;
	}

	//check valid data
	//if((pSPM->spADFscan)&0x0f) 	{
	//	CMDASIC_ReadFourRegister(0x03d4,&valid);  //Jpeg_Valid_size
	//	valid &= 0x7fffffff;	
	//}	else	{
	//	CMDASIC_ReadFourRegister(0x0408,&valid);  //RAW_Valid_line
	//	valid &= 0x001fffff;
	//}
	//if (valid > 0) {
	//	*status = False;
	//	return True;
	//}

	//check DOC sensor
	CtlADF_GetDocumentSensor(&isDocEmpty);
	if (!isDocEmpty) {
		*status = False;
		return True;
	}

	//check end_scan status
	if ( (pSPM->spADFscan & 0x0f) == 0x02 ) { // auto adf scan
		CtlMotor_LDMReadOne(0x0583, (unsigned char *)&endbyte);
		if ((endbyte&0x80)==0x00) {
			*status = False;
			return True;
		}
	}

	*status = True;
	return True;
*/
}


int Sctl_CancelScan() 
{
	int bRet=1;
	unsigned char data;

	bRet = CMDASIC_ReadRegister(0x000a, &data);  
	if(!bRet)	return False;

	if (data|0x01) {  //ADFSEL=1

		bRet=CMDASIC_WriteRegisterBit(0x0002,5,1,0);  //AGOHOME
		if (!bRet) return False;

		bRet=CtlImage_EnableScan(False); 
		if (!bRet) return False;

		bRet=CtlMotor_SetFeedSteps(0);
		if (!bRet) return False;

		CtlMotor_WaitMotorStop();

		bRet=CtlADF_SetADFSEL(0);
		if (!bRet) return False;

		bRet=CtlImage_ClrCounter();
		if (!bRet) return False;


	} else {   //ADFSEL=0

		//bRet=CMDASIC_WriteRegisterBit(0x0002,5,1,0);  //AGOHOME
		//if (!bRet) return False;

		bRet=CtlImage_EnableScan(False); 
		if (!bRet) return False;

		//bRet=CtlMotor_SetFeedSteps(0);
		//if (!bRet) return False;

		//CtlMotor_WaitMotorStop();

		//bRet=CtlADF_SetADFSEL(0);
		//if (!bRet) return False;

		//bRet=CtlImage_ClrCounter();
		//if (!bRet) return False;
	}

	return True;

}



int Sctl_BufferState(ScanParameter *pSPM, unsigned int *data)
{
	unsigned int valid_data;

	if ((pSPM->spJPEGENC&0x0f)!=0) {

		if((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1))
			CMDASIC_ReadFourRegister(0x09d4,&valid_data);  //jpg valid
		else
			CMDASIC_ReadFourRegister(0x03d4,&valid_data);  //jpg valid

	} else {

		if((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1))
			CMDASIC_ReadFourRegister(0x0a08,&valid_data);  //raw valid
		else
			CMDASIC_ReadFourRegister(0x0408,&valid_data);  //raw valid
		
	}
				
	(*data) = valid_data & 0x7fffffff;
	
	return TRUE;
	
}
