/***************************************************************************
* Name: if_usb_dev_pio.h                                                   *
* Description: iflow usb dev pio header                        	           *
*																		   *
*																		   *
* Author: John KE      				                                       *
* Date: 2013/10/25	                                                       *
****************************************************************************/
#ifndef _HEADER_IS_USB_DEV_PIO_
#define _HEADER_IS_USB_DEV_PIO_

#include "dtype.h"



#endif
