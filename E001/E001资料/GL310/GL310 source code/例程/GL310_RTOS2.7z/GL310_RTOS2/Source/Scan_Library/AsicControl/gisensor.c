////////////////////////////////////////////////////////////////
// File - gisensor.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"

unsigned short m_nDummyPixel; 
unsigned int CtlSensor_iOptRes;
unsigned char CtlSensor_nStepPerLine;
unsigned int CtlSensor_wTGPeriod;

extern int CCDLineDifference;
//extern unsigned short wLEDLAMPEXP[3];
//extern unsigned short wLEDLAMPEXP_B[3];

int CtlSensor_LperiodSet(ScanParameter *pSPM)
{
	int bRet=1;
	CtlSensor_wTGPeriod = (unsigned int)(1000.0f * pSPM->spExposureTime / CtlDevice_PixelTime);

	bRet=CMDASIC_WriteFourRegister(0x0200, (unsigned int)( 1000.0f * pSPM->spExposureTime / CtlDevice_PixelTime )); 
	if (!bRet) return False;
	bRet=CMDASIC_WriteFourRegister(0x0080, (unsigned int)( 1000.0f * pSPM->spShutterTime[0] / CtlDevice_PixelTime )); 
	if (!bRet) return False;
	bRet=CMDASIC_WriteFourRegister(0x0084, (unsigned int)( 1000.0f * pSPM->spShutterTime[1] / CtlDevice_PixelTime )); 
	if (!bRet) return False;
	bRet=CMDASIC_WriteFourRegister(0x0088, (unsigned int)( 1000.0f * pSPM->spShutterTime[2] / CtlDevice_PixelTime )); 
	if (!bRet) return False;

	if(pSPM->spDualscan) {
		bRet=CMDASIC_WriteFourRegister(0x0680, (unsigned int)( 1000.0f * pSPM->spShutterTime_B[0] / CtlDevice_PixelTime )); 
		if (!bRet) return False;
		bRet=CMDASIC_WriteFourRegister(0x0684, (unsigned int)( 1000.0f * pSPM->spShutterTime_B[1] / CtlDevice_PixelTime )); 
		if (!bRet) return False;
		bRet=CMDASIC_WriteFourRegister(0x0688, (unsigned int)( 1000.0f * pSPM->spShutterTime_B[2] / CtlDevice_PixelTime )); 
		if (!bRet) return False;
	}
	return True;
}


int CtlSensor_XResSet(ScanParameter *pSPM)
{
	int bRet; 
	unsigned int XRate, dtmp;
	unsigned int wLeft, wRight;

	////////////////////////////////////////////////////////////////////////////////////
	//DPIHW
	bRet=CtlSensor_SetDPIHW(CtlSensor_iOptRes);  
	if (!bRet) return False;
	
	//DPISET
	bRet=CMDASIC_WriteTwiRegister(0x0208, (unsigned short)(pSPM->spPixelResolution * pSPM->spTimingIdx)); 
	if (!bRet) return False;

	////////////////////////////////////////////////////////////////////////////////////
	//CIS sensor resolution select by different 1.GPIO switch or 2. MODPULSE/PULSELEN
	switch(pSPM->spTimingIdx){
		case 1: //2400dpi
			CMDASIC_WriteRegisterBit(0x0060,7,1,1); //GPO9_CMODE
			CMDASIC_WriteRegisterBit(0x0059,0,1,1); //GPEO9
			CMDASIC_WriteRegisterBit(0x0051,0,1,0);
			//CMDASIC_WriteTwiRegister(0x0094,0x000a); //MODSTR
			//CMDASIC_WriteRegister(0x0096,0x01); //MODPULSE
			//CMDASIC_WriteRegister(0x0097,0x04); //PULSELEN
			//CMDASIC_WriteRegisterBit(0x000a,7,1,0); //MOD_INV
			break;
		case 2: //1200dpi
			CMDASIC_WriteRegisterBit(0x0060,7,1,1); //GPO9_CMODE
			CMDASIC_WriteRegisterBit(0x0059,0,1,1); //GPEO9
			CMDASIC_WriteRegisterBit(0x0051,0,1,0);
			//CMDASIC_WriteTwiRegister(0x0094,0x000a); //MODSTR
			//CMDASIC_WriteRegister(0x0096,0x01); //MODPULSE
			//CMDASIC_WriteRegister(0x0097,0x04); //PULSELEN
			//CMDASIC_WriteRegisterBit(0x000a,7,1,0); //MOD_INV
			break;
		case 4: //600dpi
//			CMDASIC_WriteRegisterBit(0x0060,7,1,1); //GPO9_CMODE
//			CMDASIC_WriteRegisterBit(0x0059,0,1,1); //GPEO9
//			CMDASIC_WriteRegisterBit(0x0051,0,1,0);
			//CMDASIC_WriteTwiRegister(0x0094,0x000a); //MODSTR
			//CMDASIC_WriteRegister(0x0096,0x01); //MODPULSE
			//CMDASIC_WriteRegister(0x0097,0x04); //PULSELEN
			//CMDASIC_WriteRegisterBit(0x000a,7,1,0); //MOD_INV;
			break;
		case 8: //300dpi
//			CMDASIC_WriteRegisterBit(0x0060,7,1,0); //GPO9_CMODE
//			CMDASIC_WriteRegisterBit(0x0059,0,1,1); //GPEO9
//			CMDASIC_WriteRegisterBit(0x0051,0,1,1);
			//CMDASIC_WriteTwiRegister(0x0094,0x000a); //MODSTR
			//CMDASIC_WriteRegister(0x0096,0x01); //MODPULSE
			//CMDASIC_WriteRegister(0x0097,0x04); //PULSELEN
			//CMDASIC_WriteRegisterBit(0x000a,7,1,0); //MOD_INV
			break;
		default:
			break;
	}


	////////////////////////////////////////////////////////////////////////////////////

	XRate= CtlSensor_iOptRes / pSPM->spPixelResolution;
	wLeft= pSPM->spScanBeginPixel / pSPM->spTimingIdx;
	wRight= (pSPM->spScanLinePixels*XRate + pSPM->spScanBeginPixel) / pSPM->spTimingIdx;

	dtmp = wLeft + m_nDummyPixel;
	bRet=CMDASIC_WriteFourRegister(0x0214,dtmp);  //STRPIXEL
	if (!bRet) return False;
	dtmp += (wRight - wLeft);
	bRet=CMDASIC_WriteFourRegister(0x0218,dtmp);  //ENDPIXEL
	if (!bRet) return False;

	return True;
}


int CtlSensor_YResSet(ScanParameter *pSPM)
{
	//return CMDASIC_WriteFourRegister(0x0204,pSPM->spTotalScanLines*(pSPM->spCCDLMT+1));

	unsigned int data=0x00000000;
	unsigned char linediff;

	CCDLineDifference=12; //600dpi=12, 300dpi=6;

	//CCD HW packing
	if( (pSPM->spCCDPacking==1 ) && (pSPM->spImageType == IMAGE_COLOR) && (Sensor_type==2) ){
		linediff = CCDLineDifference * (pSPM->spMotorResolution/600.0f);
		data=0x00000000 | ((unsigned int)linediff<<16);
	} else {
		data=0x00000000;
	}
	CMDASIC_WriteFourRegister(0x020c,data);

	//LINCNT
	//return CMDASIC_WriteFourRegister(0x0204,pSPM->spTotalScanLines*(pSPM->spCCDLMT+1));
	if( (pSPM->spCCDPacking==1 ) && (pSPM->spImageType == IMAGE_COLOR) && (Sensor_type==2) ){
		return CMDASIC_WriteFourRegister(0x0204,(pSPM->spTotalScanLines+2*linediff)*(pSPM->spCCDLMT+1));
	} else {
		return CMDASIC_WriteFourRegister(0x0204,pSPM->spTotalScanLines*(pSPM->spCCDLMT+1));
	}

}

int CtlSensor_SetDPIHW(unsigned int Res)
{
	unsigned char nVal;
	switch(Res){
		case 4800:   
			nVal=3;
			break;
		case 2400:   
			nVal=2;
			break;
		case 1200:   
			nVal=1;
			break;
		case 600:   
			nVal=0;
			break;
	}
	return CMDASIC_WriteRegisterBit(0x0003,1,2,nVal);
}




int CtlSensor_SetDummyPixel(void)
{
	//m_nDummyPixel = TGSHLD*2 + TGW 
	m_nDummyPixel = 
		( ((unsigned short)CMDASIC_RegTable[0x0107].nValue << 8) | (unsigned short)CMDASIC_RegTable[0x0106].nValue ) * 2 + 
		( ((unsigned short)CMDASIC_RegTable[0x0105].nValue << 8) | (unsigned short)CMDASIC_RegTable[0x0104].nValue );
	//m_nDummyPixel=68;
	return CMDASIC_WriteTwiRegister(0x0210,m_nDummyPixel);
}



int CtlSensor_SetDummyLine(unsigned char n)
{
   CtlSensor_nStepPerLine = n + 1;
   return CMDASIC_WriteRegisterBit(0x0213,0,5,n); 
}


