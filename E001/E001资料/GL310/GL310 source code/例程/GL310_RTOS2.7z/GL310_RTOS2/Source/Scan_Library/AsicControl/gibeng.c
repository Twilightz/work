////////////////////////////////////////////////////////////////
// File - gisensor.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"
#include "cmd.h"

extern float Sensor_gap;

#define wRegIdxLen MAX_SCAN_REGISTERS/4  // 0x287 = MAX_SCAN_REGISTERS/4 = 0xA1C/4 = 0x287
unsigned char wRegIdxTbl[wRegIdxLen];  //index table for write master and b_eng register as the same value

//make index table for b_eng(DualScan) register, 
//if index=1 write master and b_eng register as the same value.
//exa: WriteFourRegister 0x0200 & 0x0800, if the wRegIdxTbl[0x0800/4]=1.
int BENG_Init_WriteDirect(void)
{
	int i, Num;
	unsigned short data[] = {
	0x0600, 0x0604, 0x0608, 0x0614, 0x0618, 0x061c, 
	0x0680, 0x0684, 0x0688, 0x068c, 0x0690, 0x0694, 
	0x06a0, 0x06ac, 0x06b0, 0x06b4, 0x06b8, 0x06bc, 
	0x06c0, 0x06c4, 0x06c8, 0x06cc, 0x06d0,
	0x0700, 0x0704, 0x0708, 0x070c, 0x0710, 0x0714, 0x0718, 0x071c, 
	0x0720, 0x0724, 0x0728, 0x072c, 0x0730, 0x0734, 0x0738, 0x073c, 
	0x0740, 0x0744, 0x0748, 0x074c,
	0x0800, 0x0808, 0x080c, 0x0810, 0x0814, 0x0818, 0x0820, 0x0824, 0x0828, 0x0830,
	0x08a0, 0x08a4, 0x08a8, 0x08ac, 0x08b0, 0x08b4, 0x08b8, 0x08bc, 
	0x08c0, 0x08c4, 0x08c8, 0x08cc, 0x08d0, 0x08d4, 0x08d8, 0x08dc, 
	0x08e0, 0x08e4, 0x08e8, 0x08ec, 0x08f0, 0x08f4, 0x08f8, 0x08fc,
	0x0900, 0x0904, 0x0908, 0x090c, 0x0910, 0x0914, 0x0918, 0x091c, 
	0x0920, 0x0924, 0x0928, 0x092c, 0x0930, 0x0934, 0x0938, 0x093c, 
	0x0940, 0x0944, 0x0948, 0x094c, 0x09a0, 
	
	//spSimplexSide
	0x09a4, 0x09a8, 0x09ac, 0x09b0, 0x09b4, 0x09b8, 0x09bc,	0x09c0, 0x09c4,

	0x09b4, 0x09b8, 0x09e8
	};

	memset(wRegIdxTbl,0,wRegIdxLen);  //clear table = 0
	Num=sizeof(data)/sizeof(unsigned short);
	for (i=0; i<Num; i++) {
		wRegIdxTbl[ (data[i]-0x0600)/4 ]=1;
	}

	return True;
}


int BENG_setting(ScanParameter *pSPM)
{
	unsigned short i;
	unsigned data;

	if(pSPM->spDualscan==2) {  //2=scan in same time CCDLMT=2, set B_eng shd 0,1,2
		for (i=0x02ac; i<=0x2b4; i=i+4) {  //shading 
			CMDASIC_ReadFourRegister(i, &data);
			CMDASIC_WriteFourRegister((unsigned short)(i+0x0600), data+DualOffset);
		}
	}
 
	if(pSPM->spDualscan==1) {  //1=switch separate CCDLMT=5, set B_eng shd 3,4,5
		for (i=0x02ac; i<=0x2b4; i=i+4) {  //shading 
			CMDASIC_ReadFourRegister((unsigned short)i, &data);
			CMDASIC_WriteFourRegister((unsigned short)(i+0x000c), data+DualOffset);
		}
	}

	for (i=0x02cc; i<=0x2f8; i=i+4) {  //image bank 
		CMDASIC_ReadFourRegister(i, &data);
		CMDASIC_WriteFourRegister((unsigned short)(i+0x0600), data+DualOffset);
	}

	for (i=0x03a4; i<=0x3b0; i=i+4) {  //jpg & thumb str/end 
		CMDASIC_ReadFourRegister(i, &data);
		CMDASIC_WriteFourRegister((unsigned short)(i+0x0600), data+DualOffset);
	}

	for (i=0x03bc; i<=0x3c4; i=i+4) {  //thumb y cb cr 
		CMDASIC_ReadFourRegister(i, &data);
		CMDASIC_WriteFourRegister((unsigned short)(i+0x0600), data+DualOffset);
	}

	CMDASIC_WriteFourRegister(0x03b4+0x0600, Jpeg_thumb_scale_xy);
	CMDASIC_WriteFourRegister(0x03b8+0x0600, Jpeg_thumb_ymax);

	CMDASIC_WriteJPGBus_B(0x0084,Jpeg_thumb_ystr+DualOffset);
	CMDASIC_WriteJPGBus_B(0x0088,Jpeg_thumb_cbstr+DualOffset);
	CMDASIC_WriteJPGBus_B(0x008c,Jpeg_thumb_crstr+DualOffset);

	{
		unsigned char b_afe_sel=1;
		unsigned char DualSWEn=0;
		//unsigned char b_mem_enb=0;
		unsigned char b_engine=1;
		unsigned char b_img_only=0;

		DualSWEn = (pSPM->spDualscan==1) ? 1 : 0 ;
		CMDASIC_WriteRegisterBit(0x0630,0,5, (unsigned char)((b_img_only<<4)|(b_engine<<3)|(DualSWEn<<1)|b_afe_sel));
		//CMDASIC_WriteRegisterBit(0x001c,3,1,0); //TwoAFE8B;
	}
	
	if(Sensor_type!=2)
		CMDASIC_WriteRegisterBit(0x006b,0,3,5);   //b_CIS_LED=1, b_SSLEDEN=1

	CMDASIC_WriteTwiRegister(0x021c,(Sensor_gap*pSPM->spMotorResolution));  //IMGGAP , color line


	return True;
}

////////////////////////////////////////////////////////
//Set GPIO78 - SYS_POWER_ON into HI
//Set GPIO79 - MOTOR_POWER_ON into HI
//Set GPIO80 - A3.3V_POWER_ON into HI
//Run Scan Process
////////////////////////////////////////////////////////
int PWR_OperationMode(ScanParameter *pSPM)
{
//HL modify
#if 0
	int bRet = 1;
	unsigned int nVal, nVal_SYS, nVal_MT, nVal_A3V3;
	unsigned int nDirSYS, nDirMT, nDirA3V3;
#ifdef CANOPUS_COM2
	CMDASIC_ReadBus(0xa0000068, &nVal);
	CMDASIC_WriteBus(0xa0000068, (nVal & 0xffffffffe)); //LCM_SEL=0

	//System Power ON/Off
	CMDASIC_ReadBus(0xa0000058, &nVal_SYS);
	CMDASIC_ReadBus(0xa000005c, &nDirSYS);

	CMDASIC_WriteBus(0xa0000058, (nVal_SYS | 0x00000080)); //Set GPIO78 =1 
	CMDASIC_WriteBus(0xa000005c, (nDirSYS | 0x00000080)); //Set GPIOE78 = output
#else
	CMDASIC_ReadBus(0xa0000068, &nVal);
	CMDASIC_WriteBus(0xa0000068, (nVal & 0xffffffffe)); //LCM_SEL=0

	//System Power ON/Off
	CMDASIC_ReadBus(0xa0000058, &nVal_SYS);
	CMDASIC_ReadBus(0xa000005c, &nDirSYS);

	CMDASIC_WriteBus(0xa0000058, (nVal_SYS | 0x00000080)); //Set GPIO78 =1 
	CMDASIC_WriteBus(0xa000005c, (nDirSYS | 0x00000080)); //Set GPIOE78 = output
#endif
	//Motor Power ON/Off
	CMDASIC_ReadBus(0xa0000059, &nVal_MT);
	CMDASIC_ReadBus(0xa000005d, &nDirMT);

	CMDASIC_WriteBus(0xa0000059, (nVal_MT | 0x00000001)); //Set GPIO79 =1 
	CMDASIC_WriteBus(0xa000005d, (nDirMT | 0x00000001)); //Set GPIOE79 = output

	//A3.3V Power ON/Off
	CMDASIC_ReadBus(0xa0000059, &nVal_A3V3);
	CMDASIC_ReadBus(0xa000005d, &nDirA3V3);

	CMDASIC_WriteBus(0xa0000059, (nVal_A3V3 | 0x00000001)); //Set GPIO80 =1 
	CMDASIC_WriteBus(0xa000005d, (nDirA3V3 | 0x00000001)); //Set GPIOE80 = output

	bRet = CtlADF_LEDPWR(1); //Turn-on Lamp
	if (!bRet) return False;
#endif
	return True;
}

////////////////////////////////////////////////////////////////////////////
//(1) Set GPIO79 - MOTOR_POWER_ON into LO
//(2) Set GPIO35 - MOTOR_nSLEEP into LO
//(3) Set GPIO80, GPIO81, GPIO82 into LO
//(4) Disable GL310 - CIS_CLK(CCD_CK1X) , Dual AFE_MCLK/
//     AFE_VSMP and CIS_LEDR,CIS_LEDG,CIS_LEDB
//(5) GL310 let LPDDR enter self-refresh mode
//(6) Set GPIO71(POWER LED) into pulsing
//(7) Set GL310 into sleep mode
////////////////////////////////////////////////////////////////////////////

int PWR_IdleMode(ScanParameter *pSPM)
{
//HL modify
#if 0
	int bRet=1;
	unsigned int nVal, nVal_SYS, nVal_MT, nVal_A3V3;
	unsigned int nDirSYS, nDirMT, nDirA3V3;

	CMDASIC_ReadBus(0xa0000068, &nVal);
	CMDASIC_WriteBus(0xa0000068, (nVal & 0xffffffffe)); //LCM_SEL=0

	//System Power ON/Off
	//CMDASIC_ReadBus(0xa0000058, &nVal_SYS);
	//CMDASIC_ReadBus(0xa000005c, &nDirSYS);

	//CMDASIC_WriteBus(0xa0000058, (nVal_SYS | 0x00000080)); //Set GPIO78 =1 
	//CMDASIC_WriteBus(0xa000005c, (nDirSYS | 0x00000080)); //Set GPIOE78 = output

	//Motor Power ON/Off
	CMDASIC_ReadBus(0xa0000059, &nVal_MT);
	CMDASIC_ReadBus(0xa000005d, &nDirMT);

	CMDASIC_WriteBus(0xa0000059, (nVal_MT & 0xfffffffe)); //Set GPIO79 =0 
	CMDASIC_WriteBus(0xa000005d, (nDirMT | 0x00000001)); //Set GPIOE79 = output

	//MOTOR_nSLEEP into LO
	CMDASIC_WriteRegisterBit(0x0064, 6, 2, 0x00); //Select GPIO35 function
	CMDASIC_WriteRegisterBit(0x0054, 2, 1, 0x00); //Set GPIO35 =0
	CMDASIC_WriteRegisterBit(0x005c, 2, 1, 0x01); //Set GPIOE35 =1 output

	//A3.3V Power ON/Off
	CMDASIC_ReadBus(0xa0000059, &nVal_A3V3);
	CMDASIC_ReadBus(0xa000005d, &nDirA3V3);

	CMDASIC_WriteBus(0xa0000059, (nVal_A3V3 | 0x00000001)); //Set GPIO80 =1 
	CMDASIC_WriteBus(0xa000005d, (nDirA3V3 | 0x00000001)); //Set GPIOE80 = output

	bRet = CtlADF_LEDPWR(0); //Turn-off Lamp
	if (!bRet) return False;

	bRet = CtlSensor_LperiodSet(pSPM);
	if (!bRet) return False;
#endif
	return True;
}




