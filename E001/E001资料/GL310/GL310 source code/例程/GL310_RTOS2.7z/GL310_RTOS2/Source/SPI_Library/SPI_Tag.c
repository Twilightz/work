#include "def.h"
//#include "tx_api.h"
#include "spi_tag.h"
#include "clibutil.h"


#ifdef _SPI_TX
#include "os_user_spi.h"
#endif


#define USBDEVICE_STRING_DESCRIPTOR_STR     0x3


BOOL tag_SPI_TagIDGet(UINT8 *TagID, UINT16 BlockNum, INT8 *IDStr)
{


	UINT16 StartBlock;
	UINT16 TagIDIndex;
	
		
	MemID_Tag *TagPtr = (MemID_Tag *)(UINT32)TagIDBaseBuf;
	
	
	
	for(TagIDIndex = 0; TagIDIndex < TagNum; TagIDIndex++ ){
		
		if( stricmp(IDStr, TagPtr->IDString) == 0)			// It's means Tag ID string had been to use in other tags		
			return false;
		
		
		
		if( !(TagPtr->ID &	0x80000000) ){					// MSB bit high, the tag space is used
		
			// fill empty block area 		
			if( !hw_FreeBlockGet(hwBlockIndexBufBase, &StartBlock, BlockNum) )	
				return false;	
			
			if( !hw_BlockIndexFill(hwBlockIndexBufBase, StartBlock, BlockNum, 1)	)
				return false;
			
		 
			TagPtr->ID |= TagIDIndex;
			TagPtr->ID |= 0x80000000;
			
			TagPtr->StartBlock = StartBlock;
			TagPtr->BlockNum   = BlockNum;			
			TagPtr->StartOff   = StartBlock * SpiParam->flash_i.BlkSize;
			TagPtr->Len 	   = BlockNum * SpiParam->flash_i.BlkSize; 
			strcpy( (INT8 *)&TagPtr->IDString[0], IDStr);
			
		 
			tag_SPI_Protect(0);
			SPI_BE(0x0, spi_intf_A);		
			SPI_WR(0x0, (UINT32)SPIParamTblBaseBuf, 0x1000, spi_intf_A);
			tag_SPI_Protect(1);
		 
			
			*TagID = TagIDIndex;
			return true;
				
		}
		
		TagPtr++;
	}
	
	return false;
}



BOOL tag_SPI_TagIDRelease(UINT8 TagID)
{

	
	MemID_Tag *TagIDIndex = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);
	
	if( (TagID == 0) || (TagID > TagNum)  || ( !(TagIDIndex->ID & 0x80000000) ) )
		return false;	
	
	
	
	if( !hw_BlockIndexFill(hwBlockIndexBufBase, TagIDIndex->StartBlock, TagIDIndex->BlockNum, 0)	)
		return false;
			
			
	memset(TagIDIndex, 0, TagIDSize);
	
	 
	tag_SPI_Protect(0);
	SPI_BE(0x0, spi_intf_A);
	SPI_WR(0x0, (UINT32)SPIParamTblBaseBuf, 0x1000, spi_intf_A);
	tag_SPI_Protect(1);
	 
	
		
	return true;
}


BOOL tag_SPI_TagEraseIndex(UINT16 TagID, UINT16 Index)
{

	MemID_Tag *TagIDIndex = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);
	
	
	
	if( (TagID == 0) || (TagID > TagNum)  || ( !(TagIDIndex->ID &	0x80000000) ) || (Index >= TagIDIndex->BlockNum) )
		return false;		
	
	tag_SPI_Protect(0);
	SPI_BE(( TagIDIndex->StartBlock + Index) * SpiParam->flash_i.BlkSize, spi_intf_A);
	tag_SPI_Protect(1);	
		
	return true;
}



BOOL tag_SPI_TagEraseAll(UINT16 TagID)
{
	
	UINT16 BlockIndex;
	
 

	MemID_Tag *TagIDIndex = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);
	
	
	if( (TagID == 0) || (TagID > TagNum)  || ( !(TagIDIndex->ID &	0x80000000) ) )
		return false;	
	
	tag_SPI_Protect(0);
	for(BlockIndex = TagIDIndex->StartBlock; BlockIndex < (TagIDIndex->StartBlock + TagIDIndex->BlockNum); BlockIndex++){		
		
		SPI_BE(BlockIndex * SpiParam->flash_i.BlkSize, spi_intf_A); 					
	}
	tag_SPI_Protect(1);
	
	return true;
}





BOOL tag_SPI_TagDataWrite(UINT16 TagID, UINT16 BlockIndex, UINT8 *WrBuf, UINT32 *checksum)
{
		
	MemID_Tag *TagIDIndex = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);
	
	
	if( (TagID == 0) || (TagID > TagNum)  || ( !(TagIDIndex->ID &	0x80000000) ) || (BlockIndex >= TagIDIndex->BlockNum) ){
		return false;	
	}
		
	
	tag_SPI_Protect(0);
	SPI_BE( (TagIDIndex->StartBlock + BlockIndex) * SpiParam->flash_i.BlkSize, spi_intf_A);
	
	*checksum = SPI_WR( (TagIDIndex->StartBlock + BlockIndex) * SpiParam->flash_i.BlkSize,  WrBuf, SpiParam->flash_i.BlkSize, spi_intf_A);
	tag_SPI_Protect(1);
			
	return true;
}



BOOL tag_SPI_TagDataRead(UINT16 TagID, UINT16 BlockIndex, UINT8 *RdBuf, UINT32 *checksum)
{

	MemID_Tag *TagIDIndex = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);
	
	
	if( (TagID > TagNum)  || ( !(TagIDIndex->ID &	0x80000000) ) || (BlockIndex >= TagIDIndex->BlockNum) )
		return false;	
	
	
	*checksum = SPI_RD( (TagIDIndex->StartBlock + BlockIndex) * SpiParam->flash_i.BlkSize,  RdBuf, SpiParam->flash_i.BlkSize, spi_intf_A);	
		
	return true;
}

BOOL tag_SPI_TagInfoRead(UINT16 TagID, MemID_Tag **TagID_Info)
{

	*TagID_Info = (MemID_Tag *)((UINT32)TagIDBaseBuf + TagID * TagIDSize);

	return true;	
}

BOOL tag_SPI_TagStringInquiry(UINT8 *TagID, INT8 *IDStr)
{

	MemID_Tag *TagID_Info;
	UINT8 TagIDIndex;
	
	if( ( strlen(IDStr) > 12 ) || ( strlen(IDStr) == 0 ))
		return false;
	
	for(TagIDIndex = 1; TagIDIndex < TagNum; TagIDIndex++ ){
	
	    tag_SPI_TagInfoRead(TagIDIndex, &TagID_Info);
		
		if( (strlen(TagID_Info->IDString)== 0) || (strlen(TagID_Info->IDString) > 12) )
			continue;
		
		if( stricmp(IDStr, TagID_Info->IDString) == 0){
		
			*TagID = TagIDIndex;
			return true;
		}
	
	}		

	return false;
}




 
BOOL tag_SPI_ImageUpdateInitial()
{
 
 
	MemID_Tag *Boot_Tag    = (MemID_Tag *)TagIDBaseBuf;
	MemID_Tag *Recover_Tag = (MemID_Tag *)(TagIDBaseBuf + (RecoverTagID * sizeof(MemID_Tag)));
 
 	if( (Recover_Tag->ID & 0x1) != BootTagID)
 		return true;									// recover tag not real recover tag
 		
 	memcpy(Boot_Tag, Recover_Tag,   sizeof(MemID_Tag));	// backup the original api image
 	
 	tag_SPI_Protect(0); 
	SPI_BE(0x0, spi_intf_A);						    // update new one	
	SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	 	 
	tag_SPI_Protect(1);

	return true;
}


BOOL tag_SPI_SetBootImageTag(UINT8 ImageTagID)
{


	MemID_Tag *Boot_Tag    = (MemID_Tag *)TagIDBaseBuf;
	MemID_Tag *Img_Tag     = (MemID_Tag *)(TagIDBaseBuf + (ImageTagID * sizeof(MemID_Tag)));	
 
 
	memcpy(Boot_Tag,    Img_Tag,   sizeof(MemID_Tag)); 	
	Boot_Tag->ID = BootTagID | 0x80000000; 
	 
	tag_SPI_Protect(0); 
	SPI_BE(0x0, spi_intf_A);												 
	SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	 	 
	tag_SPI_Protect(1);
	
	return true;
	
}


BOOL tag_SPI_FetchBootTagID(UINT8 *TagID)
{

	MemID_Tag *Boot_Tag = (MemID_Tag *)TagIDBaseBuf;
	
	*TagID = Boot_Tag->ID & 0xff;
	
	return true;
	
}

BOOL tag_SPI_BackupBootTag(UINT8 TagID)
{

	MemID_Tag *Boot_Tag = (MemID_Tag *)TagIDBaseBuf;
	MemID_Tag *Recover_Tag = (MemID_Tag *)(TagIDBaseBuf + (RecoverTagID * sizeof(MemID_Tag)));
	
	memcpy(Recover_Tag, Boot_Tag,  sizeof(MemID_Tag)); 	
	Recover_Tag->ID = RecoverTagID | 0x80000000; 
	
	tag_SPI_Protect(0);	 
	SPI_BE(0x0, spi_intf_A);												 
	SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	 
	tag_SPI_Protect(1);
	
	return true;
	
}



/******************************************************************************
*  BOOL tag_SPI_chg_venderstr(INT8 *vdrstr)
******************************************************************************/
BOOL tag_SPI_chg_venderstr(INT8 *vdrstr)
{
    INT8 *vender_str =  "vender_str";
    UINT8 strLen = vdrstr[0];
    UINT8 strsignature = vdrstr[1];  
    
    
    BOOL bRet = FALSE;
    UINT8 i;         
    UINT8 StrID;   
    MemID_Tag *StrIDTag;   
    
    
    if( (strsignature != USBDEVICE_STRING_DESCRIPTOR_STR) || (strLen > 0xFE) )
        return bRet;
    
    if(tag_SPI_TagStringInquiry(&StrID, vender_str)){
    
        if(tag_SPI_TagInfoRead(StrID, &StrIDTag) ){
        
            for(i=0; i<strLen; i++)        
                *((UINT8 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + i)) = vdrstr[i];   
            
            tag_SPI_Protect(0);
            SPI_BE(0x0, spi_intf_A);												 
    	    SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	    
    	    tag_SPI_Protect(1);
    	             
            bRet = TRUE;                       
        }            
    }
    
    return bRet;
    
}

/******************************************************************************
*  BOOL tag_SPI_chg_productstr(INT8 *prodstr)
******************************************************************************/
BOOL tag_SPI_chg_productstr(INT8 *prodstr)
{
    
    INT8 *product_str = "product_str";
    UINT8 strLen = prodstr[0];
    UINT8 strsignature = prodstr[1];
    
    
    BOOL bRet = FALSE;
    UINT8 i;         
    UINT8 StrID;   
    MemID_Tag *StrIDTag;   
    
    
    if( (strsignature != USBDEVICE_STRING_DESCRIPTOR_STR) || (strLen > 0xFE) )
        return bRet;
    
    if(tag_SPI_TagStringInquiry(&StrID, product_str)){
    
        if(tag_SPI_TagInfoRead(StrID, &StrIDTag) ){
        
            for(i=0; i<strLen; i++)        
                *((UINT8 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + i)) = prodstr[i];   
            
            tag_SPI_Protect(0);
            SPI_BE(0x0, spi_intf_A);												 
    	    SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	    
    	    tag_SPI_Protect(1);
               
            bRet = TRUE;                       
        }            
    }
    
    return bRet;
    
}


/******************************************************************************
*  BOOL tag_SPI_chg_serialstr(INT8 *serilstr)
******************************************************************************/
BOOL tag_SPI_chg_serialstr(INT8 *serilstr)
{
    
    INT8 *serial_str  = "serial_str";
    UINT8 strLen = serilstr[0];
    UINT8 strsignature = serilstr[1];
    
    
    BOOL bRet = FALSE;
    UINT8 i;         
    UINT8 StrID;   
    MemID_Tag *StrIDTag;   
    
    
    if( (strsignature != USBDEVICE_STRING_DESCRIPTOR_STR) || (strLen > 0xFE) )
        return bRet;
    
    if(tag_SPI_TagStringInquiry(&StrID, serial_str)){
    
        if(tag_SPI_TagInfoRead(StrID, &StrIDTag) ){
        
            for(i=0; i<strLen; i++)        
                *((UINT8 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + i)) = serilstr[i];   
            
            tag_SPI_Protect(0);
            SPI_BE(0x0, spi_intf_A);												 
    	    SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	    
    	    tag_SPI_Protect(1);
             
            bRet = TRUE;                       
        }            
    }
    
    return bRet;
    
}


/******************************************************************************
*  BOOL tag_SPI_chg_VPID(VPID_FORM *VPIDstr)
******************************************************************************/
BOOL tag_SPI_chg_VPID(VPID_FORM *VPIDstr)
{
    
    
    INT8 *VPID_str  = "VPID_str";
    UINT8 strLen = VPIDstr->Len;
    UINT8 strsignature = VPIDstr->Signature;
    
    
    BOOL bRet = FALSE; 
    UINT8 StrID;   
    MemID_Tag *StrIDTag;   
    
    
    if( (strsignature != 0x1) || (strLen > 0xFE) )
        return bRet;
    
    if(tag_SPI_TagStringInquiry(&StrID, VPID_str)){
    
        if(tag_SPI_TagInfoRead(StrID, &StrIDTag) ){
        
            *((UINT8 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + 0)) = VPIDstr->Len;
            *((UINT8 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + 1)) = VPIDstr->Signature;
            
            *((UINT16 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + 2)) = VPIDstr->VID;
            *((UINT16 *) (SPIParamTblBaseBuf + StrIDTag->StartOff + 4)) = VPIDstr->PID;
            
            tag_SPI_Protect(0);
            SPI_BE(0x0, spi_intf_A);												 
    	    SPI_WR(0x0, (UINT8 *)SPIParamTblBaseBuf, 0x1000, spi_intf_A);	    
    	    tag_SPI_Protect(1);
             
            bRet = TRUE;                       
        }            
    }
     
    return bRet;
    
}

/******************************************************************************
 *  BOOL tag_SPI_hw_Write_Protect(UINT8 Enable)
 ******************************************************************************/
BOOL tag_SPI_hw_Write_Protect(UINT8 Enable)
{
    
    SPI_hw_Proctect(Enable, spi_intf_A);;    
	
	return true;
}



/******************************************************************************
 *  BOOL tag_SPI_Protect(UINT8 bEnable)
 ******************************************************************************/
BOOL tag_SPI_Protect(UINT8 bEnable)
{
    
    SPI_BlockProctect(bEnable, spi_intf_A);    
	
	return true;
}


/******************************************************************************
 *  BOOL tag_SPI_GetFreeBlockNum(UINT32 *freeBlkNum)
 ******************************************************************************/
BOOL tag_SPI_GetFreeBlockNum(UINT32 *freeBlkNum)
{

    *freeBlkNum = hwfreeBlockNum;
    return true;    
}

/******************************************************************************
 *  BOOL tag_SPI_RDID(UINT8 *VID, UINT8 *PID)
 ******************************************************************************/
BOOL tag_SPI_RDID(UINT8 *VID, UINT8 *PID)
{

    SPI_RDID(VID, PID, spi_intf_A);
    return true;    
}





#ifdef _SPI_TX
//=====================================================================================
//  Mutex Lock
//=====================================================================================





extern OS_Mutex mutex_SPI;

BOOL MT_SPI_TagIDGet(UINT8 *TagID, UINT16 BlockNum, INT8 *IDStr)
{

	BOOL bRet;
	UINT32 status;
	
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return FALSE;
	
	bRet = tag_SPI_TagIDGet(TagID, BlockNum, IDStr);
	
	mutexPut(mutex_SPI);
	
	return bRet;
}


BOOL MT_SPI_TagIDRelease(UINT8 TagID)
{
	
	BOOL bRet;
	UINT32 status;
	
		
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_TagIDRelease(TagID);
	
	mutexPut(mutex_SPI);
	
	return bRet;
}


BOOL MT_SPI_TagEraseIndex(UINT16 TagID, UINT16 Index)
{

	BOOL bRet;
	UINT32 status;
	
	
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	
	
	bRet = tag_SPI_TagEraseIndex(TagID, Index);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
}

BOOL MT_SPI_TagEraseAll(UINT16 TagID)
{
	
	BOOL bRet;
	UINT32 status;
	
	
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	
	
	bRet = tag_SPI_TagEraseAll(TagID);
	
	mutexPut(mutex_SPI);
	
	return bRet;
}

BOOL MT_SPI_TagDataWrite(UINT16 TagID, UINT16 BlockIndex, UINT8 *WrBuf, UINT32 *checksum)
{
	BOOL bRet;
	UINT32 status;
	
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	
				
	bRet = tag_SPI_TagDataWrite(TagID, BlockIndex, WrBuf, checksum);
	
	mutexPut(mutex_SPI);
	
	return bRet;
}



BOOL MT_SPI_TagDataRead(UINT16 TagID, UINT16 BlockIndex, UINT8 *RdBuf, UINT32 *checksum)
{
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_TagDataRead(TagID, BlockIndex, RdBuf, checksum);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
	
}

BOOL MT_SPI_TagInfoRead(UINT16 TagID, MemID_Tag **TagID_Info)
{
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_TagInfoRead(TagID, TagID_Info);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
	
}


BOOL MT_SPI_TagStringInquiry(UINT8 *TagID, INT8 *IDStr)
{
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_TagStringInquiry(TagID, IDStr);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
	
}


BOOL MT_SPI_ImageUpdateInitial()
{
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_ImageUpdateInitial();
	
	mutexPut(mutex_SPI);
	
	return bRet;	
	
}


BOOL MT_SPI_SetBootImageTag(UINT8 ImageTagID)
{
	
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_SetBootImageTag(ImageTagID);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
}



BOOL MT_SPI_FetchBootTagID(UINT8 *TagID)
{
	
	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_FetchBootTagID(TagID);
	
	mutexPut(mutex_SPI);
	
	return bRet;	
}

BOOL MT_SPI_BackupBootTag(UINT8 TagID)
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_BackupBootTag(TagID);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
}


BOOL MT_SPI_chg_venderstr(INT8 *vdrstr)
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_chg_venderstr(vdrstr);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
}

BOOL MT_SPI_chg_productstr(INT8 *prodstr)
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_chg_productstr(prodstr);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
}

BOOL MT_SPI_chg_serialstr(INT8 *serilstr) 
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_chg_serialstr(serilstr);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
}

BOOL MT_SPI_chg_VPID(VPID_FORM *VPIDstr) 
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_chg_VPID(VPIDstr);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
}

BOOL MT_SPI_Protect(UINT8 bEnable) 
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_Protect(bEnable);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
} 

BOOL MT_SPI_GetFreeBlockNum(UINT32 *freeBlkNum) 
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_GetFreeBlockNum(freeBlkNum);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
} 

BOOL MT_SPI_hw_Write_Protect(UINT8 Enable)
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_hw_Write_Protect(Enable);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
} 


BOOL MT_SPI_RDID(UINT8 *VID, UINT8 *PID)
{

	BOOL bRet;
	UINT32 status;
	
	status = mutexGet(mutex_SPI, OS_WAIT_FOREVER);	
		
	if(status != OS_SUCCESS)
		return false;
	

	bRet = tag_SPI_RDID(VID, PID);
	
	mutexPut(mutex_SPI);
	
	return bRet;		
} 

 
#endif
