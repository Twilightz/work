////////////////////////////////////////////////////////////////
// File - gimtmotor.h
// Copyright (c) 2013 - Genesys Logic, INC.
//
////////////////////////////////////////////////////////////////
#ifndef _gimtmotor_h
#define _gimtmotor_h

///////////////////////////////////////////////////////

typedef struct {

	unsigned char MskSnr0: 1;
	unsigned char PrSnr0: 1;
	unsigned char MskSnr1: 1;
	unsigned char PrSnr1: 1;
	unsigned char MskSnr2: 1;
	unsigned char PrSnr2: 1;
	unsigned char MskSnr3: 1;
	unsigned char PrSnr3: 1;

	unsigned char MskSnr4: 1;
	unsigned char PrSnr4: 1;
	unsigned char MskSTout0: 1;
	unsigned char PrSTout0: 1;
	unsigned char MskSTout1: 1;
	unsigned char PrSTout1: 1;
	unsigned char MskSTout2: 1;
	unsigned char PrSTout2: 1;

	unsigned char MskSTout3: 1;
	unsigned char PrSTout3: 1;
	unsigned char MskM0Tout0: 1;
	unsigned char PrM0Tout0: 1;
	unsigned char MskM0Tout1: 1;
	unsigned char PrM0Tout1: 1;
	unsigned char MskM0Tout2: 1;
	unsigned char PrM0Tout2: 1;

	unsigned char MskM0Tout3: 1;
	unsigned char PrM0Tout3: 1;
	unsigned char MskM1Tout0: 1;
	unsigned char PrM1Tout0: 1;
	unsigned char MskM1Tout1: 1;
	unsigned char PrM1Tout1: 1;
	unsigned char Msk0M1Tout2: 1;
	unsigned char Pr0M1Tout2: 1;

	unsigned char MskM1Tout3: 1;
	unsigned char PrM1Tout3: 1;
	unsigned char MskM2Tout0: 1;
	unsigned char PrM2Tout0: 1;
	unsigned char MskM2Tout1: 1;
	unsigned char PrM2Tout1: 1;
	unsigned char MskM2Tout2: 1;
	unsigned char PrM2Tout2: 1;

	unsigned char MskM2Tout3: 1;
	unsigned char PrM2Tout3: 1;
	unsigned char MskStatus0: 1;
	unsigned char PrStatus0: 1;
	unsigned char MskStatus1: 1;
	unsigned char PrStatus1: 1;
	unsigned char MskStatus2: 1;
	unsigned char PrStatus2: 1;

	unsigned char MskStatus3: 1;
	unsigned char PrStatus3: 1;
	unsigned char MskStatus4: 1;
	unsigned char PrStatus4: 1;
	unsigned char MskTask0: 1;
	unsigned char PrTask0: 1;
	unsigned char MskTask1: 1;
	unsigned char PrTask1: 1;

	unsigned char MskTask2: 1;
	unsigned char PrTask2: 1;
	unsigned char MskTask3: 1;
	unsigned char PrTask3: 1;
	unsigned char TinLoopCtl: 1;
	unsigned char PrLoopCtl: 1;
	unsigned char : 2;

	unsigned char OASnr: 1;
	unsigned char OATout: 1;
	unsigned char OASt: 1;
	unsigned char : 1;
	unsigned char OAGrp: 4;

	unsigned char AccelTb: 3;
	unsigned char : 1;
	unsigned char TBTime: 3;
	unsigned char : 1;

	unsigned short AccelNo;
	unsigned int FedStep;
	unsigned short DlySet;
	unsigned short StopSet;
	unsigned short LoopLmt;

} Str_MxTin0Ci;



/////////////////////
/////////////////////

typedef struct { 

	unsigned char MskSnr0: 1;
	unsigned char PrSnr0: 1;
	unsigned char MskSnr1: 1;
	unsigned char PrSnr1: 1;
	unsigned char MskSnr2: 1;
	unsigned char PrSnr2: 1;
	unsigned char MskSnr3: 1;
	unsigned char PrSnr3: 1;

	unsigned char MskSnr4: 1;
	unsigned char PrSnr4: 1;
	unsigned char MskSTout0: 1;
	unsigned char PrSTout0: 1;
	unsigned char MskSTout1: 1;
	unsigned char PrSTout1: 1;
	unsigned char MskSTout2: 1;
	unsigned char PrSTout2: 1;

	unsigned char MskSTout3: 1;
	unsigned char PrSTout3: 1;
	unsigned char MskM0Tout0: 1;
	unsigned char PrM0Tout0: 1;
	unsigned char MskM0Tout1: 1;
	unsigned char PrM0Tout1: 1;
	unsigned char MskM0Tout2: 1;
	unsigned char PrM0Tout2: 1;

	unsigned char MskM0Tout3: 1;
	unsigned char PrM0Tout3: 1;
	unsigned char MskM1Tout0: 1;
	unsigned char PrM1Tout0: 1;
	unsigned char MskM1Tout1: 1;
	unsigned char PrM1Tout1: 1;
	unsigned char MskM1Tout2: 1;
	unsigned char PrM1Tout2: 1;

	unsigned char MskM1Tout3: 1;
	unsigned char PrM1Tout3: 1;
	unsigned char MskM2Tout0: 1;
	unsigned char PrM2Tout0: 1;
	unsigned char MskM2Tout1: 1;
	unsigned char PrM2Tout1: 1;
	unsigned char MskM2Tout2: 1;
	unsigned char PrM2Tout2: 1;

	unsigned char MskM2Tout3: 1;
	unsigned char PrM2Tout3: 1;
	unsigned char MskStatus0: 1;
	unsigned char PrStatus0: 1;
	unsigned char MskStatus1: 1;
	unsigned char PrStatus1: 1;
	unsigned char MskStatus2: 1;
	unsigned char PrStatus2: 1;

	unsigned char MskStatus3: 1;
	unsigned char PrStatus3: 1;
	unsigned char MskStatus4: 1;
	unsigned char PrStatus4: 1;
	unsigned char MskTask0: 1;
	unsigned char PrTask0: 1;
	unsigned char MskTask1: 1;
	unsigned char PrTask1: 1;

	unsigned char MskTask2: 1;
	unsigned char PrTask2: 1;
	unsigned char MskTask3: 1;
	unsigned char PrTask3: 1;
	unsigned char LoopCtl: 1;
	unsigned char PrLoopCtl: 1;
	unsigned char : 2;

	unsigned char OASnr: 1;
	unsigned char OATout: 1;
	unsigned char OASt: 1;
	unsigned char : 1;
	unsigned char OAGrp: 4;

	unsigned int FedStepA;
	unsigned int FedStepB;	

} Str_MxTin1Ci;




////////////////////////////////////
////////////////////////////////////
typedef struct {

	unsigned char MskSnr0: 1;
	unsigned char PrSnr0: 1;
	unsigned char MskSnr1: 1;
	unsigned char PrSnr1: 1;
	unsigned char MskSnr2: 1;
	unsigned char PrSnr2: 1;
	unsigned char MskSnr3: 1;
	unsigned char PrSnr3: 1;

	unsigned char MskSnr4: 1;
	unsigned char PrSnr4: 1;
	unsigned char MskSTout0: 1;
	unsigned char PrSTout0: 1;
	unsigned char MskSTout1: 1;
	unsigned char PrSTout1: 1;
	unsigned char MskSTout2: 1;
	unsigned char PrSTout2: 1;

	unsigned char MskSTout3: 1;
	unsigned char PrSTout3: 1;
	unsigned char MskM0Tout0: 1;
	unsigned char PrM0Tout0: 1;
	unsigned char MskM0Tout1: 1;
	unsigned char PrM0Tout1: 1;
	unsigned char MskM0Tout2: 1;
	unsigned char PrM0Tout2: 1;

	unsigned char MskM0Tout3: 1;
	unsigned char PrM0Tout3: 1;
	unsigned char MskM1Tout0: 1;
	unsigned char PrM1Tout0: 1;
	unsigned char MskM1Tout1: 1;
	unsigned char PrM1Tout1: 1;
	unsigned char MskM1Tout2: 1;
	unsigned char PrM1Tout2: 1;

	unsigned char MskM1Tout3: 1;
	unsigned char PrM1Tout3: 1;
	unsigned char MskM2Tout0: 1;
	unsigned char PrM2Tout0: 1;
	unsigned char MskM2Tout1: 1;
	unsigned char PrM2Tout1: 1;
	unsigned char MskM2Tout2: 1;
	unsigned char PrM2Tout2: 1;

	unsigned char MskM2Tout3: 1;
	unsigned char PrM2Tout3: 1;
	unsigned char MskStatus0: 1;
	unsigned char PrStatus0: 1;
	unsigned char MskStatus1: 1;
	unsigned char PrStatus1: 1;
	unsigned char MskStatus2: 1;
	unsigned char PrStatus2: 1;

	unsigned char MskStatus3: 1;
	unsigned char PrStatus3: 1;
	unsigned char MskStatus4: 1;
	unsigned char PrStatus4: 1;
	unsigned char MskTask0: 1;
	unsigned char PrTask0: 1;
	unsigned char MskTask1: 1;
	unsigned char PrTask1: 1;

	unsigned char MskTask2: 1;
	unsigned char PrTask2: 1;
	unsigned char MskTask3: 1;
	unsigned char PrTask3: 1;
	unsigned char LoopCtl: 1;
	unsigned char PrLoopCtl: 1;
	unsigned char : 2;

	unsigned char OASnr: 1;
	unsigned char OATout: 1;
	unsigned char OASt: 1;
	unsigned char : 1;
	unsigned char OAGrp: 4;

} Str_MxTin2Ci;



//////////////////////////
//////////////////////////


//Str_MxTin0Ci M0Tin0Ci[4];  //22*4 byte
//Str_MxTin1Ci M0Tin1Ci[4];  //17*4 byte
//Str_MxTin2Ci M0Tin2Ci[4];  //9*4 byte

//Str_MxTin0Ci M1Tin0Ci[4];  //22*4 byte
//Str_MxTin1Ci M1Tin1Ci[4];  //17*4 byte
//Str_MxTin2Ci M1Tin2Ci[4];  //9*4 byte

//Str_MxTin0Ci M2Tin0Ci[4];  //22*4 byte
//Str_MxTin1Ci M2Tin1Ci[4];  //17*4 byte
//Str_MxTin2Ci M2Tin2Ci[4];  //9*4 byte




//////////////////////////
//////////////////////////


typedef struct {

	unsigned int In0FedLmt;
	unsigned int In1FedLmt;
	unsigned short CycleLmt;
	unsigned char CaseCycle: 3;
	unsigned char CycleEn: 1;
	unsigned char : 4;

	unsigned char CaseN0: 2;
	unsigned char StepTp0: 2;
	unsigned char Dir0: 1;
	unsigned char Vref0: 3;
	unsigned char EnToutN0: 4;
	unsigned char PrToutN0: 4;
	unsigned short ClrToutN0;
	unsigned short BEndN0;
	unsigned char TGToutN0: 4;
	unsigned char PowerEn0: 1;
	unsigned char : 3;
	
	unsigned char CaseN1: 2;
	unsigned char StepTp1: 2;
	unsigned char Dir1: 1;
	unsigned char Vref1: 3;
	unsigned char EnToutN1: 4;
	unsigned char PrToutN1: 4;
	unsigned short ClrToutN1;
	unsigned short BEndN1;
	unsigned char TGToutN1: 4;
	unsigned char PowerEn1: 1;
	unsigned char : 3;
	
	unsigned char CaseN2: 2;
	unsigned char StepTp2: 2;
	unsigned char Dir2: 1;
	unsigned char Vref2: 3;
	unsigned char EnToutN2: 4;
	unsigned char PrToutN2: 4;
	unsigned short ClrToutN2;
	unsigned short BEndN2;
	unsigned char TGToutN2: 4;
	unsigned char PowerEn2: 1;
	unsigned char : 3;
	
	unsigned char CaseN3: 2;
	unsigned char StepTp3: 2;
	unsigned char Dir3: 1;
	unsigned char Vref3: 3;
	unsigned char EnToutN3: 4;
	unsigned char PrToutN3: 4;
	unsigned short ClrToutN3;
	unsigned short BEndN3;
	unsigned char TGToutN3: 4;
	unsigned char PowerEn3: 1;
	unsigned char : 3;

	
} Str_MxState;

//Str_MxState M0State;  //39 byte
//Str_MxState M1State;  //39 byte
//Str_MxState M2State;  //39 byte



//////////////////////////////////
//////////////////////////////////

typedef struct {

	unsigned char SIn0MskSnr0: 1;
	unsigned char SIn0PrSnr0: 1;
	unsigned char SIn0MakSnr1: 1;
	unsigned char SIn0PrSnr1: 1;
	unsigned char SIn0MakSnr2: 1;
	unsigned char SIn0PrSnr2: 1;
	unsigned char SIn0MakSnr3: 1;
	unsigned char SIn0PrSnr3: 1;
	
	unsigned char SIn0MakSnr4: 1;
	unsigned char SIn0PrSnr4: 1;
	unsigned char SIn0MskM0Tout0: 1;
	unsigned char SIn0PrM0Tout0: 1;
	unsigned char SIn0MskM0Tout1: 1;
	unsigned char SIn0PrM0Tout1: 1;
	unsigned char SIn0MskM0Tout2: 1;
	unsigned char SIn0PrM0Tout2: 1;
	
	unsigned char SIn0MskM0Tout3: 1;
	unsigned char SIn0PrM0Tout3: 1;
	unsigned char SIn0MskM1Tout0: 1;
	unsigned char SIn0PrM1Tout0: 1;
	unsigned char SIn0MskM1Tout1: 1;
	unsigned char SIn0PrM1Tout1: 1;
	unsigned char SIn0MskM1Tout2: 1;
	unsigned char SIn0PrM1Tout2: 1;
	
	unsigned char SIn0MskM1Tout3: 1;
	unsigned char SIn0PrM1Tout3: 1;
	unsigned char SIn0MskM2Tout0: 1;
	unsigned char SIn0PrM2Tout0: 1;
	unsigned char SIn0MskM2Tout1: 1;
	unsigned char SIn0PrM2Tout1: 1;
	unsigned char SIn0MskM2Tout2: 1;
	unsigned char SIn0PrM2Tout2: 1;
	
	unsigned char SIn0MskM2Tout3: 1;
	unsigned char SIn0PrM2Tout3: 1;
	unsigned char SIn0MskStatus0: 1;
	unsigned char SIn0PrStatus0: 1;
	unsigned char SIn0MskStatus1: 1;
	unsigned char SIn0PrStatus1: 1;
	unsigned char SIn0MskStatus2: 1;
	unsigned char SIn0PrStatus2: 1;
	
	unsigned char SIn0MskStatus3: 1;
	unsigned char SIn0PrStatus3: 1;
	unsigned char SIn0MskStatus4: 1;
	unsigned char SIn0PrStatus4: 1;
	unsigned char : 4;
		
	unsigned char SIn0OAjSnr: 1;
	unsigned char SIn0OAjTout: 1;
	unsigned char SIn0OAjSt: 1;
	unsigned char : 1;
	unsigned char SIn0OAjGrp: 3;
	unsigned char : 1;
	
	unsigned int SFedStep;
	
	
	unsigned char SIn1MskSnr0: 1;
	unsigned char SIn1PrSnr0: 1;
	unsigned char SIn1MakSnr1: 1;
	unsigned char SIn1PrSnr1: 1;
	unsigned char SIn1MakSnr2: 1;
	unsigned char SIn1PrSnr2: 1;
	unsigned char SIn1MakSnr3: 1;
	unsigned char SIn1PrSnr3: 1;
	unsigned char SIn1MakSnr4: 1;
	unsigned char SIn1PrSnr4: 1;
	unsigned char SIn1OAjSnr: 1;
	unsigned char : 5;
	unsigned int SFedStepA;
	unsigned int SFedStepB;


	unsigned char SIn2MskSnr0: 1;
	unsigned char SIn2PrSnr0: 1;
	unsigned char SIn2MakSnr1: 1;
	unsigned char SIn2PrSnr1: 1;
	unsigned char SIn2MakSnr2: 1;
	unsigned char SIn2PrSnr2: 1;
	unsigned char SIn2MakSnr3: 1;
	unsigned char SIn2PrSnr3: 1;
	unsigned char SIn2MakSnr4: 1;
	unsigned char SIn2PrSnr4: 1;
	unsigned char SIn2OAjSnr: 1;
	unsigned char : 5;	

	
} Str_ScanTinAsign;

//Str_ScanTinAsign ScanTin;  //23 byte




typedef struct {

	unsigned int SIn1FedLmt;
	unsigned char SEnToutN: 4;
	unsigned char SPrToutN: 4;
	unsigned short SClrToutN;
	unsigned short SBEndN;
	unsigned short SClrTout1N;
	unsigned short SClrTout2N;
	unsigned char STGToutN: 4;
	unsigned char SCaseN: 2;
	unsigned char : 2;

} Str_ScanStateAsign;

//Str_ScanStateAsign ScanState;  //14 byte



typedef struct {

	unsigned char Snr0No: 6;
	unsigned char : 2;
	unsigned char Snr1No: 6;
	unsigned char : 2;
	unsigned char Snr2No: 6;
	unsigned char : 2;
	unsigned char Snr3No: 6;
	unsigned char : 2;
	unsigned char Snr4No: 6;
	unsigned char : 2;
	unsigned char Status0No: 4;
	unsigned char Status1No: 4;
	unsigned char Status2No: 4;
	unsigned char Status3No: 4;
	unsigned char Status4No: 4;
	unsigned char : 4;
	unsigned char MainTsk0No: 4;
	unsigned char SubTsk0No: 4;
	unsigned char MainTsk1No: 4;
	unsigned char SubTsk1No: 4;
	unsigned char MainTsk2No: 4;
	unsigned char SubTsk2No: 4;
	unsigned char MainTsk3No: 4;
	unsigned char SubTsk3No: 4;
	unsigned char SnrStop0No: 6;
	unsigned char : 2;
	unsigned char SnrStop1No: 6;
	unsigned char : 2;
	unsigned char SnrStop2No: 6;
	unsigned char : 2;
	unsigned char SnrStop3No: 6;
	unsigned char : 2;
	unsigned char SnrStop4No: 6;
	unsigned char : 2;
	unsigned char StStop0No: 4;
	unsigned char StStop1No: 4;
	unsigned char StStop2No: 4;
	unsigned char StStop3No: 4;
	unsigned char StStop4No: 4;
	unsigned char : 4;
	unsigned char SnrExit0No: 6;
	unsigned char : 2;
	unsigned char SnrExit1No: 6;
	unsigned char : 2;
	unsigned char SnrExit2No: 6;
	unsigned char : 2;
	unsigned char SnrExit3No: 6;
	unsigned char : 2;
	unsigned char SnrExit4No: 6;
	unsigned char : 2;
	unsigned char StExit0No: 4;
	unsigned char StExit1No: 4;
	unsigned char StExit2No: 4;
	unsigned char StExit3No: 4;
	unsigned char StExit4No: 4;
	unsigned char : 4;
	unsigned char GPOAToutNo: 4;
	unsigned char GPOBToutNo: 4;

	unsigned char GPOASigDCNo: 4;
	unsigned char GPOBSigDCNo: 4;

	unsigned char GPOASigPenNo: 4;
	unsigned char GPOBSigPenNo: 4;


	unsigned char GPOSigSel: 4;
	unsigned char : 4;

} Str_STSAsign;

//Str_STSAsign STSAsign;  //32 byte




typedef struct {

	unsigned char M0MskSnrStop0: 1;
	unsigned char M0PrSnrStop0: 1;
	unsigned char M0MskSnrStop1: 1;
	unsigned char M0PrSnrStop1: 1;
	unsigned char M0MskSnrStop2: 1;
	unsigned char M0PrSnrStop2: 1;
	unsigned char M0MskSnrStop3: 1;
	unsigned char M0PrSnrStop3: 1;
	
	unsigned char M0MskSnrStop4: 1;
	unsigned char M0PrSnrStop4: 1;
	unsigned char M0MskStStop0: 1;
	unsigned char M0PrStStop0: 1;
	unsigned char M0MskStStop1: 1;
	unsigned char M0PrStStop1: 1;
	unsigned char M0MskStStop2: 1;
	unsigned char M0PrStStop2: 1;
	
	unsigned char M0MskStStop3: 1;
	unsigned char M0PrStStop3: 1;
	unsigned char M0MskStStop4: 1;
	unsigned char M0PrStStop4: 1;
	unsigned char M0OASnrStop: 1;
	unsigned char M0OAStStop: 1;
	unsigned char M0OAGrpStop : 2;
	
	unsigned char M0MskSnrExit0: 1;
	unsigned char M0PrSnrExit0: 1;
	unsigned char M0MskSnrExit1: 1;
	unsigned char M0PrSnrExit1: 1;
	unsigned char M0MskSnrExit2: 1;
	unsigned char M0PrSnrExit2: 1;
	unsigned char M0MskSnrExit3: 1;
	unsigned char M0PrSnrExit3: 1;
	
	unsigned char M0MskSnrExit4: 1;
	unsigned char M0PrSnrExit4: 1;
	unsigned char M0MskStExit0: 1;
	unsigned char M0PrStExit0: 1;
	unsigned char M0MskStExit1: 1;
	unsigned char M0PrStExit1: 1;
	unsigned char M0MskStExit2: 1;
	unsigned char M0PrStExit2: 1;
	
	unsigned char M0MskStExit3: 1;
	unsigned char M0PrStExit3: 1;
	unsigned char M0MskStExit4: 1;
	unsigned char M0PrStExit4: 1;
	unsigned char M0OASnrExit: 1;
	unsigned char M0OAStExit: 1;
	unsigned char M0OAGrpExit: 1;
	unsigned char : 1;
	
	unsigned char M1MskSnrStop0: 1;
	unsigned char M1PrSnrStop0: 1;
	unsigned char M1MskSnrStop1: 1;
	unsigned char M1PrSnrStop1: 1;
	unsigned char M1MskSnrStop2: 1;
	unsigned char M1PrSnrStop2: 1;
	unsigned char M1MskSnrStop3: 1; 
	unsigned char M1PrSnrStop3: 1;
	
	unsigned char M1MskSnrStop4: 1;
	unsigned char M1PrSnrStop4: 1;
	unsigned char M1MskStStop0: 1;
	unsigned char M1PrStStop0: 1;
	unsigned char M1MskStStop1: 1;
	unsigned char M1PrStStop1: 1;
	unsigned char M1MskStStop2: 1;
	unsigned char M1PrStStop2: 1;
	
	unsigned char M1MskStStop3: 1;
	unsigned char M1PrStStop3: 1;
	unsigned char M1MskStStop4: 1;
	unsigned char M1PrStStop4: 1;
	unsigned char M1OASnrStop: 1;
	unsigned char M1OAStStop: 1;
	unsigned char M1OAGrpStop : 2;
	
	unsigned char M1MskSnrExit0: 1;
	unsigned char M1PrSnrExit0: 1;
	unsigned char M1MskSnrExit1: 1;
	unsigned char M1PrSnrExit1: 1;
	unsigned char M1MskSnrExit2: 1;
	unsigned char M1PrSnrExit2: 1;
	unsigned char M1MskSnrExit3: 1;
	unsigned char M1PrSnrExit3: 1;
	
	unsigned char M1MskSnrExit4: 1;
	unsigned char M1PrSnrExit4: 1;
	unsigned char M1MskStExit0: 1;
	unsigned char M1PrStExit0: 1;
	unsigned char M1MskStExit1: 1;
	unsigned char M1PrStExit1: 1;
	unsigned char M1MskStExit2: 1;
	unsigned char M1PrStExit2: 1;
	
	unsigned char M1MskStExit3: 1;
	unsigned char M1PrStExit3: 1;
	unsigned char M1MskStExit4: 1;
	unsigned char M1PrStExit4: 1;
	unsigned char M1OASnrExit: 1;
	unsigned char M1OAStExit: 1;
	unsigned char M1OAGrpExit: 1;
	unsigned char : 1;
	
	unsigned char M2MskSnrStop0: 1;
	unsigned char M2PrSnrStop0: 1;
	unsigned char M2MskSnrStop1: 1;
	unsigned char M2PrSnrStop1: 1;
	unsigned char M2MskSnrStop2: 1;
	unsigned char M2PrSnrStop2: 1;
	unsigned char M2MskSnrStop3: 1;
	unsigned char M2PrSnrStop3: 1;
	
	unsigned char M2MskSnrStop4: 1;
	unsigned char M2PrSnrStop4: 1;
	unsigned char M2MskStStop0: 1;
	unsigned char M2PrStStop0: 1;
	unsigned char M2MskStStop1: 1;
	unsigned char M2PrStStop1: 1;
	unsigned char M2MskStStop2: 1;
	unsigned char M2PrStStop2: 1;
	
	unsigned char M2MskStStop3: 1;
	unsigned char M2PrStStop3: 1;
	unsigned char M2MskStStop4: 1;
	unsigned char M2PrStStop4: 1;
	unsigned char M2OASnrStop: 1;
	unsigned char M2OAStStop: 1;
	unsigned char M2OAGrpStop: 2;
	
	unsigned char M2MskSnrExit0: 1;
	unsigned char M2PrSnrExit0: 1;
	unsigned char M2MskSnrExit1: 1;
	unsigned char M2PrSnrExit1: 1;
	unsigned char M2MskSnrExit2: 1;
	unsigned char M2PrSnrExit2: 1;
	unsigned char M2MskSnrExit3: 1;
	unsigned char M2PrSnrExit3: 1;
	
	unsigned char M2MskSnrExit4: 1;
	unsigned char M2PrSnrExit4: 1;
	unsigned char M2MskStExit0: 1;
	unsigned char M2PrStExit0: 1;
	unsigned char M2MskStExit1: 1;
	unsigned char M2PrStExit1: 1;
	unsigned char M2MskStExit2: 1;
	unsigned char M2PrStExit2: 1;
	
	unsigned char M2MskStExit3: 1;
	unsigned char M2PrStExit3: 1;
	unsigned char M2MskStExit4: 1;
	unsigned char M2PrStExit4: 1;
	unsigned char M2OASnrExit: 1;
	unsigned char M2OAStExit: 1;
	unsigned char M2OAGrpExit: 1;
	unsigned char : 1;
	
	unsigned char SMskSnrStop0: 1;
	unsigned char SPrSnrStop0: 1;
	unsigned char SMskSnrStop1: 1;
	unsigned char SPrSnrStop1: 1;
	unsigned char SMskSnrStop2: 1;
	unsigned char SPrSnrStop2: 1;
	unsigned char SMskSnrStop3: 1;
	unsigned char SPrSnrStop3: 1;
	
	unsigned char SMskSnrStop4: 1;
	unsigned char SPrSnrStop4: 1;
	unsigned char SMskStStop0: 1;
	unsigned char SPrStStop0: 1;
	unsigned char SMskStStop1: 1;
	unsigned char SPrStStop1: 1;
	unsigned char SMskStStop2: 1;
	unsigned char SPrStStop2: 1;
	
	unsigned char SMskStStop3: 1;
	unsigned char SPrStStop3: 1;
	unsigned char SMskStStop4: 1;
	unsigned char SPrStStop4: 1;
	unsigned char SOASnrStop: 1;
	unsigned char SOAStStop: 1;
	unsigned char SOAGrpStop: 1;
	unsigned char : 1;


} Str_MtrStopTgr;

//Str_MtrStopTgr MtrStopTgr;  //21 byte




typedef struct {

	unsigned char Sensor0: 1;
	unsigned char Sensor1: 1;
	unsigned char Sensor2: 1;
	unsigned char Sensor3: 1;
	unsigned char Sensor4: 1;
	unsigned char Status0: 1;
	unsigned char Status1: 1;
	unsigned char Status2: 1;

	unsigned char Status3: 1;
	unsigned char Status4: 1;
	unsigned char Stop_Senr0: 1;
	unsigned char Stop_Senr1: 1;
	unsigned char Stop_Senr2: 1;
	unsigned char Stop_Senr3: 1;
	unsigned char Stop_Senr4: 1;
	unsigned char StStop0: 1;

	unsigned char StStop1: 1;
	unsigned char StStop2: 1;
	unsigned char StStop3: 1;
	unsigned char StStop4: 1;
	unsigned char Exit_Senr0: 1;
	unsigned char Exit_Senr1: 1;
	unsigned char Exit_Senr2: 1;
	unsigned char Exit_Senr3: 1;

	unsigned char Exit_Senr4: 1;
	unsigned char StExit0: 1;
	unsigned char StExit1: 1;
	unsigned char StExit2: 1;
	unsigned char StExit3: 1;
	unsigned char StExit4: 1;
	unsigned char move2err: 1;
	unsigned char : 1;

	unsigned char M0In0SnrTrg: 1;
	unsigned char M0In0MtrTrg: 1;
	unsigned char M0In0StsTrg: 1;
	unsigned char M0In0TskTrg: 1;
	unsigned char M0In1SnrTrg: 1;
	unsigned char M0In1MtrTrg: 1;
	unsigned char M0In1StsTrg: 1;
	unsigned char M0In1TskTrg: 1;

	unsigned char M0In2SnrTrg: 1;
	unsigned char M0In2MtrTrg: 1;
	unsigned char M0In2StsTrg: 1;
	unsigned char M0In2TskTrg: 1;
	unsigned char M0SnrStop: 1;
	unsigned char M0StStop: 1;
	unsigned char M0SnrExit: 1;
	unsigned char M0StExit: 1;

	unsigned char M1In0SnrTrg: 1;
	unsigned char M1In0MtrTrg: 1;
	unsigned char M1In0StsTrg: 1;
	unsigned char M1In0TskTrg: 1;
	unsigned char M1In1SnrTrg: 1;
	unsigned char M1In1MtrTrg: 1;
	unsigned char M1In1StsTrg: 1;
	unsigned char M1In1TskTrg: 1;

	unsigned char M1In2SnrTrg: 1;
	unsigned char M1In2MtrTrg: 1;
	unsigned char M1In2StsTrg: 1;
	unsigned char M1In2TskTrg: 1;
	unsigned char M1SnrStop: 1;
	unsigned char M1StStop: 1;
	unsigned char M1SnrExit: 1;
	unsigned char M1StExit: 1;

	unsigned char M2In0SnrTrg: 1;
	unsigned char M2In0MtrTrg: 1;
	unsigned char M2In0StsTrg: 1;
	unsigned char M2In0TskTrg: 1;
	unsigned char M2In1SnrTrg: 1;
	unsigned char M2In1MtrTrg: 1;
	unsigned char M2In1StsTrg: 1;
	unsigned char M2In1TskTrg: 1;

	unsigned char M2In2SnrTrg: 1;
	unsigned char M2In2MtrTrg: 1;
	unsigned char M2In2StsTrg: 1;
	unsigned char M2In2TskTrg: 1;
	unsigned char M2SnrStop: 1;
	unsigned char M2StStop: 1;
	unsigned char M2SnrExit: 1;
	unsigned char M2StExit: 1;

	unsigned char M0Tin0: 1;
	unsigned char M0Tin1: 1;
	unsigned char M0Tin2: 1;
	unsigned char M1Tin0: 1;
	unsigned char M1Tin1: 1;
	unsigned char M1Tin2: 1;
	unsigned char M2Tin0: 1;
	unsigned char M2Tin1: 1;

	unsigned char M2Tin2: 1;
	unsigned char STin0: 1;
	unsigned char STin1: 1;
	unsigned char STin2: 1;
	unsigned char Passing: 1;
	unsigned char ScanFlg: 1;
	unsigned char move0err: 1;
	unsigned char move1err: 1;

	unsigned char M0CaseIdx: 2;
	unsigned char M1CaseIdx: 2;
	unsigned char M2CaseIdx: 2;
	unsigned char M0CaseN: 2;

	unsigned char M1CaseN: 2;
	unsigned char M2CaseN: 2;
	unsigned char move0jam: 1;
	unsigned char move1jam: 1;
	unsigned char move2jam: 1;
	unsigned char Mot0PEnb: 1;

	unsigned char Mot1PEnb: 1;
	unsigned char Mot2PEnb: 1;
	unsigned char MotPEnb: 1;
	unsigned char DCMotMFlg: 1;
	unsigned char DCMotM1Flg: 1;
	unsigned char DCMotM2Flg: 1;
	unsigned char DCAccel: 1;
	unsigned char DCDecel: 1;

	unsigned char MotPEnbx: 1;
	unsigned char Mot1PEnbx: 1;
	unsigned char Mot2PEnbx: 1;
	unsigned char MotDrFlg: 1;
	unsigned char Mot1Dir: 1;
	unsigned char Mot2Dir: 1;
	unsigned char GPOATout: 1;
	unsigned char GPOBTout: 1;

	unsigned short DC0Vec;
	signed int DC0FedStep;
	signed int DC1FedStep;
	signed int DC2FedStep;

} Str_FlowData;

//Str_FlowData FlowData;  //30 byte



///////////////////////////////////////////////////////////////////////

Str_MxTin0Ci M0Tin0Ci_Rd[4];  //0x000, 88
Str_MxTin1Ci M0Tin1Ci_Rd[4];  //0x080, 68
Str_MxTin2Ci M0Tin2Ci_Rd[4];  //0x100, 36
Str_MxTin0Ci M1Tin0Ci_Rd[4];  //0x180, 88
Str_MxTin1Ci M1Tin1Ci_Rd[4];  //0x200, 68
Str_MxTin2Ci M1Tin2Ci_Rd[4];  //0x280, 36
Str_MxTin0Ci M2Tin0Ci_Rd[4];  //0x300, 88
Str_MxTin1Ci M2Tin1Ci_Rd[4];  //0x380, 68
Str_MxTin2Ci M2Tin2Ci_Rd[4];  //0x400, 36
Str_MxState M0State_Rd;           //0x440, 39
Str_MxState M1State_Rd;           //0x480, 39
Str_MxState M2State_Rd;           //0x4C0, 39
Str_ScanTinAsign ScanTin_Rd;      //0x500, 23
Str_ScanStateAsign ScanState_Rd;  //0x520, 14
Str_STSAsign STSAsign_Rd;         //0x540, 32
Str_MtrStopTgr MtrStopTgr_Rd;     //0x560, 21
Str_FlowData FlowData_Rd;         //0x580, 30
///////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////

Str_MxTin0Ci M0Tin0Ci_Wt[4];  //0x000, 88
Str_MxTin1Ci M0Tin1Ci_Wt[4];  //0x080, 68
Str_MxTin2Ci M0Tin2Ci_Wt[4];  //0x100, 36
Str_MxTin0Ci M1Tin0Ci_Wt[4];  //0x180, 88
Str_MxTin1Ci M1Tin1Ci_Wt[4];  //0x200, 68
Str_MxTin2Ci M1Tin2Ci_Wt[4];  //0x280, 36
Str_MxTin0Ci M2Tin0Ci_Wt[4];  //0x300, 88
Str_MxTin1Ci M2Tin1Ci_Wt[4];  //0x380, 68
Str_MxTin2Ci M2Tin2Ci_Wt[4];  //0x400, 36
Str_MxState M0State_Wt;           //0x440, 39
Str_MxState M1State_Wt;           //0x480, 39
Str_MxState M2State_Wt;           //0x4C0, 39
Str_ScanTinAsign ScanTin_Wt;      //0x500, 23
Str_ScanStateAsign ScanState_Wt;  //0x520, 14
Str_STSAsign STSAsign_Wt;         //0x540, 32
Str_MtrStopTgr MtrStopTgr_Wt;     //0x560, 21
//Str_FlowData FlowData_Wt;         //0x580, 30
///////////////////////////////////////////////////////////////////////


#endif // _gideviceinidb_h 