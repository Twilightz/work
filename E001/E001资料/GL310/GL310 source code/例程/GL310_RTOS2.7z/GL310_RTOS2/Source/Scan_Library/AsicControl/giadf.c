////////////////////////////////////////////////////////////////
// File - giadf.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"
#include "cmd.h"

extern unsigned int DuplexscanFlag;

extern int FullPage, ADFMotorGear;
extern float PaperLen, f_Prefeed, f_Pstfeed, f_Feedl, f_ScanLen;
extern float Sensor_gap;
extern unsigned int JpgFullLmt;

extern int m_iScanTableUnit, m_iFastTableUnit;
extern int adf_cur1;
extern int adf_cur2;
extern int fb_cur1;
extern int fb_cur2;


int CtlADF_ADFInit(void) 
{
	int bRet;
	bRet = CMDASIC_WriteFourRegister(0x000c,0x00000200);	//CLRDOCJM
	if(!bRet)	return False;
	bRet = CMDASIC_WriteRegisterBit(0x0008,3,2,3);			//MPENB, SCNUMENB
	if(!bRet)	return False;
	return True;
}

int CtlADF_DetectADFConnect(int *pADF)  //check ADF module is ready
{
	int bRet = 1;
	unsigned char bData;
	
	//check ADF connect connect on GPIO 8.
	bRet = CMDASIC_ReadRegister(0x0031, &bData);  
	if(!bRet)	return False;
	if(bData & 0x80)				
		*pADF = 0;				// disconnect
	else
		*pADF = 1;				// connect
	return True;
}


int CtlADF_GetDocumentSensor(int *pDocSensor)  //0=bepress, 1=no bepress
{
	int bRet = 1;
	unsigned char bData;

	// control GPIO, change to Document sensor

	bRet = CMDASIC_ReadRegister(0x0400, &bData);

#if 0
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);

	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);


	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);


	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	bRet = CMDASIC_ReadRegister(0x0400, &bData);

#endif
	
	if(!bRet)	return False;
	//*pDocSensor = (bData & 0x80) >> 7;
	if(bData & 0x80)				
		*pDocSensor = 1;
	else
		*pDocSensor = 0;

	// control GPIO, change to Home sensor

	return True;
}

int CtlADF_GetADFSensor(int *pADFSensor)
{
	int bRet = 1;
	unsigned char bData;

	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	if(!bRet)	return False;
	*pADFSensor = (bData & 0x40) >> 6;	

	return True;
}

int Api_CtlADF_ADFMotorOpen(void)
{
	return CtlADF_ADFMotorOpen();
}


int CtlADF_ADFMotorClose(void)
{
	return True;
}


int CtlADF_SetADFSEL(unsigned char bEnable)
{
	if(bEnable){
		ADF_Motor_Enable();
		CMDASIC_WriteRegisterBit(0x000a,0,1,bEnable);
		CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
		CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
		CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR
	}

	return True;
}


int CtlADF_CheckPaperJam(int *jam)	
{	
	int bRet = 1;
	unsigned char bData;
	bRet = CMDASIC_ReadRegister(0x0400, &bData);
	if(!bRet)	return False;

	*jam = ( (bData & 0x08) ? True : False );
	if(*jam) {
		CtlImage_EnableScan(False);
	}
	return True;
}



int CtlADF_GetADFScNum(ScanParameter *pSPM, unsigned short *scnum)
{
	unsigned int raw_jpg_page;

	//CMDASIC_ReadFourRegister(0x03d0,&raw_jpg_page);  //raw & jpg page number
	if((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1))
		CMDASIC_ReadFourRegister(0x09d0,&raw_jpg_page);  //raw & jpg page number
	else
		CMDASIC_ReadFourRegister(0x03d0,&raw_jpg_page);  //raw & jpg page number
	
	if((pSPM->spJPEGENC)&0x0f)
		(*scnum) = (unsigned short)((raw_jpg_page&0xffff0000)>>16);
	else
		(*scnum) = (unsigned short)(raw_jpg_page&0x0000ffff);
	return True;
}


int CtlADF_ADFsetting(ScanParameter *pSPM)
{
	//int ADFMotorGear=150; //1024; //166; //300;
	int ADFType = (pSPM->spADFscan)&0x0f;
	unsigned char V_CCDLMT = pSPM->spCCDLMT+1;
	unsigned int dwFeedLoad, dwPreFeed, dwPostFeed, dwScanLen;

	if (ADFType==1) {//single ADF

		dwFeedLoad = (unsigned int)(m_iScanTableUnit*ADFMotorGear*f_Feedl); 
		dwScanLen  = (unsigned int)(pSPM->spPixelResolution*f_ScanLen); 

#if 0
		dwPreFeed  = (unsigned int)(m_iScanTableUnit*ADFMotorGear*f_Prefeed);
		dwPostFeed = (unsigned int)(pSPM->spPixelResolution*f_Pstfeed);
#endif
		dwPreFeed  = (unsigned int)(m_iScanTableUnit*ADFMotorGear * 
			( ((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1)) ? (f_Prefeed+Sensor_gap) : f_Prefeed) );
		dwPostFeed = (unsigned int)(pSPM->spPixelResolution * 
			( ((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1)) ? (f_Pstfeed+Sensor_gap) : f_Pstfeed) );
		
				
		CMDASIC_WriteFourRegister(0x0170,dwFeedLoad );	               // FEEDL   : unit is motor step
		CMDASIC_WriteFourRegister(0x0174,(unsigned int)dwPreFeed );	   // PREFEED : unit is motor step
		CMDASIC_WriteTwiRegister(0x0178,(unsigned short)(dwPostFeed*V_CCDLMT));   // PSTFED  : unit is line number
		CMDASIC_WriteFourRegister(0x017c,dwScanLen*V_CCDLMT);	                  // SCANLEN : unit is line number
		//CMDASIC_WriteFourRegister(0x0204,(unsigned int)(dwScanLen*1.1*V_CCDLMT)); // LINCNT : set more than SCANLEN

		CMDASIC_WriteRegisterBit(0x000a,1,2,0);  //AUTOADF=0, FULLPAGE=0

		CtlADF_ADFMotorOpen();
		CtlMotor_EnableFastMove(0);

	} 

	if (ADFType==2) {//Auto ADF

		dwFeedLoad = (unsigned int)(m_iScanTableUnit*ADFMotorGear*f_Feedl); 
		dwScanLen  = (unsigned int)(pSPM->spPixelResolution*f_ScanLen); 
#if 0
		dwPreFeed  = (unsigned int)(m_iScanTableUnit*ADFMotorGear*f_Prefeed);
		dwPostFeed = (unsigned int)(pSPM->spPixelResolution*f_Pstfeed);
#endif
		dwPreFeed  = (unsigned int)(m_iScanTableUnit*ADFMotorGear * 
			( ((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1)) ? (f_Prefeed+Sensor_gap) : f_Prefeed) );
		dwPostFeed = (unsigned int)(pSPM->spPixelResolution * 
			( ((pSPM->spDualscan==0)&&(pSPM->spSimplexSide==1)) ? (f_Pstfeed+Sensor_gap) : f_Pstfeed) );

				
		CMDASIC_WriteFourRegister(0x0170,dwFeedLoad );	               // FEEDL   : unit is motor step
		CMDASIC_WriteFourRegister(0x0174,(unsigned int)dwPreFeed );	   // PREFEED : unit is motor step
		CMDASIC_WriteTwiRegister(0x0178,(unsigned short)(dwPostFeed*V_CCDLMT));   // PSTFED  : unit is line number
		CMDASIC_WriteFourRegister(0x017c,dwScanLen*V_CCDLMT);	                  // SCANLEN : unit is line number
		//CMDASIC_WriteFourRegister(0x0204,(unsigned int)(dwScanLen*1.1*V_CCDLMT)); // LINCNT : set more than SCANLEN

		Api_CtlADF_ADFMotorOpen();
		CtlMotor_EnableFastMove(0);

		if(FullPage==1) {
			unsigned int bufline,revline;

			//raw scan
			if ((pSPM->spJPEGENC&0x0f)==0) {  
				revline = (unsigned int)(PaperLen*pSPM->spMotorResolution / 8 * 8);  //about 12inch page length, area scan need change small
				CMDASIC_ReadFourRegister(0x02a4, &bufline);
				if (bufline < revline) { 
					printf(" not enough memory for autoadf & fullpage !!!!!! \n");
					return False;
				}
				//raw data full condition set PAGELINE
				CMDASIC_WriteFourRegister(0x034c,bufline-revline); 

			//jpg scan
			} else {  

				CMDASIC_ReadFourRegister(0x02a4, &bufline);
				CMDASIC_WriteFourRegister(0x034c,bufline);    //PAGELINE=calculated MAXLINE
				CMDASIC_WriteFourRegister(0x02a4,0xffffffff); //MAXLINE=max value

				//JPG data full condition set jpeg_page_size
				CMDASIC_WriteFourRegister(0x03e8,JpgFullLmt);  //jpg_page_line //about 3.3Mb every jpg file

			}

			CMDASIC_WriteRegisterBit(0x000a,1,2,3);  //AUTOADF=1, FULLPAGE=1

		} else {

			CMDASIC_WriteRegisterBit(0x000a,1,2,1);  //AUTOADF=1, FULLPAGE=0

		}


	} 

	CtlMotor_WriteMotorRemainder(0,0);
	CtlMotor_SetMotorPowerBit(1);

	return True;

}
int CtlADF_ADFMotorOpen(void)
{
//HL modify
#if 0
	int bRet = 1;
	int ADF_MS1, ADF_MS2;

	//GPIO87 nENABLE
	ADF_Motor_Enable();

/*======ADF_Motor setup=====*/

	/* //GPIO40  MOTOR STEP
	CMDASIC_WriteRegisterBit(0x0066,0,2,1); 
	CMDASIC_WriteRegisterBit(0x005c,7,1,1); 
	//CMDASIC_WriteRegisterBit(0x0054,7,1,0); */

	//Use the same STEP pin with FB motor
	/* //GPIO42  MOTOR DIR
	CMDASIC_WriteRegisterBit(0x0066,4,1,0); 
	CMDASIC_WriteRegisterBit(0x005d,1,1,1); 
	CMDASIC_WriteRegisterBit(0x0055,1,1,0); */
	CtlADFMotor_SetMotorDirect(1);

/*=========================
	MS1	MS2	STEP	
	L		L		Full
	H		L		Half
	L		H		Quarter
	H		H		Eighth
========================*/

	//GPIO2  MOTOR MS1
	/*CMDASIC_WriteRegisterBit(0x0060,1,1,0); 
	CMDASIC_WriteRegisterBit(0x0050,1,1,0); 
	CMDASIC_WriteRegisterBit(0x0058,1,1,1); 

	//GPIO3  MOTOR MS2
	CMDASIC_WriteRegisterBit(0x0060,2,1,0); 
	CMDASIC_WriteRegisterBit(0x0050,2,1,1); 
	CMDASIC_WriteRegisterBit(0x0058,2,1,1); */

	//GPIO16  nRESET
	CMDASIC_WriteRegisterBit(0x0061,7,1,0); 
	CMDASIC_WriteRegisterBit(0x0051,7,1,1); 
	CMDASIC_WriteRegisterBit(0x0059,7,1,1); 

	//GPIO35  nSLEEP
	CMDASIC_WriteRegisterBit(0x0064,6,2,0); 
	CMDASIC_WriteRegisterBit(0x0065,0,1,0);
	CMDASIC_WriteRegisterBit(0x005c,2,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,2,1,1); 

	CtlMotor_SetMotorCurrent(adf_cur1, adf_cur2);

	/*//GPIO36  MOTOR CUR SW1
	CMDASIC_WriteRegisterBit(0x0065,1,1,0);
	CMDASIC_WriteRegisterBit(0x005c,3,1,1); 
	CMDASIC_WriteRegisterBit(0x0054,3,1,1);

	//GPIO37  MOTOR CUR SW2
	CMDASIC_WriteRegisterBit(0x0065,2,2,0);
	CMDASIC_WriteRegisterBit(0x005c,4,1,0); 
	CMDASIC_WriteRegisterBit(0x0054,4,1,1);*/
#endif
	return True;
}

#if 0
int ADF_Motor_Enable(void)
{
//HL modify
#if 0
	//Enable GPIO86,87 work as GPIO function
	int nReg68,nValue_87,nDir_87;

	CMDASIC_ReadBus(0xa0000068, &nReg68);
	CMDASIC_ReadBus(0xa000005c, &nDir_87);
	CMDASIC_ReadBus(0xa0000058, &nValue_87);

	CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xfffff3ff)); //Set GPIO87 work as GPIO mode
	CMDASIC_WriteBus(0xa000005c, (nDir_87 | 0x00018000)); //Set GPIO87 output
	//CMDASIC_WriteBus(0xa0000058, (nValue_87 | 0x00018000)); //Set GPIO87 =1 
	CMDASIC_WriteBus(0xa0000058, (nValue_87 & 0x00007000)); //Set GPIO87 =0 nEnable 

	/*CMDASIC_ReadBus(0xa0000068, &nReg68);
	CMDASIC_ReadBus(0xa000005c, &nDir_87);
	CMDASIC_ReadBus(0xa0000058, &nValue_87);*/
#endif
	return True; 	
}
#else
int ADF_Motor_Enable(void)
{
//HL modify
#if 0
	int nReg68,nValue_87,nDir_87;

	CMDASIC_ReadBus(0xa0000068, &nReg68);
	CMDASIC_ReadBus(0xa000005c, &nDir_87);
	CMDASIC_ReadBus(0xa0000058, &nValue_87);
//
	//CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffB3ff)); 
#ifdef CANOPUS_COM2
	CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffBfff)); 
	CMDASIC_WriteBus(0xa000005c, (nDir_87 | 0x00078000)); 
	CMDASIC_WriteBus(0xa0000058, (nValue_87 | 0x00078000));  
	CMDASIC_WriteBus(0xa0000058, (nValue_87 & 0xfff07fff));  
	CMDASIC_WriteBus(0xa0000058, ( 0xfff7ffff));//0xfff2ffff CIS2 ON 
#else
	CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffB7ff)); 
	CMDASIC_WriteBus(0xa000005c, (nDir_87 | 0x00060000)); 
	CMDASIC_WriteBus(0xa0000058, (nValue_87 | 0x00060000));  
	CMDASIC_WriteBus(0xa0000058, (nValue_87 & 0xfff0ffff));  
	CMDASIC_WriteBus(0xa0000058, ( 0xfff6ffff));//0xfff2ffff CIS2 ON 
#endif
	CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
	CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
	CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR
#endif
	return True; 	
}
#endif
int FB_Motor_Enable(void)
{
//HL modify
#if 0
	int nReg68,nValue_87,nDir_87;

	CMDASIC_ReadBus(0xa0000068, &nReg68);
	CMDASIC_ReadBus(0xa000005c, &nDir_87);
	CMDASIC_ReadBus(0xa0000058, &nValue_87);
//
	//CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffB3ff)); 
#ifdef CANOPUS_COM2
	CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffBfff)); 
	CMDASIC_WriteBus(0xa000005c, (nDir_87 | 0x00078000));
	CMDASIC_WriteBus(0xa0000058, (nValue_87 & 0xFFF38FFF));
#else
	CMDASIC_WriteBus(0xa0000068, (nReg68 & 0xffffB7ff)); 
	CMDASIC_WriteBus(0xa000005c, (nDir_87 | 0x00060000));
	CMDASIC_WriteBus(0xa0000058, (nValue_87 & 0xFFF2FFFF));
#endif
#endif
	return True; 	
}

//D8V_LED_ON 
int CtlADF_LEDPWR(unsigned char nEnable)
{
//HL modify
#if 0
	unsigned int nValue_LED, nDir_LED;

	CMDASIC_ReadBus(0xa0000058, &nValue_LED);
	CMDASIC_ReadBus(0xa000005c, &nDir_LED);

	if(nEnable){ //Turn-on Lamp
		if(DuplexscanFlag){
			CMDASIC_WriteBus(0xa0000058, (nValue_LED | 0x00000800)); //Set GPIO81=0,GPIO82 =1 
			CMDASIC_WriteBus(0xa000005c, (nDir_LED | 0x00000c00)); //Set GPIO81,82 = output
		}
		else{
			CMDASIC_WriteBus(0xa0000058, (nValue_LED | 0x00000400)); //Set GPIO81=1,GPIO82 =0 
			CMDASIC_WriteBus(0xa000005c, (nDir_LED | 0x00000c00)); //Set GPIO81,82 = output
		}
	}
	else{ //Turn-off Lamp
		CMDASIC_WriteBus(0xa0000058, (nValue_LED & 0xfffff3ff)); //Set GPIO81,82 =0 
		CMDASIC_WriteBus(0xa000005c, (nDir_LED | 0x00000c00)); //Set GPIO81,82 = output
	}
#endif	
	return True;
}
