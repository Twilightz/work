////////////////////////////////////////////////////////////////
// File - gidevice.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"
#include "gideviceinidb.h"
#include "cmd.h"

float CtlDevice_PixelTime;

int CtlDevice_OpenDevice(void)
{
	int bRet, i;
	unsigned char *Buf;
	//bRet=CMDIO_OpenDevice();
	//if (!bRet) return False;

	CMDASIC_WriteBus(0xa0000050, 0xffffffff);

	CMDASIC_WriteBus(0x90100080, 0x00000060);

//HL modify
#if 0
	//CMDASIC_WriteBus(0x90300160, 0x00000750*Clock_ASIC/120);
	CMDASIC_WriteBus(0xa0000058, 0x0003b42e);
	CMDASIC_WriteBus(0xa000005c, 0x00004432);
	CMDASIC_WriteBus(0xa0000068, 0x00072c40);
#endif

	//HL modify
	//Buf= malloc(MAX_SCAN_REGISTERS);
	Buf = (UINT8 *)fLib_NC_malloc(MAX_SCAN_REGISTERS);
		
	if (Buf == NULL)	return False;
	bRet=CMDASIC_ReadBulkData(0xB0000000, Buf, MAX_SCAN_REGISTERS);
	if (!bRet) return False;

	for (i=0; i<MAX_SCAN_REGISTERS; i++) {
		CMDASIC_RegTable[i].nValue=Buf[i];
		if (CMDASIC_RegTable[i].nValue!=0)
			bRet=bRet;
	}
	
	//free(Buf);
	fLib_NC_malloc(Buf);

	//for (i=0; i<MAX_SCAN_REGISTERS; i++) {
	//	bRet=CMDASIC_ReadRegister(i,&(CMDASIC_RegTable[i].nValue) );
	//	if (!bRet) return False;
	//	if (CMDASIC_RegTable[i].nValue!=0)
	//		bRet=bRet;
	//}


//	CMDASIC_WriteBus(0xa0000058, 0x0003b42e);
//	CMDASIC_WriteBus(0xa000005c, 0x00004432);
//	CMDASIC_WriteBus(0xa0000068, 0x00072c40);

 	return True;
}


int CtlDevice_CloseDevice(void)
{
   //return CMDIO_CloseDevice();
	return True;
}


//load initial asic/afe register and set initail usb/asic clock
int CtlDevice_LoadInitRegData(void)
{
	unsigned int iRegNum, i, bRet=1;
	unsigned short data;
	unsigned int  nVal,	nVal_LED,nDir_LED; 

    if(BENG_Active) {
		BENG_Init_WriteDirect();
	}

	//load initial asic register
	iRegNum=sizeof(ASIC_INIT_REG)/sizeof(unsigned int);
	for (i=0; i<iRegNum; i=i+2) {
		bRet=CMDASIC_WriteFourRegister((unsigned short)ASIC_INIT_REG[i],ASIC_INIT_REG[i+1]);
		if(!bRet) return False;
	}

//HL modify
#if 0
	CMDASIC_ReadBus(0xa0000058, &nVal_LED);
	CMDASIC_ReadBus(0xa000005c, &nDir_LED);

	CMDASIC_WriteBus(0xa0000058, (nVal_LED & 0xffffff80)); //Set GPIO77 =1 
	CMDASIC_WriteBus(0xa000005c, (nDir_LED & 0xffffff80)); //Set GPIO77 = output
#endif



#if 1
	{
	unsigned int nGpio=0x00000000;

	/*

	//GPIO 42 ?? // BAT_CONTROL
	CMDASIC_WriteRegisterBit(0x0066,4,1,0);
	CMDASIC_WriteRegisterBit(0x005D,1,1,1);
	CMDASIC_WriteRegisterBit(0x0055,1,1,1);



	//GPIO 27 // BAT_CONTROL_P
	CMDASIC_WriteRegisterBit(0x0064,0,1,0);
	CMDASIC_WriteRegisterBit(0x005B,2,1,1);
	CMDASIC_WriteRegisterBit(0x0053,2,1,1);

	*/

	//GPIO 23  // D5V_EN
	CMDASIC_WriteRegisterBit(0x0063,3,2,0);
	CMDASIC_WriteRegisterBit(0x005A,6,1,1);
	CMDASIC_WriteRegisterBit(0x0052,6,1,1);



	//GPIO 81  // STANDBY_ENABLE
		{
		CMDASIC_ReadBus(0xA0000068, &nGpio);
		nGpio &= 0xfffffffe; //LCM_SEL=0
		CMDASIC_WriteBus(0xA0000068,nGpio);

		CMDASIC_ReadBus(0xA000005C, &nGpio);
		nGpio |= 0x00000400;
		CMDASIC_WriteBus(0xA000005C,nGpio);

		CMDASIC_ReadBus(0xA0000058, &nGpio);
		//nGpio &= 0xfffffbff;
		nGpio |= 0x00000400;  //ok for motor move
		CMDASIC_WriteBus(0xA0000058,nGpio);
		}

	//GPIO 72  // SENSOR_CONTROL
		{
		CMDASIC_ReadBus(0xA0000068, &nGpio);
		nGpio &= 0xfffffffe; //LCM_SEL=0
		CMDASIC_WriteBus(0xA0000068,nGpio);

		CMDASIC_ReadBus(0xA000005C, &nGpio);
		nGpio |= 0x00000002;
		CMDASIC_WriteBus(0xA000005C,nGpio);

		CMDASIC_ReadBus(0xA0000058, &nGpio);
		//nGpio &= 0xfffffffd;
		nGpio |= 0x00000002;  // ok for ADF/DOC sensor
		CMDASIC_WriteBus(0xA0000058,nGpio);
		}


	/*
	//GPIO 17  // AFE_SDO
	CMDASIC_WriteRegisterBit(0x005a,0,1,1); 
	CMDASIC_WriteRegisterBit(0x0062,0,1,0); //1); 
	CMDASIC_WriteRegisterBit(0x0069,3,1,0);
	*/


	///*
	//GPIO 89  ?? // VPOWER_ENABLE
		{
		CMDASIC_ReadBus(0xA0000068, &nGpio);
		nGpio &= 0xfffffbff; // UARTA_SEL=0
		CMDASIC_WriteBus(0xA0000068,nGpio); 
 
		CMDASIC_ReadBus(0xA000005C, &nGpio);
		nGpio |= 0x00040000;
		CMDASIC_WriteBus(0xA000005C,nGpio);

		CMDASIC_ReadBus(0xA0000058, &nGpio);
		//nGpio &= 0xfffbffff;
		nGpio |= 0x00040000;
		CMDASIC_WriteBus(0xA0000058,nGpio);
		}
	//*/

	/*
	//GPIO 30  // DC_JACK_CONTROL ??
	CMDASIC_WriteRegisterBit(0x0064,5,1,0);
	CMDASIC_WriteRegisterBit(0x005B,5,1,1);
	CMDASIC_WriteRegisterBit(0x0053,5,1,0);
	*/


	//ck4 GPIO 39 output
	CMDASIC_WriteRegisterBit(0x0065,6,2,1);
	CMDASIC_WriteRegisterBit(0x005C,6,1,1);


	// VREF control GPIO 36/37/38
	CMDASIC_WriteRegisterBit(0x0065,1,5,0); 
	CMDASIC_WriteRegisterBit(0x005C,3,3,7);
	CMDASIC_WriteRegisterBit(0x0054,3,3,0);  //0~7, max=0



	}
#endif

//HL modify
	//load initial afe register
	iRegNum=sizeof(AFE_INIT_REG)/sizeof(unsigned short);
	for (i=0; i<iRegNum; i=i+2) {
		bRet=CtlAfe_WriteAFERegister(AFE_INIT_REG[i],AFE_INIT_REG[i+1]);
		if(!bRet) return False;
	}

	//load asic clock
	bRet=CtlDevice_SetScannerClock((unsigned char)Clock_ASIC);
	if(!bRet) return False;

	//load SCANMOD
	bRet=CtlDevice_SetScanMOD((unsigned char)Clock_Pixel);
	if(!bRet) return False;

	bRet=CtlADF_ADFInit();
	if(!bRet) return False;
	
	CtlSensor_iOptRes = CCD_DPIHW;
	CtlImage_ShadingBase = ( (ShadingGain==8) ? 0x2000 : 0x4000 );

	bRet=CtlImage_RamSet_ShadingBank();
	if(!bRet) return False;

	bRet=CtlImage_SetDefaultGamma(1);
	if(!bRet) return False;

	switch(Sensor_type){
		case 0:  //1CH CIS
			bRet=CtlImage_SetDefaultShading16_1CH();  //bRet=CtlImage_SetDefaultShading32_1CH();
			break;
		case 1:  //3CH CIS
			bRet=CtlImage_SetDefaultShading16_3CH();  //bRet=CtlImage_SetDefaultShading32_3CH();
			break;
		case 2:  //CCD
			bRet=CtlImage_SetDefaultShading16_CCD();  //bRet=CtlImage_SetDefaultShading32_CCD();
			break;
	}
	if(!bRet) return False;

	//Wolfson AFE OEB set output low
	//CMDASIC_WriteRegisterBit(0x0058,5,1,1);  //GPIO6
	//CMDASIC_WriteRegisterBit(0x0050,5,1,0);  //GPIO6

	return True;
}


int CtlDevice_SetScanMOD(unsigned char iclkpl)
{
   return CMDASIC_WriteRegister(0x0006, iclkpl);
}



int CtlDevice_SetScannerClock(unsigned char iScanClk)
{
   unsigned char bVal;
   unsigned int iVal;

   CtlDevice_PixelTime = (float)Clock_Pixel/iScanClk;

   switch(iScanClk){
      case 24:
		 bVal=0x00;
         break;
      case 30:
		 bVal=0x01;
         break;
      case 40:
		 bVal=0x02;
         break;
      case 48:
		 bVal=0x03;
         break;
      case 60:
		 bVal=0x04;
         break;
      case 80:
		 bVal=0x09;
         break;
      case 96:
		 bVal=0x0a;
         break;
      case 120:
		 bVal=0x0b;
         break;
      default:
         bVal=0x01;
         break;
   }

   if (!CMDASIC_WriteRegisterBit(0x0004,0,4,bVal))
	   return False;

   switch(iScanClk){
      case 24:
 	     iVal=0x00000022;
         break;
      case 30:
		 iVal=0x01111122;
         break;
      case 40:
		 iVal=0x02222222;
         break;
      case 48:
		 iVal=0x03333322;
         break;
      case 60:
		 iVal=0x04444422;
         break;
      case 80:
		 iVal=0x09999922;
         break;
      case 96:
		 iVal=0x0aaaaa22;
         break;
      case 120:
		 iVal=0x0bbbbb22;
         break;
      default:
         iVal=0x01111122;
         break;
   }

   return True; 
   //return CMDASIC_WriteBus(0xa0000054, iVal);
   
}

int CtlDevice_OpPanelKey(void)
{
//HL modify
#if 0
	unsigned char nCANCEL, nMODE, nDUPLEX, nScan;
	unsigned int nVal_LED, nDir_LED;
	int STOP = 1;
	
	do{
		CMDASIC_ReadRegister(0x0050, &nCANCEL); //GPIO8 CANCEL Reg50b'7

		CMDASIC_ReadRegister(0x0051, &nMODE); //GPIO9 MODE Reg51b'0

		CMDASIC_ReadRegister(0x0054, &nDUPLEX); //GPIO38 DUPLEX Reg54b'5

		CMDASIC_ReadRegister(0x0054, &nScan); //GPIO39 DUPLEX Reg54b'6
		
		if((!(nCANCEL & 0x80)) || (!(nMODE & 0x01)) || (!(nDUPLEX & 0x20)) || (!(nScan & 0x40)))
		{
			printf("......Hit DUPLEX BUTTON!! \n");

			CMDASIC_ReadBus(0xa0000058, &nVal_LED);
			CMDASIC_ReadBus(0xa000005c, &nDir_LED);

			CMDASIC_WriteBus(0xa0000058, (nVal_LED | 0x00000040)); //Set GPIO77 =1 
			CMDASIC_WriteBus(0xa000005c, (nDir_LED | 0x00000040)); //Set GPIO77 = output

			//CMDASIC_ReadBus(0xa0000058, &nVal_LED);
			//CMDASIC_ReadBus(0xa000005c, &nDir_LED);

			//nVal_LED=nVal_LED&0x40;
			//nVal_LED=nVal_LED/0x40;
			STOP = 0;
		}
	}while(STOP);
#endif	
	return True;
}

