////////////////////////////////////////////////////////////////
// File - giimage.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "giasiccontrol.h"

unsigned int mem_bank_range;  
unsigned int shd_full_range; 
unsigned int shd_bank_address[10]; 

unsigned int memuse_start = 0x00600000; //0x02000000;
unsigned int memuse_size = 0x03a00000;  //0x02000000;

unsigned int DualOffset;
unsigned int Jpeg_stradr, Jpeg_endadr;
unsigned int Jpeg_stradr_B, Jpeg_endadr_B;

unsigned int Jpg_thumb_size = 0x00300000;
unsigned int Jpg_thumb_YCbCr_size = 0x000a0000;
unsigned int Jpeg_thumb_scale_xy = 0x00080008;
unsigned int Jpeg_thumb_ymax = 0x00000258;

unsigned int Jpeg_thumb_str, Jpeg_thumb_end;
unsigned int Jpeg_thumb_ystr, Jpeg_thumb_cbstr, Jpeg_thumb_crstr;
unsigned int Jpeg_thumb_str_B, Jpeg_thumb_end_B;

extern unsigned int m_w01SlopeTblAddr, m_w02SlopeTblAddr, m_w03SlopeTblAddr, m_w04SlopeTblAddr, m_w05SlopeTblAddr;


int CtlImage_ClrCounter(void)
{
	return CMDASIC_WriteFourRegister(0x000c,0x00000700);
}

int CtlImage_EnablePattern(unsigned char bEn)
{
	if (bEn==0)
		return CMDASIC_WriteRegisterBit(0x0005,0,3,0);

	if (bEn==1) {
		//pixelcount
		CMDASIC_WriteRegisterBit(0x0308,0,4,8); 
		CMDASIC_WriteRegister(0x0309,0x00); 
		return CMDASIC_WriteRegisterBit(0x0005,0,3,2);
	} else {
		//linecount
		CMDASIC_WriteRegisterBit(0x0308,0,4,8);
		CMDASIC_WriteRegister(0x0309,0x00); 
		return CMDASIC_WriteRegisterBit(0x0005,0,3,3);
	}


	//BENG pattern set
	//****pixelcount
	//CMDASIC_WriteRegisterBit(0x0908,0,4,8); 
	//CMDASIC_WriteRegister(0x0909,0x00); 
	//CMDASIC_WriteRegisterBit(0x0605,0,3,2);
	//****linecount
	//CMDASIC_WriteRegisterBit(0x0908,0,4,8);
	//CMDASIC_WriteRegister(0x0909,0x00); 
	//CMDASIC_WriteRegisterBit(0x0605,0,3,3);

}



int CtlImage_EnableScan(unsigned char bEnable)
{
   return CMDASIC_WriteRegisterBit(0x0001,0,1,bEnable);
}


int CtlImage_EnableASICWatchDog(unsigned char bEn)
{
	return CMDASIC_WriteRegisterBit(0x001b,7,1,bEn);
}
   

int CtlImage_SetASICWatchTime(unsigned int sec)  //sec need <=900
{
	unsigned char nVal;
	if (sec<=450) {
		nVal = (unsigned char)(sec/30);
		CMDASIC_WriteRegisterBit(0x001b,6,1,0);
	} else {
		nVal = (unsigned char)(sec/60);
		CMDASIC_WriteRegisterBit(0x001b,6,1,1);
	}
	return CMDASIC_WriteRegisterBit(0x001b,0,4,nVal);
}




int CtlImage_SetColorDepth(int iPixelBits, unsigned char Channel)
{
	int bRet=1;
	unsigned char LineArt,BitSet,Filter;
	switch(iPixelBits) {

		case 24:  // color 8 bit 
			LineArt=0;
			BitSet=0;
			Filter=0;
			break;
		case 48:  // color 16 bit 
			LineArt=0;
			BitSet=1;
			Filter=0;
			break;
		case 8:  // gray 8 bit 
			LineArt=0;
			BitSet=0;
			switch(Channel){
				case CHANNEL_RED:
					Filter=1;
					break;
				case CHANNEL_GREEN:
					Filter=2;
					break;
				case CHANNEL_BLUE:
					Filter=3;
					break;
				case CHANNEL_TRUE_CISLED:
					Filter=1;
					break;
				case CHANNEL_TRUE_Matrix:
					Filter=0;
					break;
			}
			break;
		case 16:  // gray 16 bit
			LineArt=0;
			BitSet=1;
			switch(Channel){
				case CHANNEL_RED:
					Filter=1;
					break;
				case CHANNEL_GREEN:
					Filter=2;
					break;
				case CHANNEL_BLUE:
					Filter=3;
					break;
				case CHANNEL_TRUE_CISLED:
					Filter=1;
					break;
				case CHANNEL_TRUE_Matrix:
					Filter=0;
					break;
			}
			break;

		default:   // line art  1 or 3
			LineArt=1;
			BitSet=0;
			//Filter=0;
			switch(Channel){
				case CHANNEL_RED:
					Filter=1;
					break;
				case CHANNEL_GREEN:
					Filter=2;
					break;
				case CHANNEL_BLUE:
					Filter=3;
					break;
				case CHANNEL_TRUE_CISLED:
					Filter=1;
					break;
				case CHANNEL_TRUE_Matrix:
					Filter=0;
					break;
			}
			break;

	}

	CMDASIC_WriteRegisterBit(0x0001,4,1,LineArt); //LINEART
	CMDASIC_WriteRegisterBit(0x0003,7,1,BitSet); //BITSET
	CMDASIC_WriteRegisterBit(0x0004,4,2,Filter); //FILETER

	return True;
}



int CtlImage_RamSet_ShadingBank()
{
	int GrayN = ((Sensor_type==2) ? 3 : 1);         // 1CH_3CH mode GrayN=1,  CCD GrayN=3  
	int shd_bank_num = ((Sensor_type==2) ? 1 : 3);  // 1CH_3CH mode shd_bank_num=3,  CCD shd_bank_num=1 
	int pixels = MAX_PIXELES_PER_LINE;
	unsigned int shd_onebank_range; // every bank range
	unsigned int shd_bank_reg[10]; 
	int i;

	//// one pixel one GrayN use 2 WORD memory (White,Dark)
	//shd_onebank_range= (unsigned int)(pixels*4*GrayN);
	// one pixel one GrayN use 1 WORD memory (White,Dark)
	shd_onebank_range= (unsigned int)(pixels*2*GrayN);

	shd_onebank_range = (shd_onebank_range/1024+1)*1024;
	shd_full_range = shd_onebank_range * shd_bank_num;
	
	for (i=0; i<shd_bank_num; i++) {
		if (i==0)
			shd_bank_reg[0] = memuse_start + 0xa0000;
		else
			shd_bank_reg[i] = shd_bank_reg[i-1] + shd_onebank_range;
	}

	for (i=0; i<shd_bank_num; i++) {
		CMDASIC_WriteFourRegister((unsigned short)(0x02AC+i*4),shd_bank_reg[i]);
		shd_bank_address[i] = shd_bank_reg[i];
	}

	//CMDASIC_WriteFourRegister(0x0150, memuse_start); //MOTOR_TABLE_ADD
	//motor table use from (memuse_start) to (memuse_start+0xa0000), total 5 tables
	CMDASIC_WriteFourRegister(0x0150, memuse_start); //MOTOR_TABLE_ADD
	m_w01SlopeTblAddr = memuse_start, 
	m_w02SlopeTblAddr = memuse_start+0x20000, 
	m_w03SlopeTblAddr = memuse_start+0x40000, 
	m_w04SlopeTblAddr = memuse_start+0x60000, 
	m_w05SlopeTblAddr = memuse_start+0x80000;

	return True;

}



int CtlImage_RamSet_ImageBuffer(ScanParameter *pSPM)
{
	unsigned int mem_bank_reg[12];  //unit = 1K WORD
	int i;
	unsigned int channel_byte;
	unsigned int bufline, maxline, minline, linediff;
	unsigned int m_channel_byte;
	int SEG_EN, CCDmode;   
	unsigned char scale;

	if ((pSPM->spPixelResolution == 150) || (pSPM->spPixelResolution == 100) || (pSPM->spPixelResolution == 75) )
		scale = 300 / pSPM->spPixelResolution;
	else
		scale = 1;

	switch(Sensor_type){
		case 0:  //1CH CIS
			SEG_EN=0; CCDmode=0;
			break;
		case 1:  //3CH CIS
			SEG_EN=1; CCDmode=0;
			break;
		case 2:  //CCD
			CCDmode=1,SEG_EN=0;
			break;
	}

	//m_channel_byte = (unsigned int)pSPM->spScanLinePixels * pSPM->spPixelDepth / 8;
	m_channel_byte = (unsigned int)pSPM->spScanLinePixels * ((pSPM->spPixelDepth==1) ? 8:pSPM->spPixelDepth) / 8;

	channel_byte = (m_channel_byte%512)==0 ? m_channel_byte : (m_channel_byte/512+1)*512 ;

	DualOffset = pSPM->spDualscan ? (memuse_size - 0xa0000)/2 : 0x00000000;

	linediff = CMDASIC_RegTable[0x020E].nValue;

	if((pSPM->spJPEGENC&0x0f)!=0) {  //jpg

		if( (pSPM->spCCDPacking==1 ) && (pSPM->spImageType == IMAGE_COLOR) && (Sensor_type==2) ) {
			maxline = linediff*2+1;
			bufline = ((maxline*2) /8 + 1) * 8;
			maxline = bufline - maxline;
		} else {
			bufline = 16;
			maxline = bufline-2;
		}

		Jpeg_stradr = memuse_start + 0xa0000 + shd_full_range + channel_byte * bufline * ((pSPM->spImageType == IMAGE_COLOR) ? 3:1);

	} else { //raw

		bufline = ((memuse_size - 0xa0000) / (pSPM->spDualscan ? 2:1) - shd_full_range) / channel_byte / ( (pSPM->spImageType == IMAGE_COLOR) ? 3:1);
		bufline = bufline /8 *8;

		if( (pSPM->spCCDPacking==1 ) && (pSPM->spImageType == IMAGE_COLOR) && (Sensor_type==2) )
			maxline = bufline-(linediff*2+1);
		else
			maxline = bufline-2;

		Jpeg_stradr = 0x00000000;
	}
	minline=8;




	//CIS segment mode =1
	if ((SEG_EN==1) && (CCDmode==0)) {
		
		unsigned short TG0Cnt; 
		unsigned short SEGCNT; 
		unsigned int ValidImage; 
		unsigned int STRPIXEL, ENDPIXEL;
		unsigned int Cis1_Seg, Cis2_Seg, Cis3_Seg;
		unsigned int curpxl, wpxls;
		unsigned int Off1seg, Off2seg;
#if 0
		switch(pSPM->spTimingIdx){
			case 1: //2400dpi  //�ЫO�d��ۭq��SEGCNT & ValidImage & TG0Cnt
				SEGCNT=864; ValidImage=864; TG0Cnt=19;
				break;
			case 2: //1200dpi  //�ЫO�d��ۭq��SEGCNT & ValidImage & TG0Cnt
				SEGCNT=864*4; ValidImage=864*4; TG0Cnt=19;
				break;
			case 4: //600dpi   //�ЫO�d��ۭq��SEGCNT & ValidImage & TG0Cnt
				SEGCNT=864*2; ValidImage=864*2; TG0Cnt=85;
				break;
			case 8: //300dpi   //�ЫO�d��ۭq��SEGCNT & ValidImage & TG0Cnt
				SEGCNT=864; ValidImage=864; TG0Cnt=85;
				break;
			default:
				break;
		}
#else
		switch(pSPM->spTimingIdx){
			case 1: //2400dpi
				SEGCNT=860; ValidImage=860; TG0Cnt=19;
				break;
			case 2: //1200dpi
				SEGCNT=864*4; ValidImage=864*4; TG0Cnt=78+1;
				break;
			case 4: //600dpi
				SEGCNT=864*2; ValidImage=864*2; TG0Cnt=81;
				break;
			case 8: //300dpi
				SEGCNT=864; ValidImage=864; TG0Cnt=78+6;
				break;
			default:
				SEGCNT=864; ValidImage=864; TG0Cnt=78+6;
				break;
		}
#endif
		STRPIXEL = pSPM->spScanBeginPixel; 
		ENDPIXEL = pSPM->spScanBeginPixel+pSPM->spScanLinePixels; 

		//PSCALE_X
		if ( (pSPM->spPixelResolution == 200) || (pSPM->spPixelResolution == 400) ){
			SEGCNT = SEGCNT / 3 * 2;
			ValidImage = ValidImage / 3 * 2;
		} else {
			SEGCNT /= scale;
			ValidImage /= scale;
		}

		curpxl=STRPIXEL, wpxls = ENDPIXEL-STRPIXEL;
		/////////// auto create Cis1/2/3_Seg
		Cis1_Seg = (SEGCNT > curpxl) ? (SEGCNT-curpxl) : 0 ;
		if (wpxls <= Cis1_Seg) {			
			Cis1_Seg = wpxls;
			Cis2_Seg = 0;
			Cis3_Seg = 0;
		} else {
			curpxl += Cis1_Seg;
			wpxls -= Cis1_Seg;
			Cis2_Seg = (SEGCNT*2 > curpxl) ? (SEGCNT*2-curpxl) : 0 ;
			if (wpxls <= Cis2_Seg) {
				Cis2_Seg = wpxls;
				Cis3_Seg = 0;
			} else {
				Cis3_Seg = ENDPIXEL-STRPIXEL-Cis1_Seg-Cis2_Seg;
			}
		}

		/////////// calculate image buffer
		//if (CMDASIC_RegTable[0x0003].nValue & 0x80) {  //16bit *2
		if(pSPM->spPixelDepth == 16) {
			Cis1_Seg *=2;		Cis2_Seg *=2;		Cis3_Seg *=2;
		}

		Off1seg = Cis1_Seg;
		Off1seg = (Off1seg%512)==0 ? Off1seg : (Off1seg/512+1)*512 ;

		Off2seg = Cis1_Seg + Cis2_Seg;
		Off2seg = (Off2seg%512)==0 ? Off2seg : (Off2seg/512+1)*512 ;

		if (pSPM->spImageType == IMAGE_COLOR) {
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<12; i=i+4) { 
				if (i==0) {
					mem_bank_reg[0] = memuse_start + 0xa0000 + shd_full_range;
					mem_bank_reg[1] = mem_bank_reg[0] + mem_bank_range;
					mem_bank_reg[2] = mem_bank_reg[0] + Off1seg + channel_byte*(bufline-1);
					mem_bank_reg[3] = mem_bank_reg[0] + Off2seg + channel_byte*(bufline-1);
				} else {
					mem_bank_reg[i] = mem_bank_reg[i-4] + mem_bank_range;
					mem_bank_reg[i+1] = mem_bank_reg[i+1-4] + mem_bank_range;
					mem_bank_reg[i+2] = mem_bank_reg[i+2-4] + mem_bank_range;
					mem_bank_reg[i+3] = mem_bank_reg[i+3-4] + mem_bank_range;
				}
			}
			CMDASIC_WriteRegister(0x02a1,0x04);     //MINSEL

		} else { //IMAGE_GRAY
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<3; i++) { 
				mem_bank_reg[0+i*4] = memuse_start + 0xa0000 + shd_full_range;
				mem_bank_reg[1+i*4] = mem_bank_reg[0+i*4]  + mem_bank_range;
				mem_bank_reg[2+i*4] = mem_bank_reg[0+i*4] + Off1seg + channel_byte*(bufline-1);
				mem_bank_reg[3+i*4] = mem_bank_reg[0+i*4] + Off2seg + channel_byte*(bufline-1);
			}
			CMDASIC_WriteRegister(0x02a1,0x00);     //MINSEL
		}

		for (i=0; i<12; i++) {
			CMDASIC_WriteFourRegister((unsigned short)(0x02cc+i*4), mem_bank_reg[i]);
		}

		//PSCALE_X
		if ( (pSPM->spPixelResolution == 200) || (pSPM->spPixelResolution == 400) ){
			SEGCNT = SEGCNT * 3 / 2;
			ValidImage = ValidImage * 3 / 2;
			STRPIXEL = STRPIXEL * 3 / 2;
			ENDPIXEL = ENDPIXEL * 3 / 2;
			CMDASIC_WriteRegisterBit(0x000B,5,1,1);  //PSCALE_X
			CMDASIC_WriteTwiRegister(0x0208, 2400);  //DPISET, �g�JCCD_DPIHW�ۦP����
		} else {
			SEGCNT *= scale;
			ValidImage *= scale;
			STRPIXEL *= scale;
			ENDPIXEL *= scale;
		}

		CMDASIC_WriteRegisterBit(0x0001,3,1,1);  //SEG_EN
		CMDASIC_WriteRegisterBit(0x000a,4,3,5);  //PINORDER, CIS_2H, CIS_3H (bit 6, 5, 4)
		CMDASIC_WriteRegisterBit(0x0001,5,3,5);  //CISSET, CIS_LINE, CISPIXEL (bit 7, 6, 5)  //CIS_LINE = shading bank index type
		CMDASIC_WriteFourRegister(0x0220, ValidImage);  //VALIDIMAGE
		CMDASIC_WriteFourRegister(0x0224, SEGCNT);  //SEGCNT
		CMDASIC_WriteTwiRegister(0x0228, TG0Cnt);  //TG0CNT
		CMDASIC_WriteRegister(0x022a, 1);  //SEGNO
		CMDASIC_WriteFourRegister(0x0214,STRPIXEL);  //STRPIXEL
		CMDASIC_WriteFourRegister(0x0218,ENDPIXEL);  //ENDPIXEL
		CMDASIC_WriteFourRegister(0x02fc,Cis1_Seg);  //CIS1_SEG
		CMDASIC_WriteFourRegister(0x0300,Cis2_Seg);  //CIS2_SEG
		CMDASIC_WriteFourRegister(0x0304,Cis3_Seg);  //CIS3_SEG
		CMDASIC_WriteRegisterBit(0x0000,1,1,0);  //shad_one_ch
		CMDASIC_WriteRegisterBit(0x000b,0,1,0);  //LINEOUT
		CMDASIC_WriteRegisterBit(0x0000,2,1,1);  //shad_bk_idx  //=0, only use Red Shading, =1, use R/G/B by filter(3 shading)
		CMDASIC_WriteRegisterBit(0x000a,3,1,1); //gmm_para
		CMDASIC_WriteRegisterBit(0x006a,0,3,5);  //CIS_LED=1, SSLEDEN=1
		CMDASIC_WriteRegisterBit(0x0003,4,1,1);  //LAMPPWR
		
		CMDASIC_WriteFourRegister(0x02a4,maxline);  //MAXLINE
		CMDASIC_WriteFourRegister(0x02a8,minline);  //MINLINE

	}


	//CIS segment mode=0
	if ((SEG_EN==0) && (CCDmode==0)) {
		  
		if (pSPM->spImageType == IMAGE_COLOR) {
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<12; i=i+4) { 
				if (i==0) {
					mem_bank_reg[i] = memuse_start + 0xa0000 + shd_full_range;
					mem_bank_reg[i+2] = mem_bank_reg[i] + mem_bank_range;
					mem_bank_reg[i+1] = mem_bank_reg[i+2];
					mem_bank_reg[i+3] = mem_bank_reg[i+2];
 				} else {
					mem_bank_reg[i] = mem_bank_reg[i-1]; 
					mem_bank_reg[i+2] = mem_bank_reg[i] + mem_bank_range;
					mem_bank_reg[i+1] = mem_bank_reg[i+2];
					mem_bank_reg[i+3] = mem_bank_reg[i+2];
				}
			}
			CMDASIC_WriteRegister(0x02a1,0x04);     //MINSEL

		} else { //IMAGE_GRAY
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<3; i++) { 
				mem_bank_reg[0+i*4] = memuse_start + 0xa0000 + shd_full_range;
				mem_bank_reg[2+i*4] = mem_bank_reg[0+i*4] + mem_bank_range;
				mem_bank_reg[1+i*4] = mem_bank_reg[2+i*4];
				mem_bank_reg[3+i*4] = mem_bank_reg[2+i*4];
			}
			CMDASIC_WriteRegister(0x02a1,0x00);     //MINSEL
		}

		for (i=0; i<12; i++) {
			CMDASIC_WriteFourRegister((unsigned short)(0x02cc+i*4), mem_bank_reg[i]);
		}
		CMDASIC_WriteRegisterBit(0x0001,3,1,0);  //SEG_EN
		CMDASIC_WriteRegisterBit(0x000a,4,3,0);  //PINORDER, CIS_2H, CIS_3H (bit 6, 5, 4)
		CMDASIC_WriteRegisterBit(0x0001,5,3,5);  //CISSET, CIS_LINE, CISPIXEL (bit 7, 6, 5)  //CIS_LINE = shading bank index type
		CMDASIC_WriteFourRegister(0x02fc,m_channel_byte);  //CIS1_SEG
		CMDASIC_WriteFourRegister(0x0300,0x00000000);      //CIS2_SEG
		CMDASIC_WriteFourRegister(0x0304,0x00000000);      //CIS3_SEG
		CMDASIC_WriteRegisterBit(0x0000,1,1,1);  //shad_one_ch
		CMDASIC_WriteRegisterBit(0x000b,0,1,0);  //LINEOUT
		CMDASIC_WriteRegisterBit(0x0000,2,1,1);  //shad_bk_idx  //=0, only use Red Shading, =1, use R/G/B by filter(3 shading)
		CMDASIC_WriteRegisterBit(0x000a,3,1,0);  //gmm_para
		CMDASIC_WriteRegisterBit(0x006a,0,3,5);  //CIS_LED=1, SSLEDEN=1
		CMDASIC_WriteRegisterBit(0x0003,4,1,1);  //LAMPPWR

		CMDASIC_WriteFourRegister(0x02a4,maxline);  //MAXLINE
		CMDASIC_WriteFourRegister(0x02a8,minline);  //MINLINE

	}

	//CCDmode
	if (CCDmode==1) {
		if (pSPM->spImageType == IMAGE_COLOR) {
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<12; i=i+4) { 
				if (i==0) {
					mem_bank_reg[i] = memuse_start + 0xa0000 + shd_full_range;
					mem_bank_reg[i+1] = mem_bank_reg[i] + mem_bank_range;
					mem_bank_reg[i+2] = mem_bank_reg[i];
					mem_bank_reg[i+3] = mem_bank_reg[i+1];
				} else {
					mem_bank_reg[i] = mem_bank_reg[i-1];
					mem_bank_reg[i+1] = mem_bank_reg[i] + mem_bank_range;
					mem_bank_reg[i+2] = mem_bank_reg[i];
					mem_bank_reg[i+3] = mem_bank_reg[i+1];
				}
			}
			if (CMDASIC_RegTable[0x020C].nValue & 0x01)
				CMDASIC_WriteRegister(0x02a1,0x00);     //MINSEL
			else
				CMDASIC_WriteRegister(0x02a1,0x04);     //MINSEL
	
		} else { //IMAGE_GRAY
			mem_bank_range = bufline * channel_byte;
			for (i=0; i<3; i++) { 
				mem_bank_reg[0+i*4] = memuse_start + 0xa0000 + shd_full_range;
				mem_bank_reg[1+i*4] = mem_bank_reg[0+i*4] + mem_bank_range;
				mem_bank_reg[2+i*4] = mem_bank_reg[0+i*4];
				mem_bank_reg[3+i*4] = mem_bank_reg[1+i*4];
			}
			CMDASIC_WriteRegister(0x02a1,0x04);     //MINSEL
		}
		for (i=0; i<12; i++) {
			CMDASIC_WriteFourRegister((unsigned short)(0x02cc+i*4), mem_bank_reg[i]);
		}
		CMDASIC_WriteFourRegister(0x02fc,m_channel_byte);  //CIS1_SEG
		CMDASIC_WriteFourRegister(0x0300,0x00000000);      //CIS2_SEG
		CMDASIC_WriteFourRegister(0x0304,0x00000000);      //CIS3_SEG
		CMDASIC_WriteRegisterBit(0x0003,4,1,1);  //LAMPPWR

		CMDASIC_WriteFourRegister(0x02a4,maxline);  //MAXLINE
		CMDASIC_WriteFourRegister(0x02a8,minline);  //MINLINE

	}

	return True;

}






/////////////////////////////////////////////////////////////////
// 8/24 bit scan always CMatrix=1, 16/48 bit scan CMatrix=0 or 1 (bypass or enable)
// CMartix: 0x0200 = gain 1
// use for GL310-3
//	8/24 bit scan�@�w�n�Ұ�,�p�G�Q�nbypass�N�]matrix �t�Ʀp�U(�﨤�t�Ƭ�1.0,�䥦��0.0)
//	0x2000���@��,�ҥH�t�Ʀb -4 ~ +4 ����.
//	16/48 scan���@�w�n�Ұ�, 0x8000���@��, �t�Ʀb -1 ~ +1 ����.
/////////////////////////////////////////////////////////////////
int CtlImage_CMatrix_Default(ScanParameter *pSPM) 
{
	int k;
#if 1
	float f_R[3]={1.0f, 0.0f, 0.0f};
	float f_G[3]={0.0f, 1.0f, 0.0f};
	float f_B[3]={0.0f, 0.0f, 1.0f};
#else
	float f_R[3]={1.16084f, -0.000f, -0.00f};
	float f_G[3]={-0.0f, 1.167f, -0.0f};
	float f_B[3]={-0.00f, -0.0f, 1.1603f};//1.19
#endif
	signed short Mtr_R[3]={0x2000,0x2000,0x2000};
	signed short Mtr_G[3]={0x2000,0x2000,0x2000};
	signed short Mtr_B[3]={0x2000,0x2000,0x2000};

	for(k=0; k<3; k++) {
		Mtr_R[k] = (signed short)((float)0x2000 * f_R[k]);
		Mtr_G[k] = (signed short)((float)0x2000 * f_G[k]);
		Mtr_B[k] = (signed short)((float)0x2000 * f_B[k]);
	}

	//CMDASIC_WriteRegisterBit(0x0000,0,1, ((pSPM->spPixelDepth == 8) ? 1 : 0 ) );  //CMatrix
	if( (pSPM->spPixelDepth == 8)||(pSPM->spPixelDepth == 1) )
		CMDASIC_WriteRegisterBit(0x0000,0,1,1);  //CMatrix

	for(k=0; k<3; k++) {
		CMDASIC_WriteTwiRegister(0x0330+k*2, Mtr_R[k]);
	}
	for(k=0; k<3; k++) {
		CMDASIC_WriteTwiRegister(0x0338+k*2, Mtr_G[k]);
	}
	for(k=0; k<3; k++) {
		CMDASIC_WriteTwiRegister(0x0340+k*2, Mtr_B[k]);
	}

	return True;

}


int CtlImage_TrueGray_CISLED(ScanParameter *pSPM) 
{
	//for example: LED True Gray  R:G:B = 3:6:1
	//original Color : Lperiod=0.14ms, LedR=0.8ms, LedG=0.9ms LedB=1.1ms
	//LED True Gray:   Lperiod=0.14ms, 
	//                 LedR = 0.8 * 0.1 ms
	//                 LedG = LedR + 0.9 * 0.6 ms
	//                 LedB = LedG + 1.1 * 0.3 ms
	//set weight LedR/G/B to scanparameter

	//CMDASIC_WriteRegisterBit(0x0004,4,2,1); //FILETER
	CMDASIC_WriteRegisterBit(0x0001,2,1,0);  //TRUEGRAY
	CMDASIC_WriteRegisterBit(0x0008,5,1,1);  //LEDADD

	return True;
}



int CtlImage_TrueGray_Matrix(ScanParameter *pSPM) 
{
	int k;
	//for Gray  R:G:B = 3:6:1
	float f_R[3]={0.3f, 0.6f, 0.1f};
	signed short Mtr_R[3];
	CMDASIC_WriteRegisterBit(0x0001,2,1,1);  //TRUEGRAY
	CMDASIC_WriteRegisterBit(0x0000,0,1,1);  //CMatrix
	CMDASIC_WriteRegisterBit(0x0008,5,1,0);  //LEDADD
	for(k=0; k<3; k++) {
		Mtr_R[k] = (signed short)((float) (((pSPM->spPixelDepth == 8)||(pSPM->spPixelDepth == 1)) ? 0x2000:0x8000) * f_R[k]);
	}
	for(k=0; k<3; k++) {
		CMDASIC_WriteTwiRegister(0x0330+k*2, (unsigned short)Mtr_R[k]);
	}

	return True;

}


/*
//hardware packing CCD image test
int CCD_packing_test() 
{
	CMDASIC_WriteRegisterBit(0x0009, 5, 1, 0); //Even1st
	CMDASIC_WriteRegisterBit(0x0009, 4, 1, 1); //BLINE1st
	CMDASIC_WriteRegisterBit(0x0011, 0, 6, 2); //LNOFSET
	CMDASIC_WriteRegisterBit(0x0012, 0, 5, 0); //STGSET
	CMDASIC_WriteRegister(0xf8,0x50);
	//CMDASIC_WriteTriRegister(0x25,	 ( ((unsigned int)(CMDASIC_RegTable[0x25].nValue) & (0x0f)) << 16) +
	//				((unsigned int)(CMDASIC_RegTable[0x26].nValue) << 8) +
	//				(unsigned int)(CMDASIC_RegTable[0x27].nValue) + 5 ) ;
	return True;
}
*/


/*
//test CONV_ENB
//�u��J5�Өt��.
//�t��1~4�������� -1 ~ +1����, 0x8000���@��,
//�t��5�L���� 0 ~ +2����,���i���t��.
int CONV_ENB_test() {
	int k;
	//���]�t�� 0 0 -0.1 -0.1 1.4 -0.1 -0.1 0 0 (9�Өt���`�M1.0)
	float f_R[5]= {0.0f, 0.0f, -0.1f, -0.1f, 1.4f};
	float f_G[5]= {0.0f, 0.0f, -0.1f, -0.1f, 1.4f};;
	float f_B[5]= {0.0f, 0.0f, -0.1f, -0.1f, 1.4f};

	signed short Coef_R[5]={0,0,0,0,32767};
	signed short Coef_G[5]={0,0,0,0,32767};
	signed short Coef_B[5]={0,0,0,0,32767};

	for(k=0; k<5; k++) {
		Coef_R [k] = (signed short)((float)0x8000 * f_R[k]);
		Coef_G [k] = (signed short)((float)0x8000 * f_G[k]);
		Coef_B [k] = (signed short)((float)0x8000 * f_B[k]);
	}

	for(k=0; k<5; k++) {
		CMDASIC_WriteTwiRegister(0x030c+k*2, Coef_R[k]);
		CMDASIC_WriteTwiRegister(0x0318+k*2, Coef_G[k]);
		CMDASIC_WriteTwiRegister(0x0324+k*2, Coef_B[k]);
	}
	CMDASIC_WriteRegisterBit(0x0009,3,1,1);  //CONV_ENB

	return True;
}
*/

