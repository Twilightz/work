#ifndef _USERCONFIG_H_
#define _USERCONFIG_H_

#include "sysConfig.h"


#define		_EI2		1							

BOOL usrConfig_initialize(void);

#endif 

