#include "def.h"
#include "spi_fun.h"
#include "macroutil.h"

UINT8 *gTmp;
UINT8 *xTmp;
UINT8 *gData;
	

const UINT8 cbFLH_RDSR  = 0x05;
const UINT8 cbFLH_RDSR2 = 0x35;
const UINT8 cbFLH_RDSR3 = 0x15;
const UINT8 cbFLH_WRSR  = 0x01;
const UINT8 cbFLH_WRSR2 = 0x31;
const UINT8 cbFLH_WRSR3 = 0x11;

const UINT8 cbFLH_WREN  = 0x06;
const UINT8 cbFLH_WRDI  = 0x04;

const UINT8 cbFLH_CR	= 0x3F;
const UINT8 cbFLH_CW	= 0x3E;


const UINT8 cbFLH_BE	= 0x20;
const UINT8 cbFLH_CE	= 0x60;
const UINT8 cbFLH_RDID  = 0x90;
const UINT8 cbFLH_RDIDX  = 0x9F;
const UINT8 cbFLH_RESET  = 0x99;
const UINT8 cbFLH_RESETEN  = 0x66;
const UINT8 cbFLH_EXITQ  = 0xFF;

const UINT8 cbFLH_PWR_DOWN  = 0xB9;
const UINT8 cbFLH_PWR_UP  = 0xAB;

void (*SpiIDQuadFun[noSFlashType])(UINT8 fun, Spi_Str *spistr);
void SPIC_WRITE_FUNC(Spi_Str *spistr);





//=============================
// = QUAD Bit function Mxic
//=============================
void Mxic_Quad_Fun(UINT8 fun, Spi_Str *spistr)
{
 
 	 
 	Spi_Str SpiStrTmp;
 	SpiStrTmp.Interface   = spistr->Interface;
   	SpiStrTmp.Intf_Ch	  = spistr->Intf_Ch; 
  
 	if(fun){
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
    
    
    	*xTmp |= bmQuad_MXIC;
    
    
    	SpiStrTmp.CmdPtr   = &cbFLH_WRSR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
 	
 		
 	}
 	else{
 		
 
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
    
    
    	*xTmp &= ~bmQuad_MXIC;
    
    
    	SpiStrTmp.CmdPtr   = &cbFLH_WRSR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
 	}
  
 	 
 }

 
//============================
//= QUAD Bit Function Winbond
//============================
void WinB_Quad_Fun(UINT8 fun, Spi_Str *spistr)
{
 
 
  	Spi_Str SpiStrTmp;
   	SpiStrTmp.Interface   = spistr->Interface;
   	SpiStrTmp.Intf_Ch	  = spistr->Intf_Ch;
  
 	if(fun){
 	 
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    	SpiStrTmp.CmdLen   = 1;
       	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
     	
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR2;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = (UINT8 *)(xTmp + 4);
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
    
   
   
     
    	xTmp[1] = xTmp[4] | 0x2;
    
    
    	SpiStrTmp.CmdPtr   = &cbFLH_WRSR;
    	SpiStrTmp.CmdLen   = 1;
       	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 2;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
    	
 
 	
 		
 	}
 	else{
 		
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    	SpiStrTmp.CmdLen   = 1;
       	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_RDSR2;
    	SpiStrTmp.CmdLen   = 1;
       	SpiStrTmp.rwPtr    = (UINT8 *)(xTmp + 4);
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
    
    
        
    	xTmp[1] = xTmp[4] & 0xFD;
    
    	
    
    	SpiStrTmp.CmdPtr   = &cbFLH_WRSR;
    	SpiStrTmp.CmdLen   = 1;
       	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 2;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
 	}
  
  
 }
 
//============================
//= QUAD Bit function ATMEL
//============================
void ATMEL_Quad_Fun(UINT8 fun, Spi_Str *spistr)
{
 
 	
   
  	Spi_Str SpiStrTmp;
  	SpiStrTmp.Interface   = spistr->Interface;
   	SpiStrTmp.Intf_Ch	  = spistr->Intf_Ch;
   
  
 	if(fun){
 	
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_CR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
 	   
    	
    	*xTmp |= 0x80;
    
    
    	SpiStrTmp.CmdPtr   = &cbFLH_CW;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
    	
 
 	
 		
 	}
 	else{
 		
 	
 		SpiStrTmp.CmdPtr   = &cbFLH_CR;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_READ;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_FUNC(&SpiStrTmp);
 	   
    	
    	*xTmp &= 0x7f;
    
    
    	SpiStrTmp.CmdPtr   = &cbFLH_CW;
    	SpiStrTmp.CmdLen   = 1;
    	SpiStrTmp.rwPtr    = xTmp;
    	SpiStrTmp.rwLen    = 1;
    	SpiStrTmp.Read     = _FLH_WRITE;
    	SpiStrTmp.CheckSum = _NO_CHKSUM;
    	SpiStrTmp.nChannel = 1;
   		SpiStrTmp.mAddrToggle = 0;
   		SpiStrTmp.ndummybit = 0;
   		
    	SPIC_WRITE_FUNC(&SpiStrTmp);
 	}
 }
 
 

 
void setup_Quadbit(Spi_Str *spistr, spicmap *smap)
{
    SPIC_hw_unProctect(smap);
	SpiIDQuadFun[SpiParam->IDType](1, spistr);
	SPIC_hw_Proctect(smap);
}

void clean_Quadbit(Spi_Str *spistr, spicmap *smap)
{
    SPIC_hw_unProctect(smap);
	SpiIDQuadFun[SpiParam->IDType](0, spistr);
	SPIC_hw_Proctect(smap);
}



 


void QuadBitFun_Register()
{
	
	
 	SpiIDQuadFun[0] = Mxic_Quad_Fun;
	SpiIDQuadFun[1] = WinB_Quad_Fun;
	SpiIDQuadFun[2] = ATMEL_Quad_Fun;
	
}



/*==================================================================
  = void SPI_WRITE_FUNC(Spi_Str *spistr)
 ==================================================================*/
void SPIC_WRITE_FUNC(Spi_Str *spistr)
{
  
    Spi_Str  SpiStrTmp;
    
  	SpiStrTmp.Interface   = spistr->Interface;
   	SpiStrTmp.Intf_Ch	  = spistr->Intf_Ch;
  	 
    // Write enable    
    SpiStrTmp.CmdPtr   = &cbFLH_WREN;
    SpiStrTmp.CmdLen   = 1;
    SpiStrTmp.rwPtr    = 0x0;
    SpiStrTmp.rwLen    = 0;
    SpiStrTmp.Read     = _FLH_WRITE;
    SpiStrTmp.CheckSum = _NO_CHKSUM;
    SpiStrTmp.nChannel = 1;
    SpiStrTmp.mAddrToggle = 0;
    SpiStrTmp.ndummybit = 0;
    SPIC_FUNC(&SpiStrTmp);
    
    
    SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    SpiStrTmp.CmdLen   = 1;
    SpiStrTmp.rwPtr    = gTmp;
    SpiStrTmp.rwLen    = 1;
    SpiStrTmp.Read     = _FLH_READ;
    SpiStrTmp.CheckSum = _NO_CHKSUM;
    SpiStrTmp.nChannel = 1;
   	SpiStrTmp.mAddrToggle = 0;
   	SpiStrTmp.ndummybit = 0;
   
	
	do { 
    	SPIC_FUNC(&SpiStrTmp); 
    	      
    } while (*gTmp & bmWIP);

    // Do requested SPI write operation
  
   	SPIC_FUNC(spistr);
   	
    // Check flash status until not busy
    SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    SpiStrTmp.CmdLen   = 1;
    SpiStrTmp.rwPtr    = gTmp;
    SpiStrTmp.rwLen    = 1;
    SpiStrTmp.Read     = _FLH_READ;
    SpiStrTmp.CheckSum = _NO_CHKSUM;
    SpiStrTmp.nChannel = 1;
   	SpiStrTmp.mAddrToggle = 0;
   	SpiStrTmp.ndummybit = 0;
   
	do { 
    	SPIC_FUNC(&SpiStrTmp); 
    	      
    } while (*gTmp & bmWIP);
    

    // Flash write disable
    SpiStrTmp.CmdPtr   = &cbFLH_WRDI;
    SpiStrTmp.CmdLen   = 1;
    SpiStrTmp.rwPtr    = _NULL_PTR;
    SpiStrTmp.rwLen    = 0;
    SpiStrTmp.Read     = _FLH_WRITE;
    SpiStrTmp.CheckSum = _NO_CHKSUM;
    SpiStrTmp.nChannel = 1;
    SpiStrTmp.mAddrToggle = 0;
    SpiStrTmp.ndummybit = 0;
    SPIC_FUNC(&SpiStrTmp);
    
    
    SpiStrTmp.CmdPtr   = &cbFLH_RDSR;
    SpiStrTmp.CmdLen   = 1;
    SpiStrTmp.rwPtr    = gTmp;
    SpiStrTmp.rwLen    = 1;
    SpiStrTmp.Read     = _FLH_READ;
    SpiStrTmp.CheckSum = _NO_CHKSUM;
    SpiStrTmp.nChannel = 1;
   	SpiStrTmp.mAddrToggle = 0;
   	SpiStrTmp.ndummybit = 0;
   
	
	do { 
    	SPIC_FUNC(&SpiStrTmp); 
    	      
    } while (*gTmp & bmWIP);	

 
     
}




/*==================================================================
  = UINT32 SPIC_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen) 
  ==================================================================*/
UINT32 SPIC_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen, spicmap *smap) 
{

	UINT8    CmdBuf[4];
    UINT32  wPageLen;
	Spi_Str  SpiStr;

 
	Spi_WRParam *SpiWRCmd;    
	
	SpiWRCmd = (Spi_WRParam *)&SpiParam->wrf; 
	
	CmdBuf[0] 		   = SpiWRCmd->bCmd;			 
	
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 4;
	SpiStr.Read        = _FLH_WRITE;
	
	SpiStr.nChannel	   = SpiWRCmd->nChannel;
   	SpiStr.mAddrToggle = SpiWRCmd->ToogleBit;
   	SpiStr.ndummybit   = SpiWRCmd->nDummybit; 
   	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
    
   	
   	if(SpiStr.nChannel == 4){
   	
   	    setup_Quadbit(&SpiStr, smap);
   	}
		
	
	while(WriteLen){
	
		
 		wPageLen = (WriteLen > SPIWrPgSize) ? SPIWrPgSize : WriteLen;
		
		
	    CmdBuf[1] = (UINT8 )(StartAddr >> 16);		// SPI StartAddr (H Byte)	
	    CmdBuf[2] = (UINT8 )(StartAddr >> 8);		// SPI StartAddr (M Byte)	
    	CmdBuf[3] =  StartAddr & 0x000000ff;		// SPI StartAddr (L Byte)	
    	

    	// Setup structure for reading
    	
    	SpiStr.rwPtr    = WriteBuf;
    	SpiStr.rwLen    = wPageLen;
     	
     
    	SPIC_WRITE_FUNC(&SpiStr);
    	    	
    	WriteLen		-= wPageLen;
    	StartAddr  		+= wPageLen;
    	WriteBuf	 	+= wPageLen;
    	
	}
     
    if(SpiStr.nChannel == 4)
		clean_Quadbit(&SpiStr, smap);
    
    return SpiStr.CheckSum;	

}


/*==================================================================
  = UINT32 Spi_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen) 
  ==================================================================*/
UINT32 SPIC_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen, spicmap *smap)
{
    UINT8    CmdBuf[4];
    Spi_Str  SpiStr;


 
	Spi_WRParam *SpiWRCmd;    
	
	SpiWRCmd = (Spi_WRParam *)&SpiParam->rdf; 
	
	
	
 	if(SpiWRCmd->nChannel == 4)
  		setup_Quadbit(&SpiStr, smap);
    
    if (ReadLen) {
    
    
     	CmdBuf[0] = SpiWRCmd->bCmd; 
   	
    	CmdBuf[3] = StartAddr & 0x000000ff;				
    	CmdBuf[2] = (UINT8 )(StartAddr >> 8);
    	CmdBuf[1] = (UINT8 )(StartAddr >> 16);
    
    
        // Setup structure for reading
        SpiStr.CmdPtr   = CmdBuf;
        SpiStr.CmdLen   = 4;
        SpiStr.rwPtr    = ReadBuf;
        SpiStr.rwLen    = ReadLen;
        SpiStr.Read     = _FLH_READ;
        SpiStr.CheckSum = 0;
        SpiStr.Interface   = smap->Interface;
   		SpiStr.Intf_Ch	   = smap->Intf_Ch;
   
    	SpiStr.nChannel = SpiWRCmd->nChannel;
    	SpiStr.mAddrToggle = SpiWRCmd->ToogleBit;
    	SpiStr.ndummybit = SpiWRCmd->nDummybit; 
    	
	
        SPIC_FUNC(&SpiStr);
    }
    
    if(SpiWRCmd->nChannel == 4)
    	clean_Quadbit(&SpiStr, smap);
    
    return SpiStr.CheckSum;
    
    
}

void SPIC_hw_unProctect(spicmap *smap)
{
    UINT32 wValue;
    
     // set GPIO85 enable    
    wValue = ReadUINT32(0xA0000068);    
    wValue &= ~(0x8);                    // bit 3                    
    WriteUINT32(0xA0000068, wValue);
    
    // set GPIO85 OE = output
    wValue = ReadUINT32(0xA000005C);    
    wValue |= 0x4000;                    // bit 14 = 1
    WriteUINT32(0xA000005C, wValue);
    
    // set GPIO85 data output 
    wValue = ReadUINT32(0xA0000058);    
    wValue |= 0x4000;                    // bit 14 = 1
    WriteUINT32(0xA0000058, wValue);
    
}

void SPIC_hw_Proctect(spicmap *smap)
{
    
    UINT32 wValue;
    
     // set GPIO85 enable    
    wValue = ReadUINT32(0xA0000068);    
    wValue &= ~(0x8);                    // bit 3                    
    WriteUINT32(0xA0000068, wValue);
    
    // set GPIO85 OE = output
    wValue = ReadUINT32(0xA000005C);    
    wValue |= 0x4000;                    // bit 14 = 1
    WriteUINT32(0xA000005C, wValue);
    
    // set GPIO85 data output 
    wValue = ReadUINT32(0xA0000058);    
    wValue &= ~0x4000;                    // bit 14 = 0
    WriteUINT32(0xA0000058, wValue);
    
}



void SPIC_BlkUnProctect(spicmap *smap)
{
    Spi_Str  SpiStr;

   	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	if(SpiParam->IDType != 1){    	
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    
    	
    	if(SpiParam->IDType == 2)
    		xTmp[0] = 0xC3;             // ATMEL
    	
    	else{    	      
    	    xTmp[0] = 0x80;   
    	}
    	
    
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    }
    else{
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
    	SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    	
    	 
    	SpiStr.CmdPtr   = &cbFLH_RDSR2;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = (UINT8 *)(xTmp +4);
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
    	SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    	
     	
    	 
        // BP0~BP2 all unprotect
 		xTmp[0] = 0x80;             // only SOFTWARE Protect enable, all block unlock
 		//xTmp[1] = xTmp[4];
 		xTmp[1] = 0;                // prevent the LB1~LB3 locker
 		
        
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 2;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    	
    	
    }
   	
    
}

void SPIC_BlkProctect(spicmap *smap)
{
    Spi_Str  SpiStr;

   	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	if(SpiParam->IDType != 1){    	
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    
     	
    	
    	if(SpiParam->IDType == 2)
    		xTmp[0] = 0xBC;
    	else{
    	    xTmp[0] = 0xBC;
    	}
    	
    
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    }
    else{
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
    	SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    	
    	
    	SpiStr.CmdPtr   = &cbFLH_RDSR2;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = (UINT8 *)(xTmp +4);
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface   = smap->Interface;
    	SpiStr.Intf_Ch	   = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    
 	    // BP0~BP2 all protect
 		xTmp[0] = 0x9C;
 		//xTmp[1] = xTmp[4];
 		xTmp[1] = 0;    // prevent the LB1~LB3 locker
        
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 2;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface   = smap->Interface;
   	    SpiStr.Intf_Ch	   = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    	
    }
}

void SPIC_ProctectBits(UINT8 ProtectBits, spicmap *smap)
{
	
    Spi_Str  SpiStr;    
    
   	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
    
    if(SpiParam->IDType != 1){
    	
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface = smap->Interface;
   	    SpiStr.Intf_Ch	 = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    
 
    	if(SpiParam->IDType == 2){
    	    xTmp[0]     &= 0x43;
    	    ProtectBits &= 0xBC;    	    
    	}
    	else{
    	    xTmp[0]     &= 0xC3;
    	    ProtectBits &= 0x3C;
    	}
    	
    	xTmp[0] |= ProtectBits;
    	
    
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface = smap->Interface;
   	    SpiStr.Intf_Ch	 = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    }
    else{
    
    
    	SpiStr.CmdPtr   = &cbFLH_RDSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface = smap->Interface;
    	SpiStr.Intf_Ch	 = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    	
    	SpiStr.CmdPtr   = &cbFLH_RDSR2;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = (UINT8 *)(xTmp +4);
    	SpiStr.rwLen    = 1;
    	SpiStr.Read     = _FLH_READ;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
   		SpiStr.Interface = smap->Interface;
    	SpiStr.Intf_Ch	 = smap->Intf_Ch;
    	SPIC_FUNC(&SpiStr);
    
 		
 		xTmp[0]     &= 0x83;
   	    ProtectBits &= 0x7C;   	    
   	    
 		xTmp[0] |= ProtectBits;
 		
 		xTmp[1] = xTmp[4];
        
  	  	SpiStr.CmdPtr   = &cbFLH_WRSR;
    	SpiStr.CmdLen   = 1;
    	SpiStr.rwPtr    = xTmp;
    	SpiStr.rwLen    = 2;
    	SpiStr.Read     = _FLH_WRITE;
    	SpiStr.CheckSum = _NO_CHKSUM;
    	SpiStr.nChannel = 1;
   		SpiStr.mAddrToggle = 0;
   		SpiStr.ndummybit = 0;
	   	SpiStr.Interface = smap->Interface;
   	    SpiStr.Intf_Ch	 = smap->Intf_Ch;	
    	SPIC_WRITE_FUNC(&SpiStr);
    	
    }
   
}


void SPIC_BE(UINT32 BlockAddr, spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	CmdBuf[3]           = (UINT8)BlockAddr;
	CmdBuf[2]           = (UINT8)(BlockAddr >> 8);
	CmdBuf[1]           = (UINT8)(BlockAddr >> 16);
	CmdBuf[0]           = cbFLH_BE;			 	
		
	
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 4;
	SpiStr.Read        = _FLH_WRITE;
	SpiStr.rwPtr       = 0;
    SpiStr.rwLen       = 0;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_WRITE_FUNC(&SpiStr);
  	
   	
	
}



void SPIC_CE(spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0] = cbFLH_BE;			 		
	
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 1;
	SpiStr.Read        = _FLH_WRITE;
	SpiStr.rwPtr       = 0;
    SpiStr.rwLen       = 0;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_WRITE_FUNC(&SpiStr);
   	
	
}




void SPIC_RDID(UINT8 *VID, UINT8 *PID, spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0]           = cbFLH_RDID;    
    
   	CmdBuf[3]           = 0x0;				
   	CmdBuf[2]           = 0x0;
   	CmdBuf[1]           = 0x0;
    
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 4;
	SpiStr.Read        = _FLH_READ;
	SpiStr.rwPtr       = xTmp;
    SpiStr.rwLen       = 2;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_FUNC(&SpiStr);
   	
   	*VID = xTmp[0];
   	*PID = xTmp[1];
   	
	
}

void SPIC_RDIDX(UINT8 *VID, UINT8 *PID, spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0]           = cbFLH_RDIDX;    
    
   	CmdBuf[3]           = 0x0;				
   	CmdBuf[2]           = 0x0;
   	CmdBuf[1]           = 0x0;
    
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 1;
	SpiStr.Read        = _FLH_READ;
	SpiStr.rwPtr       = xTmp;
    SpiStr.rwLen       = 3;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_FUNC(&SpiStr);
   	
   	*VID = xTmp[0];
   	*PID = xTmp[1];
   	
	
}


void SPIC_RESET(spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0]           = cbFLH_RESET;    
    
   	CmdBuf[3]           = 0x0;				
   	CmdBuf[2]           = 0x0;
   	CmdBuf[1]           = 0x0;
    
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 1;
	SpiStr.Read        = _FLH_WRITE;
	SpiStr.rwPtr       = 0;
    SpiStr.rwLen       = 0;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_FUNC(&SpiStr);
    
   	
	
}
void SPIC_RESET_EN(spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0]           = cbFLH_RESETEN;    
    
   	CmdBuf[3]           = 0x0;				
   	CmdBuf[2]           = 0x0;
   	CmdBuf[1]           = 0x0;
    
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 1;
	SpiStr.Read        = _FLH_WRITE;
	SpiStr.rwPtr       = 0;
    SpiStr.rwLen       = 0;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_FUNC(&SpiStr);
    
   	
	
}


void SPIC_EXITQ(spicmap *smap)
{
	
	
	UINT8    CmdBuf[4];
    Spi_Str  SpiStr;
		
	
	
	
	CmdBuf[0]           = cbFLH_EXITQ;    
    
   	CmdBuf[3]           = 0x0;				
   	CmdBuf[2]           = 0x0;
   	CmdBuf[1]           = 0x0;
    
	SpiStr.CheckSum    = 0;
	SpiStr.CmdPtr      = &CmdBuf[0];
   	SpiStr.CmdLen      = 1;
	SpiStr.Read        = _FLH_WRITE;
	SpiStr.rwPtr       = 0;
    SpiStr.rwLen       = 0;
	
	SpiStr.nChannel	   = 1;
   	SpiStr.mAddrToggle = 0;
   	SpiStr.ndummybit   = 0; 
   	
	SpiStr.Interface   = smap->Interface;
   	SpiStr.Intf_Ch	   = smap->Intf_Ch;
   	
   	SPIC_FUNC(&SpiStr);
    
   	
	
}


void SPIC_buf_Initialize(void)
{
	
 	gTmp = (UINT8 *)fLib_NC_malloc(32);
 	xTmp = (UINT8 *)fLib_NC_malloc(32);
 	gData = (UINT8 *)fLib_NC_malloc(64);
 	
 	QuadBitFun_Register(); 	
 	
  
 	
}
