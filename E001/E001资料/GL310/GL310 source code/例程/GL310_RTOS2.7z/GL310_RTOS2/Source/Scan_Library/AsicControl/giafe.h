
#ifndef _giafe_h_
#define _giafe_h_

//#include "..\api\asicapi.h"
#include "..\asiccmd\gusrdef.h"
//#include "windows.h"
#include "stdio.h"
#include "..\asiccmd\asiccmd.h"

#define gGainR_300			0x37 //0x31
#define gGainG_300			0x31
#define gGainB_300			0x31
#define gGainR_300_B		0x31
#define gGainG_300_B		0x31
#define gGainB_300_B		0x31

#define gGainR_600			0x31 //0x37
//#define gGainG_600			0x2c
//#define gGainB_600			0x2c	
//#define gGainR_600_B		0x2c
//#define gGainG_600_B		0x2c
//#define gGainB_600_B		0x2c

#define gGainR_1200			0x37
#define gGainG_1200			0x2c
#define gGainB_1200			0x2c
#define gGainR_1200_B		0x2c
#define gGainG_1200_B		0x2c
#define gGainB_1200_B		0x2c

#define gOffR_300				0x5c
#define gOffG_300				0x5c
#define gOffB_300				0x5c
#define gOffR_300_B			0x5c
#define gOffG_300_B			0x5c
#define gOffB_300_B			0x5c

#define gOffR_600				0x7f; //0x17f
#define gOffG_600				0x5c
#define gOffB_600				0x5c
#define gOffR_600_B			0x5c
#define gOffG_600_B			0x5c
#define gOffB_600_B			0x5c

#define gOffR_1200			0x5c
#define gOffG_1200			0x5c
#define gOffB_1200			0x5c
#define gOffR_1200_B		0x5c
#define gOffG_1200_B		0x5c
#define gOffB_1200_B		0x5c

/*=======Duplex Gain============*/
#define dGainR_200			0x32 //0x3f
#define dGainR_200_B		0x33 //0x3f

#define dGainR_300			0x32 //0x3f
//#define dGainG_300			0x38
//#define dGainB_300			0x38
#define dGainR_300_B		0x33 //0x3f
//#define dGainG_300_B		0x38
//#define dGainB_300_B		0x38

#define dGainR_600			0x32 //0x3f
//#define dGainG_600			0x38
//#define dGainB_600			0x38
#define dGainR_600_B		0x33 //0x3f
//#define dGainG_600_B		0x38
//#define dGainB_600_B		0x38

/*=======Duplex Offset============*/
#define dOffR_200				0x5f
#define dOffR_200_B				0x5f

#define dOffR_300				0x5f
//#define dOffG_300				0x60
//#define dOffB_300				0x60
#define dOffR_300_B				0x5f
//#define dOffG_300_B			0x60
//#define dOffB_300_B			0x60

#define dOffR_600				0x5f
//#define dOffG_600				0x60
//#define dOffB_600				0x60
#define dOffR_600_B				0x5f
//#define dOffG_600_B			0x60
//#define dOffB_600_B			0x60

#define DARK_THROD			 16

#define ADF_DARK_THROD	 10

#define Brightness_TARGET			232 //192 //180
#define ADF_Brightness_TARGET		242 //186//180

typedef struct {
	unsigned short Dark:	6; //8; //4;
	unsigned short White:	10; //8; //12;
} Str_16bShd;  //use for 16bit shading 12+4 or 10+6 or 8+8 


//FB
/*=====================<Globals>==========================*/
extern int loop_time;
extern int ADF_loop_time,ADF_B_loop_time;
int FB_DoCalibration(int resolution);
int SampleDarkPixel(void);
int MnPowerOnBackToHome(void);
int MnPWROnMove(void);
int PowerOnMoveToPRNU(void);
int PowerOnBackToHome(void);
int packing_shadingfile(char* whitefile, char* darkfile, char* outfile);
int packing_shadingfile_B(char* whitefile, char* darkfile, char* outfile);
/*====================<Prototypes>=========================*/
extern unsigned short LampMax1[3];
extern unsigned short LampMin1[3];
extern unsigned short LampAvg1[3];
extern unsigned short LampAvg1_tmp[3];

extern float LedLampR1_300;
extern float LedLampG1_300;
extern float LedLampB1_300;

extern float LedLampR1_600;
extern float LedLampG1_600;
extern float LedLampB1_600;

extern float LedLampR1_1200;
extern float LedLampG1_1200;
extern float LedLampB1_1200;

extern unsigned short AFEGainCode[3];
extern unsigned short AFEOffsetCode[3];
extern unsigned short AFEGainCode_B[3];
extern unsigned short AFEOffsetCode_B[3];

extern unsigned short wLEDLAMPEXP[3];
//float wLEDLAMPEXP[3];
extern unsigned short wLEDLAMPEXP_B[3];

//unsigned short g_OffR, g_OffG, g_OffB;
//unsigned short g_OffR_B, g_OffG_B, g_OffB_B;

extern float fGainRate;

extern int Sctl_ReadScanData_to_RAWFILE2(ScanParameter *pSPM);
extern int CMDASIC_WriteRegisterBit(unsigned short nAddr, unsigned char StartBit, unsigned char Bitn, unsigned char iData);
extern float g_Exp;
extern float gLightOnTime[3]; 
extern float gLightOnTime_B[3];

extern int PowerOnBACK;
extern float CtlDevice_PixelTime;
extern unsigned char StartLEDTuning;

extern float g_Exp, g_LedR1, g_LedG1, g_LedB1, g_LedR2, g_LedG2, g_LedB2;
//extern unsigned short g_GainR, g_GainG, g_GainB, g_OffR, g_OffG, g_OffB;

extern unsigned short CAL_Offset_Lv;

extern float g_Exp, g_LedR1, g_LedG1, g_LedB1, g_LedR2, g_LedG2, g_LedB2;
//extern unsigned short g_GainR, g_GainG, g_GainB, g_OffR, g_OffG, g_OffB;

//ADF
/*=====================<Globals>==========================*/

/*====================<Prototypes>=========================*/
#endif //_giafe_h_