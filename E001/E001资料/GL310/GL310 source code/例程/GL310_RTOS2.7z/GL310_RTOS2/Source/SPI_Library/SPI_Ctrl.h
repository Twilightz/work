#ifndef _SPICTRL_H_
#define _SPICTRL_H_

#include "def.h"
#include "tag.h"
#include "libspic.h"
 
#define _SPI_TX
 
void SPIC_FUNC(Spi_Str *spistr); 
void SPIC_Transfer_Entry_Register(BOOL (*transfer_entry)(Spi_Str *));
BOOL user_spi_transfer(Spi_Str *spistr); 


typedef struct _spic_transfer_entry{

	 BOOL  (*transfer_entry)(Spi_Str *);		
	
}spic_transfer_entry;


#endif // __SPI_H__
