//-------------------
//	File: sc_job_adf.c
//	Date: 2014.07.31
//-------------------

//#include "sc_api.h"
#include "cmd.h"	//"i_GL310.h"
#include "sc_job.h"
#include ".\AsicCmd\gusrdef.h"
#include ".\asiccmd\asiccmd.h" 
#include ".\asiccontrol\giafe.h"

//-----------------------------------
int PWR_OperationMode(ScanParameter *pSPM);	//gibeng.c
int CtlADF_SetADFSEL(unsigned char bEnable); //giadf.c
int Sctl_CheckADFPaperReady(int *status);	//gscontrol.c
int Sctl_SetScanParameter(ScanParameter *pSPM);	//gscontrol.c
int CtlAfe_SetAFEGain(unsigned short GainR, unsigned short GainG, unsigned short GainB); //giafe.c
int CtlAfe_SetAFEOffset(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB); //giafe.c
int CtlAfe_SetAFEGain_B(unsigned short GainR, unsigned short GainG, unsigned short GainB); //giafe.c
int CtlAfe_SetAFEOffset_B(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB); //giafe.c
int CtlImage_WriteShadingFile(char* main_file, char* sub_file); //gishdgma.c
int CtlImage_WriteShadingFile_SimplexscanFlag(char* shading_file); //gishdgma.c
int CtlADF_LEDPWR(unsigned char nEnable); //giadf.c
int Sctl_StartScan(ScanParameter *pSPM); //gscontrol.c
int Sctl_ReadScanData_JPG(ScanParameter *pSPM); //gsimgread.c
int Sctl_ReadScanData_RAW(ScanParameter *pSPM); //gsimgeread_raw.c
int Sctl_StopScan(ScanParameter *pSPM); //gscontrol.c
int CtlADF_CheckPaperJam(int *jam); //giadf.c
int Sctl_CheckADFScanFinish(ScanParameter *pSPM, int *status);
int Sctl_StopScan(ScanParameter *pSPM); //gscontrol.c
int CtlMotor_WaitMotorStop(void); //gimotor.c
int Sctl_MoveMotor(float fpps, unsigned int Steps, int iDir);//gscontrol.c
int Sctl_MoveMotor(float fpps, unsigned int Steps, int iDir);//gscontrol.c
//----------------------------------------
float g_Exp  =0.140;
float	gLightOnTime[3];
float	gLightOnTime_B[3];
//unsigned short wLEDLAMPEXP[3];
//unsigned short wLEDLAMPEXP_B[3];
extern unsigned int DuplexscanFlag;
extern int mEngineScan;
//extern unsigned int MonoScanFlag;
#if 1
float g_LedR1=0.075f;
float g_LedG1=0.136f;
float g_LedB1=0.136f;
float g_LedR2=0.075f;
float g_LedG2=0.136f;
float g_LedB2=0.136f;
#endif
#if 0
//LED TRUE Gray  R:G:B = 3:6:1
float g_LedR1=0.036f;
float g_LedG1=0.108f;
float g_LedB1=0.120f;
float g_LedR2=0.036f;
float g_LedG2=0.108f;
float g_LedB2=0.120f;
#endif
/*unsigned short g_GainR=240;
unsigned short g_GainG=240;
unsigned short g_GainB=240;
unsigned short g_OffR=40; 
unsigned short g_OffG=40; 
unsigned short g_OffB=40; 
unsigned short g_GainR_B=240;
unsigned short g_GainG_B=240;
unsigned short g_GainB_B=240;
unsigned short g_OffR_B=33;
unsigned short g_OffG_B=33;
unsigned short g_OffB_B=33;*/

int scan_adf_image();
extern int CtlImage_WriteShadingFile(char* main_file, char* sub_file);
unsigned short AFEGainCode[3];
unsigned short AFEOffsetCode[3];
unsigned short AFEGainCode_B[3];
unsigned short AFEOffsetCode_B[3];

extern float CtlDevice_PixelTime;

static ScanParameter SPM;
extern int iEnableShading;	// main.c

int ReadFileCalibartionDataDuplex(ScanParameter *pSPM)
{
	int bRet=1;

	FILE *botout0, *botout1, *botout2; 
	FILE *topout0, *topout1, *topout2; //Dualscan 

	switch(solu)
	{
	case 200:
		if(pSPM->spDualscan ==2){//DuplexscanFlag
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=dGainR_300;
			AFEGainCode_B[0] = AFEGainCode_B[1] = AFEGainCode_B[2] = dGainR_300_B; //B engine
			AFEOffsetCode[0] = AFEOffsetCode[1] = AFEOffsetCode[2]=dOffR_300;
			AFEOffsetCode_B[0] = AFEOffsetCode_B[1] = AFEOffsetCode_B[2]=dOffR_300_B;
			pSPM->spShutterTime[0]  = d_300_LedR1;
			pSPM->spShutterTime[1]  = d_300_LedG1;
			pSPM->spShutterTime[2]  = d_300_LedB1;
			pSPM->spShutterTime_B[0]  = g_300_LedR2;
			pSPM->spShutterTime_B[1]  = g_300_LedG2;
			pSPM->spShutterTime_B[2]  = g_300_LedB2;
		}
		else{ //Simplex
			AFEGainCode[0] = AFEGainCode[1] = AFEGainCode[2] = gGainR_300;
			AFEOffsetCode[0]=AFEOffsetCode[1]=AFEOffsetCode[2]=gOffR_300;
			pSPM->spShutterTime[0]  = g_300_LedR1;
			pSPM->spShutterTime[1]  = g_300_LedG1;
			pSPM->spShutterTime[2]  = g_300_LedB1;
		}
		break;

	case 300:
		if(pSPM->spDualscan ==2){//DuplexscanFlag
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=dGainR_300;
			AFEGainCode_B[0] = AFEGainCode_B[1] = AFEGainCode_B[2] = dGainR_300_B; //B engine
			AFEOffsetCode[0] = AFEOffsetCode[1] = AFEOffsetCode[2]=dOffR_300;
			AFEOffsetCode_B[0] = AFEOffsetCode_B[1] = AFEOffsetCode_B[2]=dOffR_300_B;
			pSPM->spShutterTime[0]  = d_300_LedR1;
			pSPM->spShutterTime[1]  = d_300_LedG1;
			pSPM->spShutterTime[2]  = d_300_LedB1;
			pSPM->spShutterTime_B[0]  = d_300_LedR2;
			pSPM->spShutterTime_B[1]  = d_300_LedG2;
			pSPM->spShutterTime_B[2]  = d_300_LedB2;
		}
		else{ //Simplex
			AFEGainCode[0] = AFEGainCode[1] = AFEGainCode[2] = gGainR_300;
			AFEOffsetCode[0] = AFEOffsetCode[1] = AFEOffsetCode[2] = gOffR_300;
			pSPM->spShutterTime[0]  = g_300_LedR1;
			pSPM->spShutterTime[1]  = g_300_LedG1;
			pSPM->spShutterTime[2]  = g_300_LedB1;
		}
		break;

	case 600:
		if(pSPM->spDualscan ==2){//DuplexscanFlag
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=dGainR_600;
			AFEGainCode_B[0] = AFEGainCode_B[1] = AFEGainCode_B[2] = dGainR_600_B; //B engine
			AFEOffsetCode[0] = AFEOffsetCode[1] = AFEOffsetCode[2]=dOffR_600;
			AFEOffsetCode_B[0] = AFEOffsetCode_B[1] = AFEOffsetCode_B[2]=dOffR_600_B;
			pSPM->spShutterTime[0] = d_600_LedR1;
			pSPM->spShutterTime[1] = d_600_LedG1;
			pSPM->spShutterTime[2] = d_600_LedB1;
			pSPM->spShutterTime_B[0] = d_600_LedR2;
			pSPM->spShutterTime_B[1] = d_600_LedG2;
			pSPM->spShutterTime_B[2] = d_600_LedB2;
		}
		else{ //Simpex
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=gGainR_600;
			AFEOffsetCode[0] = AFEOffsetCode[1] = 	AFEOffsetCode[2] = gOffR_600;
			pSPM->spShutterTime[0] = g_600_LedR1;
			pSPM->spShutterTime[1] = g_600_LedG1;
			pSPM->spShutterTime[2] = g_600_LedB1;
		}
		break;
	}
	return True;
}

int CheckMotorinHome(int *iState)  
{
	int bRet;
	unsigned char nVal;

	bRet=CMDASIC_ReadRegister(0x0401,&nVal);
	if (!bRet)
		return False;
	*iState = ( (nVal & 0x08) ? 1 : 0);

	return True;
}


int ADF_SetParameter(JOB_SCAN_T *job)
{

	int isADFPaperReady = 0;
	int result;
	unsigned short data;
	
	result = PWR_OperationMode(0) &&
			CtlADF_SetADFSEL(0) &&
			Sctl_CheckADFPaperReady(&isADFPaperReady);
	if(!result || !isADFPaperReady) {
		dprintf("......ADF Paper not Ready !!\n");
		return False;
	}

	solu = job->img.dpi.x;
	SPM.spScanBeginPixel = 0;	            //scan begin x way postion
//HL modify	
//first 59pixel dummy black
	SPM.spScanBeginPixel = 59 * 2400 / 300;
		
	SPM.spScanBeginLine = 0;	            //scan begin y way postion
	iEnableShading = job->action.shading;
	//MonoScanFlag = (job->img.bit <= 16)? 1: 0;
	DuplexscanFlag = (job->acq.duplex == 3)? 1: 0;
	mEngineScan = (job->acq.duplex <= 1)? 1: 0;

	//set AFD scan 3 * A4 paper length
	switch(solu)
	{
	case 200: 
		SPM.spScanLinePixels = CIS_TGEXP_200;   			//scan total x way pixels  
		SPM.spTotalScanLines = 200*12*3; 						//scan total y way lines  
		SPM.spPixelResolution = 200;									// x way resolution
		SPM.spMotorResolution = 200;
		SPM.spTimingIdx =		8; //timing idex 1,2,4,8
		g_Exp  =g_200_Exp;//0.22f
		gLightOnTime[0]=d_300_LedR1;
		gLightOnTime[1]=d_300_LedG1;
		gLightOnTime[2]=d_300_LedB1;
		gLightOnTime_B[0]=d_300_LedR2;
		gLightOnTime_B[1]=d_300_LedG2;
		gLightOnTime_B[2]=d_300_LedB2;
		SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY
		SPM.spCCDLMT= 2;
		//----------------------------------------------
		SPM.spShutterTime[0]= SPM.spShutterTime_B[0]= 0.20980000; 
		SPM.spShutterTime[1]= SPM.spShutterTime_B[1]= 0.21960001;
		SPM.spShutterTime[2]= SPM.spShutterTime_B[2]= 0.13700001;
		AFEGainCode[0]=0x6a; AFEGainCode[1]=0x32; AFEGainCode[2]=0x32;
		AFEGainCode_B[0]=0x33; AFEGainCode_B[1]=0x33; AFEGainCode_B[2]=0x33;
		AFEOffsetCode[0]=0x8b; AFEOffsetCode[1]=0x8b; AFEOffsetCode[2]=0x8b;
		AFEOffsetCode_B[0]=0x63; AFEOffsetCode_B[1]=0x63; AFEOffsetCode_B[2]=0x63;
		//----------------------------------------------
		break;

	case 300:
		//HL modify
		SPM.spScanLinePixels = job->img.dot.w;  //CIS_TGEXP_300;    			//scan total x way pixels  
		SPM.spTotalScanLines = 300*12*3;						//scan total y way lines  
		SPM.spPixelResolution = 300;									// x way resolution
		SPM.spMotorResolution = 300;								// y way resolution
		SPM.spTimingIdx =		8;											//timing idex 1,2,4,8
		g_Exp  =g_300_Exp;//0.22f
		gLightOnTime[0]=d_300_LedR1;
		gLightOnTime[1]=d_300_LedG1;
		gLightOnTime[2]=d_300_LedB1;
		gLightOnTime_B[0]=d_300_LedR2;
		gLightOnTime_B[1]=d_300_LedG2;
		gLightOnTime_B[2]=d_300_LedB2;

		//if(MonoScanFlag){
		if(job->img.bit <= 16) {
			SPM.spImageType = IMAGE_GRAY;			//IMAGE_COLOR or IMAGE_GRAY
			SPM.spCCDLMT= 0;
			g_Exp = 0.330f;
		}
		else{
			SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY
			SPM.spCCDLMT= 2;
		}
		//----------------------------------------------
		SPM.spShutterTime[0]= SPM.spShutterTime_B[0]= 0.18440001; 
		SPM.spShutterTime[1]= SPM.spShutterTime_B[1]= 0.19220001;
		SPM.spShutterTime[2]= SPM.spShutterTime_B[2]= 0.11480000;
		AFEGainCode[0]=0x33; AFEGainCode[1]=0x32; AFEGainCode[2]=0x32;
		AFEGainCode_B[0]=0x33; AFEGainCode_B[1]=0x33; AFEGainCode_B[2]=0x33;
		AFEOffsetCode[0]=0x8b; AFEOffsetCode[1]=0x8b; AFEOffsetCode[2]=0x8b;
		AFEOffsetCode_B[0]=0x6f; AFEOffsetCode_B[1]=0x6f; AFEOffsetCode_B[2]=0x6f;
		//----------------------------------------------
		break;

	case 600:
		SPM.spScanLinePixels = CIS_TGEXP_600;    		//scan total x way pixels  
		SPM.spTotalScanLines = 600*12*3;		//scan total y way lines  
		SPM.spPixelResolution = 600;			// x way resolution
		SPM.spMotorResolution = 600;			// y way resolution
		SPM.spTimingIdx =		4;		//timing idex 1,2,4,8
		g_Exp  =g_600_Exp;
		gLightOnTime[0]=d_600_LedR1;
		gLightOnTime[1]=d_600_LedG1;
		gLightOnTime[2]=d_600_LedB1;
		gLightOnTime_B[0]=d_600_LedR2;
		gLightOnTime_B[1]=d_600_LedG2;
		gLightOnTime_B[2]=d_600_LedB2;
		SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY
		SPM.spCCDLMT= 2;
		//----------------------------------------------
		SPM.spShutterTime[0]= SPM.spShutterTime_B[0]= 0.22800000; 
		SPM.spShutterTime[1]= SPM.spShutterTime_B[1]= 0.25000000;
		SPM.spShutterTime[2]= SPM.spShutterTime_B[2]= 0x17200001;
		AFEGainCode[0]=0x32; AFEGainCode[1]=0x32; AFEGainCode[2]=0x32;
		AFEGainCode_B[0]=0x33; AFEGainCode_B[1]=0x33; AFEGainCode_B[2]=0x33;
		AFEOffsetCode[0]=0x5f; AFEOffsetCode[1]=0x5f; AFEOffsetCode[2]=0x5f;
		AFEOffsetCode_B[0]=0x5f; AFEOffsetCode_B[1]=0x5f; AFEOffsetCode_B[2]=0x5f;
		//----------------------------------------------
		break;
	}
	//SPM.spMonoChannel = CHANNEL_GREEN;		//channel of IMAGE_GRAY 
	//SPM.spPixelDepth =		8;				//pixel depth 8 or 16
	switch(job->img.bit) {
		case 24:
			SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY	
			SPM.spPixelDepth =	8;					//pixel depth 8 or 16
			SPM.spCCDLMT = 2;
			break;
		case 8:
			SPM.spImageType = IMAGE_GRAY;			//IMAGE_COLOR or IMAGE_GRAY	
			SPM.spPixelDepth =	8;					//pixel depth 8 or 16
			SPM.spCCDLMT = 0;
			break;
		case 48:
			SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY 
			SPM.spPixelDepth =	16; 				//pixel depth 8 or 16
			SPM.spCCDLMT = 2;
			break;
		case 16:
			SPM.spImageType = IMAGE_GRAY;			//IMAGE_COLOR or IMAGE_GRAY 
			SPM.spPixelDepth =	16; 				//pixel depth 8 or 16
			SPM.spCCDLMT = 0;
			break;
		default:
			dprintf("SetParameter error (img.bit=%d)\n", job->img.bit);
			return FALSE;
	}

	SPM.spExposureTime =  g_Exp; //exposure time , unit = ms

#if 0 	
	SPM.spShutterTime[0]= gLightOnTime[0]; 
	SPM.spShutterTime[1]= gLightOnTime[1];
	SPM.spShutterTime[2]= gLightOnTime[2]; 
	SPM.spShutterTime_B[0]= gLightOnTime_B[0]; 
	SPM.spShutterTime_B[1]= gLightOnTime_B[1]; 
	SPM.spShutterTime_B[2]= gLightOnTime_B[2];
#endif

	SPM.spDummyLines =		0;		//dummy line
	SPM.spStillMode =		0;		//set motor still status
	SPM.spAutoGoHome =		0;		//set auto feed last paper function after scan finished
	SPM.spDisBackTrack =	1;		//set carriage backtracking when image buffer full, enable_backtracking=0

	if(iEnableShading==1){
		SPM.spShading	=		1;		//enable ASIC shading
		SPM.spGammaMapping	=	1;		//enable ASIC gamma
	}
	else{
		SPM.spShading	=		0;		//enable ASIC shading
		SPM.spGammaMapping	=	0;		//enable ASIC gamma
	}
	SPM.spCCDPacking = 0;
	SPM.spTestImage = job->action.test_pattern;			//0=real image, 1=pixel count pattern, 2=line count pattern
	SPM.spADFscan		=	0x02; //0x02;   //1=single adf scan, 2=autoadf

	if(DuplexscanFlag == 1){
		SPM.spDualscan=	2;              // 0=disable,  1=switch separate CCDLMT=5,   2=scan in same time CCDLMT=2
		SPM.spSimplexSide = 0;			// 0 = top side, 1 = bottom side
	}
	else{ //!Duplexscan
		if(mEngineScan ==1){
			SPM.spDualscan=	0;              // 0=disable,  1=switch separate CCDLMT=5,   2=scan in same time CCDLMT=2
			SPM.spSimplexSide = 0;			// 0 = top side, 1 = bottom side
		}
		else{
			SPM.spDualscan=	0;              // 0=disable,  1=switch separate CCDLMT=5,   2=scan in same time CCDLMT=2
			SPM.spSimplexSide = 1;			// 0 = top side, 1 = bottom side
		}
	}
	//bit0=JPG enable, bit3=thumb enable, bit4(1=444 0=422), bit7(1=best 0=normal quality)
	SPM.spJPEGENC = (job->img.format == I3('JPG'))? 0x11: 0x00; 

	SPM.spMirror = 0x00;			//nibble 0 top side flag, nibble 1 bottom side flag (ScanLinePixels must be multiple of 8)

//HL modify
#if 0
	result = ReadFileCalibartionDataDuplex(&SPM);  // write scan parameter
	if(!result) return False;
#else
	SPM.spShutterTime[0]  = g_300_LedR1;
	SPM.spShutterTime[1]  = g_300_LedG1;
	SPM.spShutterTime[2]  = g_300_LedB1;
#endif

	CtlImage_RamSet_ImageBuffer(&SPM);
	Sctl_SetScanParameter(&SPM);

//HL modify
#if 0	
	CtlAfe_SetAFEGain(AFEGainCode[0], AFEGainCode[1], AFEGainCode[2]);  //write AFE gain code
	CtlAfe_SetAFEOffset(AFEOffsetCode[0], AFEOffsetCode[1], AFEOffsetCode[2]); //write AFE offset code
	CtlAfe_SetAFEGain_B(AFEGainCode_B[0], AFEGainCode_B[1], AFEGainCode_B[2]);  //write AFE gain code
	CtlAfe_SetAFEOffset_B(AFEOffsetCode_B[0], AFEOffsetCode_B[1], AFEOffsetCode_B[2]); //write AFE offset code
	
	if(SPM.spShading)
	{
		switch(solu){
			case 200:
				if(SPM.spDualscan !=0) {
					CtlImage_WriteShadingFile(0, 0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;

			case 300:
				if(SPM.spDualscan !=0) {
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;
			
			case 600:
				if(SPM.spDualscan !=0) {
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;
		}
	}
#endif
	
	//horizontal mirror function
	CMDASIC_WriteRegisterBit(0x03a1, 0, 4, 0); 
	CMDASIC_WriteRegisterBit(0x09a1, 0, 4, 1); 

	/*//Set GPIO40 as ADF DOC SENSOR
	CMDASIC_WriteRegisterBit(0x66,0,2,0); //Enable GPIO40
	CMDASIC_WriteRegisterBit(0x54,7,1,1); //GPIO40 OUTPUT VALUE
	CMDASIC_WriteRegisterBit(0x5c,7,1,1); //GPIO40 DIR*/

//HL modify
#if 0

// for console output recovery
	CMDASIC_ReadBus(0xa0000068, &result);
	
#ifdef CANOPUS_COM2
	CMDASIC_WriteBus(0xa0000068, 0x0c00 | result);
#else
	CMDASIC_WriteBus(0xa0000068, 0x0400 | result);
#endif

#endif

	CtlAfe_ReadAFERegister(0x02,&data);  
	dprintf("AFE Final Gain = 0x%02x \n",data); //Gain
	CtlAfe_ReadAFERegister(0x05,&data);  
	dprintf("AFE Final Offset = 0x%02x \n",data); //Offset

	dprintf("*** Read LED EXPO TIME ***\n");
	dprintf("LED EXPO TIME R, G, B = %f, %f, %f\n", SPM.spShutterTime[0], SPM.spShutterTime[1], SPM.spShutterTime[2]);
	dprintf("LED EXPO TIME R2, G2, B2 = %f, %f, %f\n", SPM.spShutterTime_B[0], SPM.spShutterTime_B[1], SPM.spShutterTime_B[2]);
	return True;
}



int ADF_StartScan(JOB_SCAN_T *job)
{
	int bRet;
	int istate;

	//SET_REGBIT(0x00c, CLRMCNT(1)|CLRDOCJM(1)|CLRLNCNT(1), CLRMCNT(1)|CLRDOCJM(1)|CLRLNCNT(1));

	if((SPM.spADFscan & 0x0f) == 0x02 ) { // auto adf scan

		bRet=CheckMotorinHome(&istate); //franky
		if(!bRet) return False;

		CtlADF_LEDPWR(1); //Turn-on Lamp power

		CMDASIC_WriteRegisterBit(0x0003,4,1,1); //LAMPPWR ON

		//CMDASIC_Debug_Dump();
		bRet=Sctl_StartScan(&SPM); 
		if(!bRet) return False;
	}
	else if ( (SPM.spADFscan & 0x0f) == 0x01 ) //single adf scan
	{ 
			//CMDASIC_Debug_Dump();
			bRet=Sctl_StartScan(&SPM);
			if(!bRet) return False;
	}
	return True;

}


int ADF_CancelScan(JOB_SCAN_T *job)
{
	
	SET_AUTO_ADF(0);
	SET_LINCNT(1);
	return TRUE;
}


int ADF_StopScan(JOB_SCAN_T *job)
{
	int bRet;
	int isADFScanFinish=False;

	if((SPM.spADFscan & 0x0f) == 0x02 ) { // auto adf scan
		bRet=Sctl_StopScan(&SPM); 
		if(!bRet) return False;

		CtlMotor_WaitMotorStop();
	}
	else if ( (SPM.spADFscan & 0x0f) == 0x01 ) //single adf scan
	{
		bRet=Sctl_StopScan(&SPM); 
		if(!bRet) return False;

		CtlMotor_WaitMotorStop();

		Sctl_CheckADFScanFinish(&SPM, &isADFScanFinish);
		//if (isADFScanFinish)
		//	break;
	}
#if 0 //Feed paper
		CtlADF_SetADFSEL(1);
		Sctl_MoveMotor(1000,1000,1);
		CtlMotor_WaitMotorStop();
		CtlADF_SetADFSEL(0);
#endif

//HL modify
#if 0 //Pick-up motor reverse
{
		int status = GET_STATUS(0xffffffff);
		if(status & DOCSNR(1)) {
			CtlADF_SetADFSEL(1);
			Sctl_MoveMotor(1000,2000,0);
			CtlMotor_WaitMotorStop();
		}
}
		CtlADF_SetADFSEL(0);
#endif

		//ADF_FeedPaperRollerRevrse();

}
