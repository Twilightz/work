#ifndef _job_h_
#define _job_h_

#include "sc.h"

//-----------------

int JOB_test();

//-----------------
#endif //_job_h_
