
////////////////////////////////////////////////////////////////
// File - gsimgread.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

//#include <Windows.h>
#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "..\asiccontrol\giasiccontrol.h"
//#include "gscanctrl.h"
//#include "..\main\savebmp.h"
//#include "..\api\Utility.h"

//#include "..\main\savetiff.h"


static int scanidx=0;

int ReadRawImage(unsigned char *Buf, unsigned int dwLen);
int ReadRawImage_B(unsigned char *Buf, unsigned int dwLen);

extern unsigned int RdOnceLine;
extern unsigned char *RdBuffer;
extern int disable_output_images;

////////////////////////////////////////////////////////////////
//  Read RAW image flow
//1. check until ValidLine !=0 
//2. read ValidLine size image from DDR
//3. repeat until total line image read finish
////////////////////////////////////////////////////////////////

//save to TIFF file for duplex
int Sctl_ReadScanData_RAW(ScanParameter *pSPM) 
{
	//FILE *fpout, *fpout2;
	char strtmp[256]; 
	int bRet, fsh1, fsh2, chk1, chk2;
	unsigned int dwLineSize;
	unsigned int ScanCnt1, ScanCnt2, ValidLine;
	unsigned int tl_readLn1, tl_readLn2, raw_jpg_page;
	unsigned int readlen; 
	DWORD dwRet;

	//if(scanidx>1) scanidx = 0;

	if(pSPM->spPixelDepth==1)
		pSPM->spImageType=IMAGE_GRAY;

	if(pSPM->spMonoChannel==CHANNEL_TRUE_Matrix)
		pSPM->spImageType=IMAGE_GRAY;

	if(!disable_output_images){
#if 0
		if(pSPM->spDualscan!=0) {
			gTIFFCreate(0, pSPM, scanidx);
			gTIFFCreate(1, pSPM, scanidx);
		} else {
			if(pSPM->spSimplexSide==0)
				gTIFFCreate(0, pSPM, scanidx);
			else
				gTIFFCreate(1, pSPM, scanidx);
		}
#endif
	}
	dwLineSize = pSPM->spScanLinePixels * pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1)/8;

	tl_readLn1=0; chk1=0; ScanCnt1=0xffffff;
	tl_readLn2=0; chk2=0; ScanCnt2=0xffffff;
	if(pSPM->spDualscan!=0) {
		fsh1=0;	fsh2=0;
	} else {
		if(pSPM->spSimplexSide==0) {
			fsh1=0;	fsh2=1;
		} else {
			fsh1=1;	fsh2=0;
		}
	}

	/////////////////////////////////////////////////////////////////
	while(1) {

		if ((fsh1==1)&&(fsh2==1)) break;
		///////////////////////////////////////////////
		if (fsh1==0) {
			CMDASIC_ReadFourRegister(0x0408,&ValidLine);
			if(chk1==0) {
				raw_jpg_page = ValidLine & 0x80000000; 
				if (raw_jpg_page) {
					chk1=1;
					CMDASIC_ReadBus(0xb0004000, &ScanCnt1);     //total line
					//printf("\n raw_jpg_page1=0x%08x, ScanCnt1=%d tl_readLn1=%d\n",raw_jpg_page,ScanCnt1, tl_readLn1);
					if (tl_readLn1 == ScanCnt1) {
						//printf("\n c finish tl_readLn1=%d, ScanCnt1=%d \n",tl_readLn1,ScanCnt1);
						fsh1=1;
						continue; 
					}
				}
			}
			ValidLine &= 0x001fffff;
			if(ValidLine!=0) {
				readlen = (ValidLine > RdOnceLine) ? RdOnceLine : ValidLine;
					if (chk1==1) {
						readlen = ((ScanCnt1-tl_readLn1)>readlen) ? readlen : (ScanCnt1-tl_readLn1);
				}
				bRet=ReadRawImage(RdBuffer,readlen*dwLineSize);  
				if(!bRet) 
					break;
				//if(!disable_output_images)
				//	gTIFFWriteImage(0, RdBuffer, dwLineSize, readlen);

				CMDASIC_WriteFourRegister(0x0408,readlen);  //clear validline
				//printf(" tl_readLn1=%d, readlen1=%d, validline1=%d \n",tl_readLn1, readlen, ValidLine);
				tl_readLn1 += readlen; 
				if (tl_readLn1 == ScanCnt1) {
					//printf("\n finish tl_readLn1=%d, ScanCnt1=%d \n",tl_readLn1,ScanCnt1);
					fsh1=1;
					continue; 
				}
			}
		}  //if (fsh1==0) {

		if (fsh2==0) {
			CMDASIC_ReadFourRegister(0x0a08,&ValidLine);
			if(chk2==0) {
				raw_jpg_page = ValidLine & 0x80000000; 
				if (raw_jpg_page) {
					chk2=1;
					CMDASIC_ReadBus(0xb0006000, &ScanCnt2);     //total line
					printf("\n raw_jpg_page2=0x%08x, ScanCnt2=%d tl_readLn2=%d\n",raw_jpg_page,ScanCnt2, tl_readLn2);
					if (tl_readLn2 == ScanCnt2) {
						printf("\n c finish tl_readLn2=%d, ScanCnt2=%d \n",tl_readLn2,ScanCnt2);
						fsh2=1;
						continue; 
					}
				}
			}
			ValidLine &= 0x001fffff;
			if(ValidLine!=0) {
				readlen = (ValidLine > RdOnceLine) ? RdOnceLine : ValidLine;
				if (chk2==1) {
					readlen = ((ScanCnt2-tl_readLn2)>readlen) ? readlen : (ScanCnt2-tl_readLn2);
				}
				bRet=ReadRawImage_B(RdBuffer,readlen*dwLineSize);  
				if(!bRet) 
					break;

				//gTIFFWriteImage(1, RdBuffer, dwLineSize, readlen);

				CMDASIC_WriteFourRegister(0x0a08,readlen);  //clear validline
				printf(" tl_readLn2=%d, readlen2=%d, validline2=%d \n",tl_readLn2, readlen, ValidLine);
				tl_readLn2 += readlen; 
				if (tl_readLn2 == ScanCnt2) {
					printf("\n finish tl_readLn2=%d, ScanCnt2=%d \n",tl_readLn2,ScanCnt2);
					fsh2=1;
					continue; 
				}
			}
		}  //if (fsh2==0) 
		//if ADF scan check paper jam : CtlADF_CheckPaperJam
	}

	/////////////////////////
	if(!disable_output_images){
#if 0
		if(pSPM->spDualscan!=0) {
			gTIFFClose(0);
			gTIFFClose(1);
		} else {
			if(pSPM->spSimplexSide==0)
				gTIFFClose(0);
			else
				gTIFFClose(1);
		}
#endif
	}

	scanidx++;

	return True;
}


//save to RAW file for duplex
int Sctl_ReadScanData_to_RAWFILE2(ScanParameter *pSPM) 
{
	FILE *fpout, *fpout2;
	char strtmp[256]; 
	int bRet, fsh1, fsh2, chk1, chk2;
	unsigned int dwLineSize;
	unsigned int ScanCnt1, ScanCnt2, ValidLine;
	unsigned int tl_readLn1, tl_readLn2, raw_jpg_page;
	unsigned int readlen; 

	if(scanidx>1) scanidx = 0;

	if(pSPM->spPixelDepth==1)
		pSPM->spImageType=IMAGE_GRAY;

	if(pSPM->spMonoChannel==CHANNEL_TRUE_Matrix)
		pSPM->spImageType=IMAGE_GRAY;

	if(pSPM->spDualscan!=0) {
		//sprintf(strtmp,"Duo_out%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
		sprintf(strtmp,"Duo_ous%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
		if ((fpout=fopen(strtmp,"wb")) == NULL) {
			printf("......File open error!!!\n");
			return False;
		}
		//sprintf(strtmp,"Duo_ous%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
		sprintf(strtmp,"Duo_out%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));		
		if ((fpout2=fopen(strtmp,"wb")) == NULL) {
			printf("......File open error!!!\n");
			return False;
		}
	} else {
		if(pSPM->spSimplexSide==0) { //Flatbedscan or spSimplexSide main engine scan(bottom)
			//sprintf(strtmp,"out%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
			sprintf(strtmp,"ous%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
			if ((fpout=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
		} else { //spSimplexSide = 1 secondary engine(Top)
			sprintf(strtmp,"out%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));			
			//sprintf(strtmp,"ous%d_x%d_y%d_b%d.raw", scanidx, pSPM->spScanLinePixels, pSPM->spTotalScanLines , pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1));
			if ((fpout2=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
		}
	}

	dwLineSize = pSPM->spScanLinePixels * pSPM->spPixelDepth*((pSPM->spImageType==IMAGE_COLOR) ? 3:1)/8;

	tl_readLn1=0; chk1=0; ScanCnt1=0xffffff;
	tl_readLn2=0; chk2=0; ScanCnt2=0xffffff;
	if(pSPM->spDualscan!=0) {
		fsh1=0;	fsh2=0;
	} else {
		if(pSPM->spSimplexSide==0) {
			fsh1=0;	fsh2=1;
		} else {
			fsh1=1;	fsh2=0;
		}
	}

	/////////////////////////////////////////////////////////////////
	while(1) {
		if ((fsh1==1)&&(fsh2==1)) break;
		///////////////////////////////////////////////
		if (fsh1==0) {
			CMDASIC_ReadFourRegister(0x0408,&ValidLine);
			if(chk1==0) {
				raw_jpg_page = ValidLine & 0x80000000; 
				if (raw_jpg_page) {
					chk1=1;
					CMDASIC_ReadBus(0xb0004000, &ScanCnt1);     //total line
					//printf("\n raw_jpg_page1=0x%08x, ScanCnt1=%d tl_readLn1=%d\n",raw_jpg_page,ScanCnt1, tl_readLn1);
					if (tl_readLn1 == ScanCnt1) {
						//printf("\n c finish tl_readLn1=%d, ScanCnt1=%d \n",tl_readLn1,ScanCnt1);
						fsh1=1;
						continue; 
					}
				}

			}
			ValidLine &= 0x001fffff;
			if(ValidLine!=0) {
				readlen = (ValidLine > RdOnceLine) ? RdOnceLine : ValidLine;
					if (chk1==1) {
						readlen = ((ScanCnt1-tl_readLn1)>readlen) ? readlen : (ScanCnt1-tl_readLn1);
				}
				bRet=ReadRawImage(RdBuffer,readlen*dwLineSize);  
				if(!bRet) 
					break;
				if(fwrite(RdBuffer,sizeof(char), dwLineSize*readlen , fpout) < 0) {
					printf("......File write error!!!\n");
					bRet=False;
					break;
				}
				CMDASIC_WriteFourRegister(0x0408,readlen);  //clear validline
				//printf(" tl_readLn1=%d, readlen1=%d, validline1=%d \n",tl_readLn1, readlen, ValidLine);
				tl_readLn1 += readlen; 
				if (tl_readLn1 == ScanCnt1) {
					//printf("\n finish tl_readLn1=%d, ScanCnt1=%d \n",tl_readLn1,ScanCnt1);
					fsh1=1;
					continue; 
				}

			}
		}  //if (fsh1==0) {

		if (fsh2==0) {
			CMDASIC_ReadFourRegister(0x0a08,&ValidLine);
			if(chk2==0) {
				raw_jpg_page = ValidLine & 0x80000000; 
				if (raw_jpg_page) {
					chk2=1;
					CMDASIC_ReadBus(0xb0006000, &ScanCnt2);     //total line
					//printf("\n raw_jpg_page2=0x%08x, ScanCnt2=%d tl_readLn2=%d\n",raw_jpg_page,ScanCnt2, tl_readLn2);
					if (tl_readLn2 == ScanCnt2) {
						//printf("\n c finish tl_readLn2=%d, ScanCnt2=%d \n",tl_readLn2,ScanCnt2);
						fsh2=1;
						continue; 
					}
				}
			}
			ValidLine &= 0x001fffff;
			if(ValidLine!=0) {
				readlen = (ValidLine > RdOnceLine) ? RdOnceLine : ValidLine;
				if (chk2==1) {
					readlen = ((ScanCnt2-tl_readLn2)>readlen) ? readlen : (ScanCnt2-tl_readLn2);
				}
				bRet=ReadRawImage_B(RdBuffer,readlen*dwLineSize);  
				if(!bRet) 
					break;
				if(fwrite(RdBuffer,sizeof(char), dwLineSize*readlen , fpout2) < 0) {
					printf("......File write error!!!\n");
					bRet=False;
					break;
				}
				CMDASIC_WriteFourRegister(0x0a08,readlen);  //clear validline
				//printf(" tl_readLn2=%d, readlen2=%d, validline2=%d \n",tl_readLn2, readlen, ValidLine);
				tl_readLn2 += readlen; 
				if (tl_readLn2 == ScanCnt2) {
					//printf("\n finish tl_readLn2=%d, ScanCnt2=%d \n",tl_readLn2,ScanCnt2);
					fsh2=1;
					continue; 
				}
			}
		}  //if (fsh2==0) 

		//if ADF scan check paper jam : CtlADF_CheckPaperJam

	}

	if(pSPM->spDualscan!=0) {
		fclose(fpout);
		fclose(fpout2);
	} else {
		if(pSPM->spSimplexSide==0)
			fclose(fpout);
		else
			fclose(fpout2);
	}
	/////////////////////////

	scanidx++;

	return True;
}
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
int CMDASIC_ReadBulkData(unsigned int wAddr,unsigned char *pData, unsigned int dwLen);

int ReadRawImage(unsigned char *Buf, unsigned int dwLen)
{
#if 0
	int bRet;
	bRet=CMDASIC_SetupBulkLength(0xB0100000, dwLen,0x08);
	if (!bRet) return False;
	return CMDIO_BulkRead(Buf, dwLen);
#endif
	CMDASIC_ReadBulkData(0xB0100000, Buf, dwLen);
	/*
	int bRet;
	unsigned int wtlen, total=dwLen;
	unsigned char *tmpbuf;
	tmpbuf=Buf;
	while(total) {
		wtlen = (total > 0x100000) ? 0x100000 : total ;
		bRet=CMDASIC_SetupBulkLength(0xB0100000, wtlen,0x08);
		if (!bRet) return False;
		bRet=CMDIO_BulkRead(tmpbuf, wtlen);
		if (!bRet) return False;		
		tmpbuf += wtlen;
		total -= wtlen;
	}
	return True;
	*/
}


int ReadRawImage_B(unsigned char *Buf, unsigned int dwLen)
{
#if 0
	int bRet;
	bRet=CMDASIC_SetupBulkLength(0xB0200000, dwLen,0x08);
	if (!bRet) return False;
	return CMDIO_BulkRead(Buf, dwLen);
#endif
	/*
	int bRet;
	unsigned int wtlen, total=dwLen;
	unsigned char *tmpbuf;
	tmpbuf=Buf;
	while(total) {
		wtlen = (total > 0x100000) ? 0x100000 : total ;
		bRet=CMDASIC_SetupBulkLength(0xB0200000, wtlen,0x08);
		if (!bRet) return False;
		bRet=CMDIO_BulkRead(tmpbuf, wtlen);
		if (!bRet) return False;		
		tmpbuf += wtlen;
		total -= wtlen;
	}
	return True;
	*/

}
