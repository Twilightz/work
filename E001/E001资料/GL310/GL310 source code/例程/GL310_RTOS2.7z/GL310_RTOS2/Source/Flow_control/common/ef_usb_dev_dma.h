/***************************************************************************
* Name: ef_usb_dev_dma.h                                                   *
* Description: event flow usb dev dma header                   	           *
*																		   *
*																		   *
* Author: John KE      				                                       *
* Date: 2013/10/25	                                                       *
****************************************************************************/
#ifndef _HEADER_EF_USB_DMA_IO_
#define _HEADER_EF_USB_DMA_IO_

#include "dtype.h"



#endif
