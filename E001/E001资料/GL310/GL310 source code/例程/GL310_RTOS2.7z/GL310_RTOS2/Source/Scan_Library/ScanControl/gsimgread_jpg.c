
////////////////////////////////////////////////////////////////
// File - gsimgread.c
// Copyright (c) 2011 - Genesys Logic, INC.
////////////////////////////////////////////////////////////////

//#include <Windows.h>
#include "..\asiccmd\asiccmd.h"
#include "..\asiccmd\gusrdef.h"
#include "..\asiccontrol\giasiccontrol.h"
//#include "gscanctrl.h"

int ResetJPGImgAdr(void);
int ResetJPGthumbImgAdr(void);
int ReadJPGImage(unsigned char *Buf, unsigned int dwLen);
int ReadJPGImage_B(unsigned char *Buf, unsigned int dwLen);
int ReadJPGthumbImage(unsigned char *Buf, unsigned int dwLen);
int ReadJPGthumbImage_B(unsigned char *Buf, unsigned int dwLen);

//unsigned int Jpeg_curadr=Jpeg_stradr;
//unsigned int Jpeg_thumb_curadr=Jpeg_thumb_str;
//unsigned int Jpeg_curadr_B=Jpeg_stradr_B;
//unsigned int Jpeg_thumb_curadr_B=Jpeg_thumb_str_B;
unsigned int Jpeg_curadr;
unsigned int Jpeg_thumb_curadr;
unsigned int Jpeg_curadr_B;
unsigned int Jpeg_thumb_curadr_B;

static int scanidx=0;

extern unsigned int RdBufSize;
extern unsigned char *RdBuffer;

////////////////////////////////////////////////////////////////
//  Read jpg image flow
//1. check until JpegValid !=0 
//2. read JpegValid size image from DDR
//3. clear JpegValid size
//4. check JPG page finish, 
//5. if JPG page finish, read total scan line & JPG image size
//6. repeat until total JPG image size read finish
////////////////////////////////////////////////////////////////

int Sctl_ReadScanData_JPG(ScanParameter *pSPM) 
{
	FILE *fpout, *fpout2;
	char strtmp[256]; 
	int bRet, fsh1, fsh2, chk1, chk2;
	unsigned int ScanCnt1, ScanCnt2, ScanCnttmp;
	unsigned int JpegValid, JpgImgSize1, JpgImgSize2, uRead, tl_read1, tl_read2, raw_jpg_page;
	unsigned int rdsize; 

	if((pSPM->spPixelDepth==1)||(pSPM->spPixelDepth==16)) {
		printf("......JPG don't support 1 or 16bit data!!!\n");
		return False;
	}
	if(pSPM->spMonoChannel==CHANNEL_TRUE_Matrix)
		pSPM->spImageType=IMAGE_GRAY;


	if(pSPM->spDualscan!=0) {
		sprintf(strtmp,"JPG_%03d_A_%d.jpg",scanidx,solu);
		if ((fpout=fopen(strtmp,"wb")) == NULL) {
			printf("......File open error!!!\n");
			return False;
		}
		sprintf(strtmp,"JPG_%03d_B_%d.jpg",scanidx,solu);
		if ((fpout2=fopen(strtmp,"wb")) == NULL) {
			printf("......File open error!!!\n");
			return False;
		}
	} else {
		if(pSPM->spSimplexSide==0) {
		sprintf(strtmp,"JPG_%03d_SA_%d.jpg",scanidx,solu);
			if ((fpout=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
		} else {
		sprintf(strtmp,"JPG_%03d_SB_%d.jpg",scanidx,solu);
			if ((fpout2=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
		}
	}


	tl_read1=0; chk1=0; JpgImgSize1=0xffffff;
	tl_read2=0; chk2=0; JpgImgSize2=0xffffff;
	if(pSPM->spDualscan!=0) {
		fsh1=0;	fsh2=0;
	} else {
		if(pSPM->spSimplexSide==0) {
			fsh1=0;	fsh2=1;
		} else {
			fsh1=1;	fsh2=0;
		}
	}
		
	/////////////////////////////////////////////////////////////////
	while(1) {
		if ((fsh1==1)&&(fsh2==1)) break;
		///////////////////////////////////////////////
		if (fsh1==0) {
			CMDASIC_ReadFourRegister(0x03d4,&JpegValid);  //Jpeg_Valid_size
			uRead = (JpegValid & 0x7fffffff);
			if(chk1==0) {
				raw_jpg_page = JpegValid & 0x80000000;
				if (raw_jpg_page) {
					chk1=1;
					CMDASIC_ReadBus(0xb0004000, &ScanCnt1);     //total line
					CMDASIC_ReadBus(0xb0004800, &JpgImgSize1);  //total image size
					//printf(" raw_jpg_page1=0x%08x, ScanCnt1=%d, JpgImgSize1=%d \n",raw_jpg_page,ScanCnt1,JpgImgSize1);
					if (tl_read1 == JpgImgSize1) {
						//printf(" finish tl_read1=%d, JpgImgSize1=%d \n",tl_read1,JpgImgSize1);
						fsh1=1;
						continue; 
					}
				}
			}
			if(uRead!=0) {
				rdsize = (uRead<RdBufSize) ? uRead : RdBufSize;
				if (chk1==1) {
					rdsize = ((JpgImgSize1-tl_read1)>rdsize) ? rdsize : (JpgImgSize1-tl_read1);
				}
				bRet=ReadJPGImage(RdBuffer,rdsize); 
				if(!bRet) 
					break;
				if(fwrite(RdBuffer,sizeof(char), rdsize , fpout) < 0) {
					printf("......File write error!!!\n");
					bRet=False;
					break;
				}
				//printf(" total1=%d, read=%d, valid=%d \n",tl_read1, rdsize, uRead);
				CMDASIC_WriteFourRegister(0x03dc,rdsize);  //Clear_Jpeg_size
				tl_read1 += rdsize; 
				if (tl_read1 == JpgImgSize1) {
					//printf(" finish tl_read1=%d, JpgImgSize1=%d \n",tl_read1,JpgImgSize1);
					fsh1=1;
					continue;
				}
			}
		} //if (fsh1==0) {
		///////////////////////////////////////////////
		if (fsh2==0) {
			CMDASIC_ReadFourRegister(0x09d4,&JpegValid);  //Jpeg_Valid_size
			uRead = (JpegValid & 0x7fffffff);
			if(chk2==0) {
				raw_jpg_page = JpegValid & 0x80000000;
				if (raw_jpg_page) {
					chk2=1;
					CMDASIC_ReadBus(0xb0006000, &ScanCnt2);     //total line
					CMDASIC_ReadBus(0xb0006800, &JpgImgSize2);  //total image size
					//printf(" raw_jpg_page2=0x%08x, ScanCnt2=%d, JpgImgSize2=%d \n",raw_jpg_page,ScanCnt2,JpgImgSize2);
					if (tl_read2 == JpgImgSize2) {
						//printf(" finish tl_read2=%d, JpgImgSize2=%d \n",tl_read2,JpgImgSize2);
						fsh2=1;
						continue;
					}
				}
			}
			if(uRead!=0) {
				rdsize = (uRead<RdBufSize) ? uRead : RdBufSize;
				if (chk2==1) {
					rdsize = ((JpgImgSize2-tl_read2)>rdsize) ? rdsize : (JpgImgSize2-tl_read2);
				}
				bRet=ReadJPGImage_B(RdBuffer,rdsize); 
				if(!bRet) 
					break;
				if(fwrite(RdBuffer,sizeof(char), rdsize , fpout2) < 0) {
					printf("......File write error!!!\n");
					bRet=False;
					break;
				}
				//printf(" total2=%d, read=%d, valid=%d \n",tl_read2, rdsize, uRead);
				CMDASIC_WriteFourRegister(0x09dc,rdsize);  //Clear_Jpeg_size
				tl_read2 += rdsize; 
				if (tl_read2 == JpgImgSize2) {
					//printf(" finish tl_read2=%d, JpgImgSize2=%d \n",tl_read2,JpgImgSize2);
					fsh2=1;
					continue;
				}
			}
		} //if (fsh2==0) 
		//if ADF scan check paper jam : CtlADF_CheckPaperJam

	}
	/////////////////////////////////////////////////////////////////

	if(!bRet) {
		fclose(fpout); fclose(fpout2); return False;
	}

	if(pSPM->spDualscan!=0) {

		//modify JPG length
		fseek(fpout,((pSPM->spImageType==IMAGE_COLOR)?0xe6:0x64),SEEK_SET);
		ScanCnttmp= (((ScanCnt1-7)&0x00ff)<<8)|(((ScanCnt1-7)&0xff00)>>8);
		fwrite((unsigned char *)&ScanCnttmp,sizeof(char), 2 , fpout);
		fclose(fpout);

		//modify JPG length
		fseek(fpout2,((pSPM->spImageType==IMAGE_COLOR)?0xe6:0x64),SEEK_SET);
		ScanCnttmp= (((ScanCnt2-7)&0x00ff)<<8)|(((ScanCnt2-7)&0xff00)>>8);
		fwrite((unsigned char *)&ScanCnttmp,sizeof(char), 2 , fpout2);
		fclose(fpout2);

	} else {

		if(pSPM->spSimplexSide==0) {
			//modify JPG length
			fseek(fpout,((pSPM->spImageType==IMAGE_COLOR)?0xe6:0x64),SEEK_SET);
			ScanCnttmp= (((ScanCnt1-7)&0x00ff)<<8)|(((ScanCnt1-7)&0xff00)>>8);
			fwrite((unsigned char *)&ScanCnttmp,sizeof(char), 2 , fpout);
			fclose(fpout);
		} else {
			//modify JPG length
			fseek(fpout2,((pSPM->spImageType==IMAGE_COLOR)?0xe6:0x64),SEEK_SET);
			ScanCnttmp= (((ScanCnt2-7)&0x00ff)<<8)|(((ScanCnt2-7)&0xff00)>>8);
			fwrite((unsigned char *)&ScanCnttmp,sizeof(char), 2 , fpout2);
			fclose(fpout2);
		}

	}

	/////////////////////////
	//thumb enable.
	if(pSPM->spJPEGENC&0x08) {

		if(pSPM->spDualscan!=0) {
			sprintf(strtmp,"Thumb_%03d_A.jpg",scanidx);
			if ((fpout=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
			sprintf(strtmp,"Thumb_%03d_B.jpg",scanidx);
			if ((fpout2=fopen(strtmp,"wb")) == NULL) {
				printf("......File open error!!!\n");
				return False;
			}
		} else {
			if(pSPM->spSimplexSide==0) {
				sprintf(strtmp,"Thumb_%03d_A.jpg",scanidx);
				if ((fpout=fopen(strtmp,"wb")) == NULL) {
					printf("......File open error!!!\n");
					return False;
				}
			} else {
				sprintf(strtmp,"Thumb_%03d_B.jpg",scanidx);
				if ((fpout2=fopen(strtmp,"wb")) == NULL) {
					printf("......File open error!!!\n");
					return False;
				}
			}
		}

		tl_read1=0; chk1=0; JpgImgSize1=0xffffff;
		tl_read2=0; chk2=0; JpgImgSize2=0xffffff;
		if(pSPM->spDualscan!=0) {
			fsh1=0;	fsh2=0;
		} else {
			if(pSPM->spSimplexSide==0) {
				fsh1=0;	fsh2=1;
			} else {
				fsh1=1;	fsh2=0;
			}
		}

		/////////////////////////////////////////////////////////////////
		while(1) {
			if ((fsh1==1)&&(fsh2==1)) break;
			///////////////////////////////////////////////
			if (fsh1==0) {
				CMDASIC_ReadFourRegister(0x03d8,&JpegValid);  //Jpeg_Valid_size
				uRead = (JpegValid & 0x7fffffff);
				if(chk1==0) {
					CMDASIC_ReadFourRegister(0x03d0,&raw_jpg_page);  //raw & jpg page number
					raw_jpg_page = raw_jpg_page & 0xffff0000;
					if (raw_jpg_page) {
						chk1=1;
						CMDASIC_ReadBus(0xb0004800, &JpgImgSize1);  //total image size
						//printf(" raw_jpg_page1=0x%08x, JpgImgSize1=%d \n",raw_jpg_page,JpgImgSize1);
						if (tl_read1 == JpgImgSize1) {
							//printf(" finish tl_read1=%d, JpgImgSize1=%d \n",tl_read1,JpgImgSize1);
							fsh1=1;
							continue; 
						}
					}
				}
				if(uRead!=0) {
					rdsize = (uRead<RdBufSize) ? uRead : RdBufSize;
					if (chk1==1) {
						rdsize = ((JpgImgSize1-tl_read1)>rdsize) ? rdsize : (JpgImgSize1-tl_read1);
					}
					bRet=ReadJPGthumbImage(RdBuffer,rdsize); 
					if(!bRet) 
						break;
					if(fwrite(RdBuffer,sizeof(char), rdsize , fpout) < 0) {
						printf("......File write error!!!\n");
						bRet=False;
						break;
					}
					//printf(" total1=%d, read=%d, valid=%d \n",tl_read1, rdsize, uRead);
					CMDASIC_WriteFourRegister(0x03e0,rdsize);  //Clear_Jpeg_size
					tl_read1 += rdsize; 
					if (tl_read1 == JpgImgSize1) {
						//printf(" finish tl_read1=%d, JpgImgSize1=%d \n",tl_read1,JpgImgSize1);
						fsh1=1;
						continue;
					}
				}
			} //if (fsh1==0) {
			///////////////////////////////////////////////
			if (fsh2==0) {
				CMDASIC_ReadFourRegister(0x09d8,&JpegValid);  //Jpeg_Valid_size
				uRead = (JpegValid & 0x7fffffff);
				if(chk2==0) {
					CMDASIC_ReadFourRegister(0x09d0,&raw_jpg_page);  //raw & jpg page number
					raw_jpg_page = raw_jpg_page & 0xffff0000;
					if (raw_jpg_page) {
						chk2=1;
						CMDASIC_ReadBus(0xb0006800, &JpgImgSize2);  //total image size
						//printf(" raw_jpg_page2=0x%08x, JpgImgSize2=%d \n",raw_jpg_page,JpgImgSize2);
						if (tl_read2 == JpgImgSize2) {
							//printf(" finish tl_read2=%d, JpgImgSize2=%d \n",tl_read2,JpgImgSize2);
							fsh2=1;
							continue;
						}
					}
				}
				if(uRead!=0) {
					rdsize = (uRead<RdBufSize) ? uRead : RdBufSize;
					if (chk2==1) {
						rdsize = ((JpgImgSize2-tl_read2)>rdsize) ? rdsize : (JpgImgSize2-tl_read2);
					}	
					bRet=ReadJPGthumbImage_B(RdBuffer,rdsize); 
					if(!bRet) 
						break;
					if(fwrite(RdBuffer,sizeof(char), rdsize , fpout2) < 0) {
						printf("......File write error!!!\n");
						bRet=False;
						break;
					}
					//printf(" total2=%d, read=%d, valid=%d \n",tl_read2, rdsize, uRead);
					CMDASIC_WriteFourRegister(0x09e0,rdsize);  //Clear_Jpeg_size
					tl_read2 += rdsize; 
					if (tl_read2 == JpgImgSize2) {
						//printf(" finish tl_read2=%d, JpgImgSize2=%d \n",tl_read2,JpgImgSize2);
						fsh2=1;
						continue;
					}
				}
			} //if (fsh2==0) 

		}
		/////////////////////////////////////////////////////////////////

		if(!bRet) {
			fclose(fpout); fclose(fpout2); return False;
		}


		if(pSPM->spDualscan!=0) {
			fclose(fpout);
			fclose(fpout2);
		} else {
			if(pSPM->spSimplexSide==0)
				fclose(fpout);
			else
				fclose(fpout2);
		}
	}
	/////////////////////////

	scanidx++;

	return True;
}


////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

int ResetJPGImgAdr(void)
{
	Jpeg_curadr=Jpeg_stradr;
	Jpeg_curadr_B=Jpeg_stradr_B;
	return True;
}

int ResetJPGthumbImgAdr(void)
{
	Jpeg_thumb_curadr=Jpeg_thumb_str;
	Jpeg_thumb_curadr_B=Jpeg_thumb_str_B;
	return True;
}


int ReadJPGImage(unsigned char *Buf, unsigned int dwLen)
{
	int bRet;
	unsigned int itmp;

	if (dwLen <= (Jpeg_endadr-Jpeg_curadr)) {
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr, Buf, dwLen);
		if (!bRet) return False;

		Jpeg_curadr += dwLen;
		if(Jpeg_curadr==Jpeg_endadr) {
			Jpeg_curadr=Jpeg_stradr;
		}

	} else {
		itmp=Jpeg_endadr-Jpeg_curadr;
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr, Buf, itmp);
		if (!bRet) return False;

		Jpeg_curadr=Jpeg_stradr;
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr, Buf+itmp, (dwLen-itmp));
		if (!bRet) return False;

		Jpeg_curadr += (dwLen-itmp);

	}

	return True;

}

int ReadJPGImage_B(unsigned char *Buf, unsigned int dwLen)
{
	int bRet;
	unsigned int itmp;

	if (dwLen <= (Jpeg_endadr_B-Jpeg_curadr_B)) {
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr_B, Buf, dwLen);
		if (!bRet) return False;

		Jpeg_curadr_B += dwLen;
		if(Jpeg_curadr_B==Jpeg_endadr_B) {
			Jpeg_curadr_B=Jpeg_stradr_B;
			printf("full\n");
		}

	} else {
		itmp=Jpeg_endadr_B-Jpeg_curadr_B;
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr_B, Buf, itmp);
		if (!bRet) return False;

		Jpeg_curadr_B=Jpeg_stradr_B;
		bRet=CMDASIC_ReadBulkData(Jpeg_curadr_B, Buf+itmp, (dwLen-itmp));
		if (!bRet) return False;

		Jpeg_curadr_B += (dwLen-itmp);

	}
	return True;
}

int ReadJPGthumbImage(unsigned char *Buf, unsigned int dwLen)
{
	int bRet;
	unsigned int itmp;

	if (dwLen <= (Jpeg_thumb_end-Jpeg_thumb_curadr)) {
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr, Buf, dwLen);
		if (!bRet) return False;

		Jpeg_thumb_curadr += dwLen;
		if(Jpeg_thumb_curadr==Jpeg_thumb_end) {
			Jpeg_thumb_curadr=Jpeg_thumb_str;
		}

	} else {
		itmp=Jpeg_thumb_end-Jpeg_thumb_curadr;
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr, Buf, itmp);
		if (!bRet) return False;

		Jpeg_thumb_curadr=Jpeg_thumb_str;
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr, Buf+itmp, (dwLen-itmp));
		if (!bRet) return False;
		Jpeg_thumb_curadr += (dwLen-itmp);

	}

	return True;

}


int ReadJPGthumbImage_B(unsigned char *Buf, unsigned int dwLen)
{
	int bRet;
	unsigned int itmp;

	if (dwLen <= (Jpeg_thumb_end_B-Jpeg_thumb_curadr_B)) {
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr_B, Buf, dwLen);
		if (!bRet) return False;

		Jpeg_thumb_curadr_B += dwLen;
		if(Jpeg_thumb_curadr_B==Jpeg_thumb_end_B) {
			Jpeg_thumb_curadr_B=Jpeg_thumb_str_B;
			printf("full\n");
		}

	} else {
		itmp=Jpeg_thumb_end_B-Jpeg_thumb_curadr_B;
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr_B, Buf, itmp);
		if (!bRet) return False;

		Jpeg_thumb_curadr_B=Jpeg_thumb_str_B;
		bRet=CMDASIC_ReadBulkData(Jpeg_thumb_curadr_B, Buf+itmp, (dwLen-itmp));
		if (!bRet) return False;
		Jpeg_thumb_curadr_B += (dwLen-itmp);

	}

	return True;

}