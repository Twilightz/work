#ifndef _SPIFUN_H_
#define _SPIFUN_H_

#include "spi_ctrl.h"



#define	bmWIP			0x01
#define	bmQuad_MXIC		0x40


#define SPIWrPgSize     256
#define noSFlashType    10





UINT32 SPIC_WR(UINT32 StartAddr, UINT8 *WriteBuf, UINT32 WriteLen, spicmap *smap); 
UINT32 SPIC_RD(UINT32 StartAddr, UINT8 *ReadBuf, UINT32 ReadLen, spicmap *smap);
void SPIC_BE(UINT32 BlockAddr,  spicmap *smap);
void SPIC_CE(spicmap *smap);
void SPIC_buf_Initialize(void);
void SPIC_BlkUnProctect(spicmap *smap);
void SPIC_BlkProctect(spicmap *smap);
void SPIC_hw_unProctect(spicmap *smap);
void SPIC_hw_Proctect(spicmap *smap);
void SPIC_ProctectBits(UINT8 ProtectBits, spicmap *smap);
void SPIC_RDID(UINT8 *VID, UINT8 *PID, spicmap *smap);
#endif 
