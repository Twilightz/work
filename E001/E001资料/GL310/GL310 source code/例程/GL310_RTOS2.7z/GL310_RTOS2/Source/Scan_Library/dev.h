
#ifndef _dev_h_
#define _dev_h_

#include "cmd.h"

#define dev_sensor_motor_select(adf)	set_gpio40(adf)

#endif //_dev_h_
