//=======================================
//	File: uDebug.h
//	Note: debug message definition
//	Date: 2014.07.01
//=======================================
#ifndef	_uDebug_h_
#define	_uDebug_h_
//=======================================
#include <stdio.h>

//#define CANOPUS_COM2
#define MAX_COM_BAUDRATE	// 115200
//#define BULKCMD_SIMULATE
#define EMBEDDED_ARM		// not PC

// measurement with GL310-ARM9-120MHz
#define DELAY_US(us)	{int i; for(i = 0; i < ((us)*13282/1000); i++);}while(0)

#if 1
#   define dprintf(...)     printf(__VA_ARGS__)
#else
#   define dprintf(...)
#endif

//=====================================
#endif	// _uDebug_h_
//=====================================
