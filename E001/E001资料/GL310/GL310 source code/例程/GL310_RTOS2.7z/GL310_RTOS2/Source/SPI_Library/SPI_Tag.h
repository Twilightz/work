#ifndef _SPITAG_H_
#define _SPITAG_H_
 
#include "spi_lib.h"

typedef struct _VPID_FORM{
    
  UINT8 Len;
  UINT8 Signature;  
  UINT16 VID;
  UINT16 PID;
    
}VPID_FORM;

#ifdef _SPI_TX
// _SPI_TX define in SPI_CTRL.H

#define SPI_TagIDGet            MT_SPI_TagIDGet 
#define SPI_TagIDRelease        MT_SPI_TagIDRelease
#define SPI_TagEraseIndex       MT_SPI_TagEraseIndex
#define SPI_TagEraseAll         MT_SPI_TagEraseAll
#define SPI_TagDataWrite        MT_SPI_TagDataWrite
#define SPI_TagDataRead         MT_SPI_TagDataRead
#define SPI_TagInfoRead         MT_SPI_TagInfoRead
#define SPI_TagStringInquiry    MT_SPI_TagStringInquiry
#define SPI_ImageUpdateInitial  MT_SPI_ImageUpdateInitial
#define SPI_SetBootImageTag     MT_SPI_SetBootImageTag
#define SPI_FetchBootTagID      MT_SPI_FetchBootTagID
#define SPI_BackupBootTag       MT_SPI_BackupBootTag
#define SPI_chg_venderstr       MT_SPI_chg_venderstr
#define SPI_chg_productstr      MT_SPI_chg_productstr
#define SPI_chg_serialstr       MT_SPI_chg_serialstr
#define SPI_chg_VPID            MT_SPI_chg_VPID
#define SPI_Protect             MT_SPI_Protect
#define SPI_hw_Write_Protect    MT_SPI_hw_Write_Protect
#define SPI_GetFreeBlockNum     MT_SPI_GetFreeBlockNum
#define SPI_Tag_RDID            MT_SPI_RDID

 

#else 

#define SPI_TagIDGet            tag_SPI_TagIDGet
#define SPI_TagIDRelease        tag_SPI_TagIDRelease
#define SPI_TagEraseIndex       tag_SPI_TagEraseIndex
#define SPI_TagEraseAll         tag_SPI_TagEraseAll
#define SPI_TagDataWrite        tag_SPI_TagDataWrite
#define SPI_TagDataRead         tag_SPI_TagDataRead
#define SPI_TagInfoRead         tag_SPI_TagInfoRead
#define SPI_TagStringInquiry    tag_SPI_TagStringInquiry
#define SPI_ImageUpdateInitial  tag_SPI_ImageUpdateInitial
#define SPI_SetBootImageTag     tag_SPI_SetBootImageTag
#define SPI_FetchBootTagID      tag_SPI_FetchBootTagID
#define SPI_BackupBootTag       tag_SPI_BackupBootTag
#define SPI_chg_venderstr       tag_SPI_chg_venderstr
#define SPI_chg_productstr      tag_SPI_chg_productstr
#define SPI_chg_serialstr       tag_SPI_chg_serialstr
#define SPI_chg_VPID            tag_SPI_chg_VPID
#define SPI_Protect             tag_SPI_Protect
#define SPI_hw_Write_Protect    tag_SPI_hw_Write_Protect
#define SPI_GetFreeBlockNum     tag_SPI_GetFreeBlockNum
#define SPI_Tag_RDID            tag_SPI_RDID

#endif

 
BOOL MT_SPI_TagIDGet(UINT8 *TagID, UINT16 BlockNum, INT8 *IDStr);
BOOL MT_SPI_TagIDRelease(UINT8 TagID);
BOOL MT_SPI_TagEraseIndex(UINT16 TagID, UINT16 Index);
BOOL MT_SPI_TagEraseAll(UINT16 TagID);
BOOL MT_SPI_TagDataWrite(UINT16 TagID, UINT16 BlockIndex, UINT8 *WrBuf, UINT32 *checksum);
BOOL MT_SPI_TagDataRead(UINT16 TagID, UINT16 BlockIndex, UINT8 *RdBuf, UINT32 *checksum);
BOOL MT_SPI_TagInfoRead(UINT16 TagID, MemID_Tag **TagID_Info);
BOOL MT_SPI_TagStringInquiry(UINT8 *TagID, INT8 *IDStr);
BOOL MT_SPI_ImageUpdateInitial(void);
BOOL MT_SPI_SetBootImageTag(UINT8 ImageTagID);
BOOL MT_SPI_FetchBootTagID(UINT8 *TagID);
BOOL MT_SPI_BackupBootTag(UINT8 TagID);
BOOL MT_SPI_chg_venderstr(INT8 *vdrstr);
BOOL MT_SPI_chg_productstr(INT8 *prodstr);
BOOL MT_SPI_chg_serialstr(INT8 *serilstr); 
BOOL MT_SPI_chg_VPID(VPID_FORM *VPIDstr);
BOOL MT_SPI_Protect(UINT8 bEnable);
BOOL MT_SPI_GetFreeBlockNum(UINT32 *freeBlkNum); 
BOOL MT_SPI_hw_Write_Protect(UINT8 Enable);
BOOL MT_SPI_RDID(UINT8 *VID, UINT8 *PID);

 
/* The tag subroutine use in no multi_task(no os) only */
BOOL tag_SPI_TagIDGet(UINT8 *TagID, UINT16 BlockNum, INT8 *IDStr);
BOOL tag_SPI_TagIDRelease(UINT8 TagID);
BOOL tag_SPI_TagEraseIndex(UINT16 TagID, UINT16 Index);
BOOL tag_SPI_TagEraseAll(UINT16 TagID);
BOOL tag_SPI_TagDataWrite(UINT16 TagID, UINT16 BlockIndex, UINT8 *WrBuf, UINT32 *checksum);
BOOL tag_SPI_TagDataRead(UINT16 TagID, UINT16 BlockIndex, UINT8 *RdBuf, UINT32 *checksum);
BOOL tag_SPI_TagInfoRead(UINT16 TagID, MemID_Tag **TagID_Info);
BOOL tag_SPI_TagStringInquiry(UINT8 *TagID, INT8 *IDStr);
BOOL tag_SPI_ImageUpdateInitial(void);
BOOL tag_SPI_SetBootImageTag(UINT8 ImageTagID);
BOOL tag_SPI_FetchBootTagID(UINT8 *TagID);
BOOL tag_SPI_BackupBootTag(UINT8 TagID);
BOOL tag_SPI_chg_venderstr(INT8 *vdrstr);
BOOL tag_SPI_chg_productstr(INT8 *prodstr);
BOOL tag_SPI_chg_serialstr(INT8 *serilstr); 
BOOL tag_SPI_chg_VPID(VPID_FORM *VPIDstr);
BOOL tag_SPI_Protect(UINT8 bEnable);
BOOL tag_SPI_GetFreeBlockNum(UINT32 *freeBlkNum); 
BOOL tag_SPI_hw_Write_Protect(UINT8 Enable);
BOOL tag_SPI_RDID(UINT8 *VID, UINT8 *PID);

#endif 
