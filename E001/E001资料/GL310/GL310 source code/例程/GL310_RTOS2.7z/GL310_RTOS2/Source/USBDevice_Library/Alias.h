#ifndef _ALIAS_H
#define _ALIAS_H


//sysConfig
void USBDevDisConnect(void)         __attribute__((alias("UDev_DisConnect")));
void udev_InitUSBModule(void)       __attribute__((alias("UDev_Init_USBModule")));
void udev_RegDefaultCmdHdl(void)    __attribute__((alias("UDev_Reg_DefaultCmdHdl")));


//usrConfig
UINT8 udev_RegEvtHandler(UINT8, BOOL (*Hdl)())  __attribute__((alias("UDev_Reg_EvtHdl")));
BOOL Chg_Cfg_Intf_Endp_Desc(UINT8 aCstDesc[], BOOL)        __attribute__((alias("Chg_Cfg_Desc")));



BOOL usbdev_Isdevconnect(void)      __attribute__((alias("UDev_Chk_Connect")));

#endif

