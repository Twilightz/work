
#ifndef _sc_h_
#define _sc_h_

#include "dev.h"

int SC_test();

#endif //_sc_h_
