////////////////////////////////////////////////////////////////
// File - gusrdef.h
// Copyright (c) 2011 - Genesys Logic, INC.
//
// define the export defines and functions for gusrdef.c 
//
////////////////////////////////////////////////////////////////

#ifndef _gusrdef_h
#define _gusrdef_h
//#define Down_Speed

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "cmd.h"

extern unsigned int solu;//default

#define LEDEXP_SameTime 

#define Ref_W				92 //116-24 //56(300dpi) //5mm
#define Ref_H				146 //(2mm+4.16mm)/0.042

#define CIS_Lamp_T1	72 //see CIS spec
#define CIS_Lamp_T2	64

#define g_200_Exp  0.3375f
#define g_300_Exp  0.580f  //0.225f  //HL modify
//#define g_300_Exp  0.322f;
#define g_600_Exp  0.420f
#define g_1200_Exp 0.800f//0.81

//=================================
//Max Lamp 300 = 0.1928(3862 clk/pixel)
//Max Lamp 600 = 0.3828(1914 clk/pixel)
//Max Lamp 1200= 0.7728(964 clk/pixel)
//=================================
//Main Scan Engin A
#define g_300_LedR1 0.492  //0.1380  //HL modify
#define g_300_LedG1 0.491  //0.1500 
#define g_300_LedB1 0.321  //0.1000

#define g_600_LedR1 0.2500
#define g_600_LedG1 0.2800
#define g_600_LedB1 0.1800

#define g_1200_LedR1 0.4800
#define g_1200_LedG1 0.5200
#define g_1200_LedB1 0.3420

//Scan Engin B
#define g_300_LedR2 0.492
#define g_300_LedG2 0.491
#define g_300_LedB2 0.321

#define g_600_LedR2 0.3300
#define g_600_LedG2 0.3350
#define g_600_LedB2 0.2600

/*=======Duplex=======*/
//Duplex Scan Engin A
#define d_300_LedR1 0.492 
#define d_300_LedG1 0.491 
#define d_300_LedB1 0.321

#ifdef LEDEXP_SameTime
//Duplex Scan Engin B
	#define d_300_LedR2 0.492 
	#define d_300_LedG2 0.491 
	#define d_300_LedB2 0.321
#else
	#define d_300_LedR2 0.492
	#define d_300_LedG2 0.491
	#define d_300_LedB2 0.321
#endif

//Duplex Scan Engin A
#define d_600_LedR1 0.2280
#define d_600_LedG1 0.2500
#define d_600_LedB1 0.1720

#ifdef LEDEXP_SameTime
	//Duplex Scan Engin B
	#define d_600_LedR2 0.2280
	#define d_600_LedG2 0.2500
	#define d_600_LedB2 0.1720
#else
	#define d_600_LedR2 0.3150
	#define d_600_LedG2 0.3570
	#define d_600_LedB2 0.2340
#endif

#define COLOR_CHANNELS			(3)
#define DDR_64M
//#define DDR_128M
//#define DDR_256M
extern unsigned int memuse_start;
extern unsigned int memuse_size;

extern unsigned int DualOffset;
extern unsigned int Jpeg_stradr, Jpeg_endadr;
extern unsigned int Jpeg_stradr_B, Jpeg_endadr_B;

extern unsigned int Jpg_thumb_size;
extern unsigned int Jpg_thumb_YCbCr_size;
extern unsigned int Jpeg_thumb_scale_xy;
extern unsigned int Jpeg_thumb_ymax;

extern unsigned int Jpeg_thumb_str, Jpeg_thumb_end;
extern unsigned int Jpeg_thumb_ystr, Jpeg_thumb_cbstr, Jpeg_thumb_crstr;
extern unsigned int Jpeg_thumb_str_B, Jpeg_thumb_end_B;

#define Word				WORD
#define DWord				DWORD
#define Byte				BYTE
#define Quad				DWORD
#define HiByte(word)   ((unsigned char)((unsigned short)(word) >> 8 ))
#define LoByte(word)   ((unsigned char)(word))
#define HiWord(quad)   ((unsigned short)((unsigned int)(quad) >> 16 ))
#define LoWord(quad)   ((unsigned short)(quad))
#define True 1
#define False 0

#define ROUND(fract)            ((Quad)((fract) + 0.5 ))

typedef enum { LAMP_FLATBED, LAMP_LIGHTBOX } eLampID;
typedef enum { IMAGE_COLOR, IMAGE_GRAY, IMAGE_LINEART } eImageType;
typedef enum { CHANNEL_RED, CHANNEL_GREEN, CHANNEL_BLUE, CHANNEL_TRUE_CISLED, CHANNEL_TRUE_Matrix } eChannel;
//typedef enum { STATUS_OPERATION, STATUS_IDLE, STATUS_SLEEP } eScannerStatus;
typedef enum { USB_10, USB_20 } flgUSBType;


#define MAX_PIXELES_PER_LINE 10800   //1200dpi max pixels

#define MAX_PATH          260

typedef struct {
	unsigned int	spScanBeginPixel;
	unsigned int	spScanBeginLine;
	unsigned int	spScanLinePixels;
	unsigned int    spTotalScanLines;
	unsigned short	spPixelResolution;
	unsigned short	spMotorResolution;
	unsigned char	spImageType;
	unsigned char	spMonoChannel;
	unsigned char	spPixelDepth;
	float			spExposureTime;
	float			spShutterTime[3];
	float			spShutterTime_B[3];
	unsigned char	spTimingIdx;
	unsigned char	spDummyLines;
	unsigned char	spStillMode;
	unsigned char	spAutoGoHome;
	unsigned char	spDisBackTrack;
	unsigned char	spShading;
	unsigned char	spGammaMapping;
	unsigned char	spCCDLMT;
	unsigned char	spTestImage;
	unsigned char	spADFscan;
	unsigned char	spDualscan;

	unsigned char	spSimplexSide;

	unsigned char	spJPEGENC;
	unsigned char   spMirror;
	unsigned char   spCCDPacking;
	//unsigned char   spScanerStatus; //Operation/Idel
} ScanParameter;

typedef struct {
	int TbLength;
	float *fPPSTable;
	int Vref;
	int UseStepUnit;
}MotorTableCfg;

typedef struct{
	unsigned short	gAFEOffsetCode[COLOR_CHANNELS];
	unsigned short	gAFEGainCode[COLOR_CHANNELS];
	unsigned short	gAFEOffsetCode_B[COLOR_CHANNELS];
	unsigned short	gAFEGainCode_B[COLOR_CHANNELS];
	float					gAFEOffsetValue[ COLOR_CHANNELS ];
	float					gAFEGainValue[ COLOR_CHANNELS ];
	float					gAFEOffsetValue_B[ COLOR_CHANNELS ];
	float					gAFEGainValue_B[ COLOR_CHANNELS ];

}AfeParameter;

void sleep(unsigned int wait);
unsigned int gettickcount(void);


#endif //_gusrdef_h