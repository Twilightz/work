#ifndef _i_job_h_
#define _i_job_h_
#ifdef __cplusplus
extern "C" {
#endif//__cplusplus
//-----------------
#include "sc_acquire.h"
#include "sc_image.h"
#include "sc_calibration.h"

//--------------------------------------
// input: img, pipe, duplex, expect.page;
// apply expect.line = -1 to initialize
// output expect.line for page end
#define MAX_VALID_SIZE	0x7fffffff
#define MAX_VALID_LINE	0x1fffff
#define MAX_VALID_PAGE	0x1ff
//--DATAFLOW.event ----------------------
#define EVENT_PAGE_COUNT_DOWN	0x1000
#define EVENT_DATA_SUBMIT		0x2000
#define EVENT_SCAN_END			0x0100
#define EVENT_PAGE_END			0x0200
#define EVENT_DOCUMENT_END		0x0400
#define EVENT_PIPE_ERROR		0x0010
#define EVENT_PAPER_JAM			0x0020
#define EVENT_BUTTON_PRESS		0x0001
//--------------------------------------

typedef struct DATA_FLOW_STRUCT {
	U32 event; U32 status;
	struct{U32 page; U32 line; U32 size;} expect;
	struct{U32 page; U32 size;} scanned;
	struct{U32 page; U32 size;} read;
	struct{U32 size;} reading;
	struct{U32 start; U32 end; U32 next;} mem;
} DATA_FLOW_T;

typedef struct JOB_SCAN_STRUCT {
	//--------------------------
	ACQUIRE_T	acq;
	IMAGE_T		img;
	//SHADING_T	shad;
	//U32			user[0x4000];	// 64KB
	//-------------------------
	struct {
		U32 auto_scan:1; U32 shading:1; U32 calibration:1; U32 gamma:1; U32 mirror:1;
		U32 start_home:1; U32 back_track:1; U32 auto_go_home:1;
		U32 eject_paper:1; U32 pickup_home:1;
		U32 still_scan:1; U32 test_pattern:1;
		U32 runin_image; U32 runin; 
	} action;
	struct {
		U32 start;
		U32 end;
		U32 next;
	} mem;
	DATA_FLOW_T data[2];
	//-------------------------
} JOB_SCAN_T;

int sc_Init(void *par, int size);
int sc_SetParameter(void *par, int size);
U32 sc_ReadData(int dup, int *size);
//-----------------
#ifdef __cplusplus
}
#endif//__cplusplus
#endif//_i_job_h_
