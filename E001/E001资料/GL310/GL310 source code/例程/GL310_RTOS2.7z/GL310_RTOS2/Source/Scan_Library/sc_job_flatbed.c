//-------------------
//	File: sc_job_flatbed.c
//	Date: 2014.07.31
//-------------------
#include "os_api.h"
//#include "sc_api.h"
#include "cmd.h"	//"i_GL310.h"
#include "sc_job.h"
#include ".\AsicCmd\gusrdef.h"
#include ".\asiccmd\asiccmd.h" 
#include ".\asiccontrol\giafe.h"



//-----------------------------------
int PWR_OperationMode(ScanParameter *pSPM);	//gibeng.c
int CtlADF_SetADFSEL(unsigned char bEnable); //giadf.c
int Sctl_CheckADFPaperReady(int *status);	//gscontrol.c
int Sctl_SetScanParameter(ScanParameter *pSPM);	//gscontrol.c
int CtlAfe_SetAFEGain(unsigned short GainR, unsigned short GainG, unsigned short GainB); //giafe.c
int CtlAfe_SetAFEOffset(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB); //giafe.c
int CtlAfe_SetAFEGain_B(unsigned short GainR, unsigned short GainG, unsigned short GainB); //giafe.c
int CtlAfe_SetAFEOffset_B(unsigned short OffsetR, unsigned short OffsetG, unsigned short OffsetB); //giafe.c
int CtlImage_WriteShadingFile(char* main_file, char* sub_file); //gishdgma.c
int CtlImage_WriteShadingFile_SimplexscanFlag(char* shading_file); //gishdgma.c
int CtlADF_LEDPWR(unsigned char nEnable); //giadf.c
int Sctl_StartScan(ScanParameter *pSPM); //gscontrol.c
int Sctl_ReadScanData_JPG(ScanParameter *pSPM); //gsimgread.c
int Sctl_ReadScanData_RAW(ScanParameter *pSPM); //gsimgeread_raw.c
int Sctl_StopScan(ScanParameter *pSPM); //gscontrol.c
int CtlADF_CheckPaperJam(int *jam); //giadf.c
int Sctl_CheckADFScanFinish(ScanParameter *pSPM, int *status);
int Sctl_StopScan(ScanParameter *pSPM); //gscontrol.c
int CtlMotor_WaitMotorStop(void); //gimotor.c
int Sctl_MoveMotor(float fpps, unsigned int Steps, int iDir);//gscontrol.c
int Sctl_MoveMotor(float fpps, unsigned int Steps, int iDir);//gscontrol.c
//----------------------------------------
extern unsigned int DuplexscanFlag;

//int mEngineScan = 0;
extern int mEngineScan;	// change to define in gscontrol.c
unsigned short POSY;
unsigned short POSX;
//unsigned short POSX_200;

char strtmp[MAX_PATH]; 

extern int CtlImage_WriteShadingFile(char* main_file, char* sub_file);
extern int Running_Test;
extern int disable_output_images;
extern int Scan_Count;
extern float g_Exp, g_LedR1, g_LedG1, g_LedB1, g_LedR2, g_LedG2, g_LedB2;
//extern unsigned short g_GainR, g_GainG, g_GainB, g_OffR, g_OffG, g_OffB;
//extern unsigned short g_GainR_B, g_GainG_B, g_GainB_B, g_OffR_B, g_OffG_B, g_OffB_B;
extern float g_Exp; 
extern float gLightOnTime[3];
//extern float gLightOnTime_B[3];
extern unsigned short AFEGainCode[3];
extern unsigned short AFEOffsetCode[3];
//extern unsigned short AFEGainCode_B[3];
//extern unsigned short AFEOffsetCode_B[3];
extern unsigned char  DoCalibrationFlag;
extern unsigned short wLEDLAMPEXP[3];
//extern unsigned short wLEDLAMPEXP_B[3];
extern float CtlDevice_PixelTime;
extern int iEnableShading;
extern int ScanfromHome;
extern int ScanRefMark;

//extern unsigned short	x_axis;
//extern unsigned short	y_axis;

//extern unsigned long	reg_0xac, reg_0xb0, reg_0xb4;

//----------------------------------------------------------------
extern int CtlImage_WriteShadingFile(char* main_file, char* sub_file);
extern unsigned short AFEGainCode[3];
extern unsigned short AFEOffsetCode[3];
extern unsigned short AFEGainCode_B[3];
extern unsigned short AFEOffsetCode_B[3];

extern float CtlDevice_PixelTime;

static ScanParameter SPM;
extern int iEnableShading;	// main.c

int ReadFileCalibartionData(ScanParameter *pSPM)
{
	int bRet=1;

	FILE *botout0, *botout1, *botout2; 
	FILE *topout0, *topout1, *topout2; //Dualscan 

	switch(solu)
	{
		case 200:
			AFEGainCode[0] = AFEGainCode[1] = AFEGainCode[2] = gGainR_300;
			AFEOffsetCode[0]=AFEOffsetCode[1]=AFEOffsetCode[2] = gOffR_300;
			pSPM->spShutterTime[0]  = g_300_LedR1;
			pSPM->spShutterTime[1]  = g_300_LedG1;
			pSPM->spShutterTime[2]  = g_300_LedB1;
			break;

		case 300:
			AFEGainCode[0] = AFEGainCode[1] = AFEGainCode[2] = 0x37;	//gGainR_300;
			AFEOffsetCode[0] = AFEOffsetCode[1] = AFEOffsetCode[2] = 0xb0;	//gOffR_300;
			pSPM->spShutterTime[0]  = g_300_LedR1;
			pSPM->spShutterTime[1]  = g_300_LedG1;
			pSPM->spShutterTime[2]  = g_300_LedB1;
			break;

		case 600:
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=gGainR_600;
			AFEOffsetCode[0] = AFEOffsetCode[1] = 	AFEOffsetCode[2] = gOffR_600;
			pSPM->spShutterTime[0] = g_600_LedR1;
			pSPM->spShutterTime[1] = g_600_LedG1;
			pSPM->spShutterTime[2] = g_600_LedB1;
			break;

		case 1200: //Flat Bed
			AFEGainCode[0]=AFEGainCode[1]=AFEGainCode[2]=gGainR_1200;
			AFEOffsetCode[0]=AFEOffsetCode[1]=AFEOffsetCode[2]=gOffR_1200;
			pSPM->spShutterTime[0] = g_1200_LedR1;
			pSPM->spShutterTime[1] = g_1200_LedG1;
			pSPM->spShutterTime[2] = g_1200_LedB1;
			break;
	}
	return True;
}

int FLB_SetParameter(JOB_SCAN_T *job)
{
	int bRet=1;
	int isADFScanFinish=False;
	//ScanParameter SPM;
	short fnamex[256], fnamey[256];
	FILE *IniFile; 
	//FILE	*topout0, *topout1, *topout2;
	//unsigned int filelen;
	unsigned short data;
	unsigned char nVal;
	//--------------
	U16 x_axis, y_axis;	// reference mark position
	//--------------
	//Read file Ref.
	x_axis = 5000;
	y_axis = 0;
	
	POSX = x_axis + (4-(x_axis%4))+Ref_W;
	POSY = ((y_axis+Ref_H)*100)/24;

	dprintf("Ref. POSX =%d, POSY=%d\n", POSX, POSY);

	solu = job->img.dpi.x;
	SPM.spScanBeginPixel = job->img.org.x;	            //scan begin x way postion

//HL modify	
//first 59pixel dummy black
	SPM.spScanBeginPixel = 59 * 2400 / 300;
	
	
	SPM.spScanBeginLine = job->img.org.y;	            //scan begin y way postion
	iEnableShading = job->action.shading;
	DuplexscanFlag = 0;
	mEngineScan = 1;

	//SPM.spScanBeginPixel = 0; //POSX;	            //scan begain x way postion
	
	//if(!job->action.start_home)
	//	SPM.spScanBeginLine += 3300;	//+POSY;//1115;        //scan begin y way postion(scan from window) 
	//else
	//	SPM.spScanBeginLine = 0;             //scan begin y way postion(scan from home)
	SPM.spTotalScanLines = job->img.dot.h;

	//300dpi setting
	switch(solu)
	{
		case 150:
			SPM.spScanLinePixels = CIS_TGEXP_150;   			//scan total x way pixels  
			//SPM.spTotalScanLines = 150*11.7; 		//scan total y way lines  
			SPM.spPixelResolution = 150;			// x way resolution
			SPM.spMotorResolution = 150;
			SPM.spTimingIdx	=		8;				//timing idex 1,2,4,8
			g_Exp  =g_300_Exp;
			gLightOnTime[0]=g_300_LedR1;
			gLightOnTime[1]=g_300_LedG1;
			gLightOnTime[2]=g_300_LedB1;
			break;

		case 200:
			if((POSX/3)%4)
				POSX = (POSX/3)+(4-(POSX/3)%4);
			else
				POSX =  (POSX/3);
			SPM.spScanLinePixels = job->img.dot.w;	//POSX;    					//scan total x way pixels  
			//SPM.spTotalScanLines = 200*11.7;								//scan total y way lines  			
			SPM.spPixelResolution = 200;											// x way resolution
			SPM.spMotorResolution = 200;										// y way resolution
			SPM.spTimingIdx =		8;													//timing idex 1,2,4,8
			g_Exp  =g_200_Exp;														//use 300dpi timing
			gLightOnTime[0]=g_300_LedR1;
			gLightOnTime[1]=g_300_LedG1;
			gLightOnTime[2]=g_300_LedB1;
			break;

		case 300:
			if((POSX/2)%4)
				POSX = POSX/2+(4-(POSX/2)%4);
			else
				POSX /=2;
			SPM.spScanLinePixels = job->img.dot.w; //POSX; //(CIS_TGEXP_300-POSX);    					//scan total x way pixels  
			//SPM.spTotalScanLines = 300*11.7;								//scan total y way lines  			
			SPM.spPixelResolution = 300;											// x way resolution
			SPM.spMotorResolution = 300;										// y way resolution
			SPM.spTimingIdx =		8;													//timing idex 1,2,4,8
			g_Exp  =g_300_Exp;
			gLightOnTime[0]=g_300_LedR1;
			gLightOnTime[1]=g_300_LedG1;
			gLightOnTime[2]=g_300_LedB1;
			break;

		case 600:
			SPM.spScanLinePixels = job->img.dot.w;	//POSX;    		//scan total x way pixels  
			//SPM.spTotalScanLines = 600*11.7;		//scan total y way lines  					
			SPM.spPixelResolution = 600;			// x way resolution
			SPM.spMotorResolution = 600;			// y way resolution
			SPM.spTimingIdx =		4;		//timing idex 1,2,4,8
			g_Exp  =g_600_Exp;
			gLightOnTime[0]=g_600_LedR1;
			gLightOnTime[1]=g_600_LedG1;
			gLightOnTime[2]=g_600_LedB1;
			break;

	case 1200:
			if((POSX*2)%4)
				POSX = POSX*2+(4-(POSX*2)%4);
			else
				POSX *=2;
			SPM.spScanLinePixels = job->img.dot.w;	//POSX;    		//scan total x way pixels  
			//SPM.spTotalScanLines = 1200*11.7;		//scan total y way lines  			
			SPM.spPixelResolution = 1200;			// x way resolution
			SPM.spMotorResolution = 1200;			// y way resolution	
			SPM.spTimingIdx =		2;		//timing idex 1,2,4,8
			g_Exp  =g_1200_Exp;
			gLightOnTime[0]=g_1200_LedR1;
			gLightOnTime[1]=g_1200_LedG1;
			gLightOnTime[2]=g_1200_LedB1;
			break;
	}

	switch(job->img.bit) {
		case 24:
			SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY	
			SPM.spPixelDepth =	8;					//pixel depth 8 or 16
			SPM.spCCDLMT = 2;
			break;
		case 8:
			SPM.spImageType = IMAGE_GRAY;			//IMAGE_COLOR or IMAGE_GRAY	
			SPM.spPixelDepth =	8;					//pixel depth 8 or 16
			SPM.spCCDLMT = 0;
			break;
		case 48:
			SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY 
			SPM.spPixelDepth =	16; 				//pixel depth 8 or 16
			SPM.spCCDLMT = 2;
			break;
		case 16:
			SPM.spImageType = IMAGE_GRAY;			//IMAGE_COLOR or IMAGE_GRAY 
			SPM.spPixelDepth =	16; 				//pixel depth 8 or 16
			SPM.spCCDLMT = 0;
			break;
		default:
			dprintf("SetParameter error (img.bit=%d)\n", job->img.bit);
			return FALSE;
	}

	switch(job->img.mono) {
		case 1:
		case 8:	// IR
			SPM.spMonoChannel = CHANNEL_RED;		//channel of IMAGE_GRAY 
			break;
		case 2:
			SPM.spMonoChannel = CHANNEL_GREEN;		//channel of IMAGE_GRAY 
			break;
		case 4:
			SPM.spMonoChannel = CHANNEL_BLUE;		//channel of IMAGE_GRAY 
			break;
		default:
			SPM.spMonoChannel = CHANNEL_GREEN;		//channel of IMAGE_GRAY 
			break;
	}

	//SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY
	//SPM.spMonoChannel = CHANNEL_GREEN;		//channel of IMAGE_GRAY 
	//SPM.spPixelDepth =		8;				//pixel depth 8 or 16

	SPM.spExposureTime =  g_Exp; //exposure time , unit = ms
	SPM.spShutterTime[0]= gLightOnTime[0]; 
	SPM.spShutterTime[1]= gLightOnTime[1];
	SPM.spShutterTime[2]= gLightOnTime[2]; 

	SPM.spDummyLines =		0; //4;		//dummy line
	SPM.spStillMode =		0;		//set motor still status
	SPM.spAutoGoHome =		0;		//set auto go home function after scan finished
	SPM.spDisBackTrack =	0;		//set carriage backtracking when image buffer full, enable_backtracking=0
	//SPM.spScanerStatus = STATUS_OPERATION;

	if(iEnableShading==1)
	{
		//printf("Enable shading.....\n");
		SPM.spShading	=		1;		//enable ASIC shading
		SPM.spGammaMapping	=	0;		//enable ASIC gamma
	}
	else{
		//printf("Disable shading.....\n");
		SPM.spShading	=		0;		//enable ASIC shading
		SPM.spGammaMapping	=	0;		//enable ASIC gamma
	}

	SPM.spCCDPacking = 0;

	SPM.spTestImage = job->action.test_pattern;			//0=real image, 1=pixel count pattern, 2=line count pattern
	//SPM.spCCDLMT = 2;
	SPM.spADFscan =	0x00;           //1=single adf scan, 2=autoadf
	SPM.spDualscan=	0;              // 0=disable,  1=switch separate CCDLMT=5,   2=scan in same time CCDLMT=2

	SPM.spSimplexSide = 0;			// 0 = top side, 1 = bottom side

	//bit1=JPG enable, bit3=thumb enable, bit4(1=444 0=422), bit7(1=best 0=normal quality)
	SPM.spJPEGENC = (job->img.format == I3('JPG'))? 0x11: 0x00; 

	SPM.spMirror = 0x01;			//nibble 0 top side flag, nibble 1 bottom side flag (ScanLinePixels must be multiple of 8)

//HL modify
#if 0
	bRet=ReadFileCalibartionData(&SPM);  // write scan parameter
	if(!bRet) return False;
#else
	SPM.spShutterTime[0]  = g_300_LedR1;
	SPM.spShutterTime[1]  = g_300_LedG1;
	SPM.spShutterTime[2]  = g_300_LedB1;
#endif	
	
	CtlImage_RamSet_ImageBuffer(&SPM);
	Sctl_SetScanParameter(&SPM);
//HL modify	
#if 0
	CtlAfe_SetAFEGain(AFEGainCode[0], AFEGainCode[1], AFEGainCode[2]);  //write AFE gain code
	CtlAfe_SetAFEOffset(AFEOffsetCode[0], AFEOffsetCode[1], AFEOffsetCode[2]); //write AFE offset code
	
	if(SPM.spShading)
	{
		switch(solu)
		{
			case 200: 
				if(SPM.spDualscan){
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;

			case 300: 
				if(SPM.spDualscan){
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){ //main engine scan (bottom side)
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{ //(top side)
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;

			case 600:
				if(SPM.spDualscan){
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;

			case 1200:
				if(SPM.spDualscan){
					CtlImage_WriteShadingFile(0,0);
				}
				else{
					if(SPM.spSimplexSide ==0){
						mEngineScan = 1;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
					else{
						mEngineScan = 0;
						CtlImage_WriteShadingFile_SimplexscanFlag(0);
					}
				}
			break;
		}
	}
#endif	
	CtlADF_SetADFSEL(0);

	printf("\n*** Read AFE data ***\n");
	CtlAfe_ReadAFERegister(0x02,&data);  printf("AFE Reg0x02 = 0x%02x \n",data); //Gain	
	CtlAfe_ReadAFERegister(0x05,&data);  printf("AFE Reg0x05 = 0x%02x \n",data); //Offset
	printf("\n*** Read LED EXPO TIME ***\n");
	printf("LED EXPO TIME R, G, B = %f, %f, %f\n", SPM.spShutterTime[0], SPM.spShutterTime[1], SPM.spShutterTime[2]);
	return True;
}



int FLB_StartScan(JOB_SCAN_T *job)
{
	int bRet;

	//SET_REGBIT(0xa0000058, 0x01010c00, 0x00000000);
	//SET_REGBIT(0xa000005c, 0x01070d00, 0x00010000);

	//SET_REG(0xb0000050, 0x823003f8);
	//SET_REG(0xb0000054, 0x00126804);
	//SET_REG(0xb0000058, 0x370d7e21);
	//SET_REG(0xb000005c, 0x001ebd18);
	//SET_REG(0xb0000060, 0xc6b0fd20);
	
	//PWR_OperationMode(0);
	//SET_REGBIT(0xb000000c, CLRMCNT(clr)|CLRDOCJM(clr)|CLRLNCNT(clr), CLRMCNT(1)|CLRDOCJM(1)|CLRLNCNT(1));
	//SET_REGBIT(0xb0000008, ADFSEL(clr), ADFSEL(0));
	bRet=Sctl_StartScan(&SPM);
	if(!bRet) return False;

	//dprintf("(A)58:(%08x)\n(A)5c:(%08x)\n", M32(0xa0000058), M32(0xa000005c));
	//dprintf("(B)50:(%08x) (B)54:(%08x)\n", M32(0xb0000050), M32(0xb0000054));
	//dprintf("(B)58:(%08x) (B)5c:(%08x)\n", M32(0xb0000058), M32(0xb000005c));
	//dprintf("(B)60:(%08x) (B)64:(%08x) (B)64:(%08x)\n", M32(0xb0000060), M32(0xb0000064), M32(0xb0000068));
	
	return True;
}

int FLB_CancelScan(JOB_SCAN_T *job)
{
	
	SET_AUTO_ADF(0);
	SET_LINCNT(1);
	return TRUE;
}


int FLB_StopScan(JOB_SCAN_T *job)
{
	int bRet;
	U8 nVal;

	bRet=Sctl_StopScan(&SPM); 
	if(!bRet) return False;

	printf("StopScan finish...\n\n");

	do{
		CMDASIC_ReadRegister(0x0401,&nVal);
		nVal=nVal&8;
		nVal=nVal/8;
		//printf("home sensor 0x0401 bit-3 = %ld\n",nVal);
		if(nVal==1) break;
	}while(1);
	return bRet;
}

int CheckMotorinHome(int *iState);


int PowerOnBackToHome(void)
{
	int bRet=1;
	int isADFScanFinish=False;
	int iState;
	ScanParameter SPM;

	SPM.spScanBeginPixel = 0;	            //scan begin x way postion
	SPM.spScanBeginLine = 0;             //scan begin y way postion
	SPM.spScanLinePixels = CIS_TGEXP_300;    		//scan total x way pixels  
	SPM.spTotalScanLines = 300*0.2;			//scan total y way lines  
	SPM.spPixelResolution = 300;			// x way resolution
	SPM.spMotorResolution = 300;			// y way resolution
	SPM.spTimingIdx =		8;		//timing idex 1,2,4,8
	g_Exp  =g_300_Exp;
	gLightOnTime[0]=g_300_LedR1;
	gLightOnTime[1]=g_300_LedG1;
	gLightOnTime[2]=g_300_LedB1;

	SPM.spImageType = IMAGE_COLOR;			//IMAGE_COLOR or IMAGE_GRAY
	SPM.spMonoChannel = CHANNEL_GREEN;		//channel of IMAGE_GRAY 
	SPM.spPixelDepth =		8;				//pixel depth 8 or 16

	SPM.spExposureTime =  g_Exp; //exposure time , unit = ms	
	SPM.spShutterTime[0]= gLightOnTime[0]; 
	SPM.spShutterTime[1]= gLightOnTime[1];
	SPM.spShutterTime[2]= gLightOnTime[2];
	
	SPM.spDummyLines =		0;		//dummy line
	SPM.spStillMode =		0;		//set motor still status
	SPM.spAutoGoHome =		1;		//set auto go home function after scan finished
	SPM.spDisBackTrack =	1;		//set carriage backtracking when image buffer full, enable_backtracking=0
	SPM.spShading	=		0;		//enable ASIC shading
	SPM.spGammaMapping	=	0;		//enable ASIC gamma

	SPM.spTestImage = 0;			//0=real image, 1=pixel count pattern, 2=line count pattern
	SPM.spCCDLMT = 2;
	SPM.spADFscan =	0;           //1=single adf scan, 2=autoadf
	SPM.spDualscan=	0;              // 0=disable,  1=switch separate CCDLMT=5,   2=scan in same time CCDLMT=2

	SPM.spSimplexSide = 0;			// 0 = top side, 1 = bottom side

	//bit1=JPG enable, bit3=thumb enable, bit4(1=444 0=422), bit7(1=best 0=normal quality)
	SPM.spJPEGENC	=	0x00; //0x11; 	

	SPM.spMirror = 0x00;  //bit0=1: image horizontal mirror (ScanLinePixels must be multiple of 8)

	bRet=Sctl_SetScanParameter(&SPM);  // write scan parameter
	if(!bRet) return False;

	CMDASIC_WriteRegisterBit(0x0003,4,1,0); //LAMPPWR

	bRet=CheckMotorinHome(&iState);
	if(!bRet) return False;

	//FB_Motor_Enable();

	bRet=Sctl_StartScan(&SPM);
	if(!bRet) return False;

	taskSleep(100); //wait motor back to home

	bRet=CheckMotorinHome(&iState);
	//if(!bRet) return False;
	
	//bRet=Sctl_BackToHomeReadScanData_to_RAWFILE2(&SPM);
	//bRet=Sctl_ReadScanData_RAW(&SPM);
	if(!bRet) {
		Sctl_StopScan(&SPM);
		return False;
	}

	bRet=Sctl_StopScan(&SPM); 
	if(!bRet) return False;

	CtlMotor_WaitMotorStop();

	//PowerOnBACK = 0;

	return True;

}

