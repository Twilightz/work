////////////////////////////////////////////////////////////////
// File - asiccmd.h
// Copyright (c) 2011 - Genesys Logic, INC.
//
// define the export function and global variable for asiccmd.c 
//
////////////////////////////////////////////////////////////////

#ifndef _asiccmd_h
#define _asiccmd_h

#define Canopus_CIS

//#include "usbio.h"

#define  MAX_SCAN_REGISTERS      0xA1C 
#ifdef Canopus_CIS	
	#define		CIS_TGEXP_150			1296		
	#define		CIS_TGEXP_200			1728	
	#define		CIS_TGEXP_300			2592
	#define		CIS_TGEXP_600			5184
	#define		CIS_TGEXP_1200		10368
#endif

typedef struct {
 	unsigned short nCtrl;
	unsigned char nValue;
}RegRec;


int CMDASIC_ReadRegister(unsigned short nAddr,unsigned char *nResult);
int CMDASIC_ReadTwiRegister(unsigned short nAddr,unsigned short *wResult);
int CMDASIC_ReadFourRegister(unsigned short nAddr, unsigned int *dwResult); 

int CMDASIC_WriteRegisterBit(unsigned short nAddr, unsigned char StartBit, unsigned char Bitn, unsigned char iData);
int CMDASIC_WriteRegister(unsigned short nAddr, unsigned char nData);
int CMDASIC_WriteTwiRegister(unsigned short nAddr, unsigned short wData);  
int CMDASIC_WriteFourRegister(unsigned short nAddr, unsigned int dwData);
int CMDASIC_WriteMultiRegister(unsigned char *pBuf, unsigned int dwLen);

int CMDASIC_SetupBulkLength(unsigned addr, unsigned int len,unsigned char bmode); //bmode=1=write bmode=0=read
int CMDASIC_ReadBulkData(unsigned int wAddr, unsigned char *pData, unsigned int dwLen);
int CMDASIC_WriteBulkData(unsigned int wAddr, unsigned char *pData, unsigned int dwLen);

int CMDASIC_WriteBulkData_Ex(unsigned int wAddr, unsigned char *pData, unsigned int dwLen);

int CMDASIC_APBWriteAddr(unsigned int addr);
int CMDASIC_APBWriteData(unsigned int data);
int CMDASIC_APBReadData(unsigned int *data);

int CMDASIC_Debug_Dump(void);

int CMDASIC_WriteJPGBus(unsigned short nAddr, unsigned int nData);
int CMDASIC_ReadJPGBus(unsigned short nAddr, unsigned int *nResult);

int CMDASIC_WriteJPGBus_B(unsigned short nAddr, unsigned int nData);
int CMDASIC_ReadJPGBus_B(unsigned short nAddr, unsigned int *nResult);

int CMDASIC_WriteBus(unsigned int nAddr, unsigned int nData);
int CMDASIC_ReadBus(unsigned int nAddr, unsigned int *nResult);

#endif  //_asiccmd_h




